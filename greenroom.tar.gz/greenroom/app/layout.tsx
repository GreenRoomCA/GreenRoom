import type { Metadata, Viewport } from 'next'
import './globals.css'
import { Toaster } from '@/components/ui/Toaster'
import { AuthProvider } from '@/components/shared/AuthProvider'

export const metadata: Metadata = {
  title: {
    default: 'GreenRoom — Watch the Set',
    template: '%s | GreenRoom',
  },
  description: 'Missed the show? Watch the set here. The discovery-first marketplace for stand-up comedy.',
  keywords: ['stand-up comedy', 'comedy sets', 'comedians', 'live comedy', 'comedy streaming'],
  authors: [{ name: 'GreenRoom' }],
  creator: 'GreenRoom',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: process.env.NEXT_PUBLIC_APP_URL,
    title: 'GreenRoom — Watch the Set',
    description: 'Missed the show? Watch the set here.',
    siteName: 'GreenRoom',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'GreenRoom — Watch the Set',
    description: 'Missed the show? Watch the set here.',
  },
  robots: {
    index: true,
    follow: true,
  },
}

export const viewport: Viewport = {
  themeColor: '#0a0a0a',
  colorScheme: 'dark',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="dark">
      <body className="bg-background text-text-primary font-body antialiased">
        <AuthProvider>
          {children}
          <Toaster />
        </AuthProvider>
      </body>
    </html>
  )
}
