import { createServerClient } from '@/lib/supabase'
import { VideoFeed } from '@/components/feed/VideoFeed'
import { CategoryFilter } from '@/components/feed/CategoryFilter'
import type { Post } from '@/types'

interface FeedPageProps {
  searchParams: { category?: string; page?: string }
}

export default async function FeedPage({ searchParams }: FeedPageProps) {
  const supabase = createServerClient()
  const category = searchParams.category
  const page = parseInt(searchParams.page || '1')
  const limit = 10
  const offset = (page - 1) * limit

  let query = supabase
    .from('posts')
    .select(`
      *,
      creator:creators(
        id, display_name, username, profile_image_url,
        subscription_price, ticket_link
      )
    `)
    .eq('status', 'published')
    .not('preview_mux_playback_id', 'is', null)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1)

  if (category) {
    query = query.eq('category', category)
  }

  const { data: posts, error } = await query

  if (error) {
    console.error('Feed error:', error)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Desktop header */}
      <div className="hidden md:block sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border px-6 py-4">
        <div className="flex items-center justify-between max-w-3xl mx-auto">
          <h1 className="font-display text-2xl text-text-primary">
            Discover
          </h1>
          <CategoryFilter selected={category} />
        </div>
      </div>

      {/* Mobile category filter */}
      <div className="md:hidden sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border px-4 py-3">
        <CategoryFilter selected={category} />
      </div>

      <VideoFeed
        initialPosts={(posts as Post[]) || []}
        category={category}
      />
    </div>
  )
}
