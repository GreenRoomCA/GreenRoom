import Link from 'next/link'
import { ArrowRight, Play, Mic, TrendingUp, Lock, Star } from 'lucide-react'
import { createServerClient } from '@/lib/supabase'

export default async function LandingPage() {
  const supabase = createServerClient()

  // Fetch featured creators for social proof
  const { data: creators } = await supabase
    .from('creators')
    .select('display_name, profile_image_url, username')
    .limit(6)

  return (
    <div className="min-h-screen bg-background overflow-hidden">
      {/* Nav */}
      <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-gold flex items-center justify-center">
              <span className="text-black font-display font-bold text-sm">G</span>
            </div>
            <span className="font-display text-xl text-text-primary">GreenRoom</span>
          </div>
          <div className="flex items-center gap-3">
            <Link
              href="/login"
              className="text-sm text-text-secondary hover:text-text-primary transition-colors px-4 py-2"
            >
              Sign in
            </Link>
            <Link
              href="/signup"
              className="text-sm bg-gold text-black font-medium px-4 py-2 rounded-lg hover:bg-gold-light transition-colors"
            >
              Join free
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-4 pt-16">
        {/* Spotlight bg */}
        <div className="absolute inset-0 spotlight-vignette pointer-events-none" />
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-gold/3 blur-[120px] pointer-events-none" />

        <div className="relative z-10 text-center max-w-4xl mx-auto">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-gold/20 bg-gold/5 text-gold text-sm mb-8">
            <Mic className="w-3.5 h-3.5" />
            <span>The comedy creator marketplace</span>
          </div>

          {/* Headline */}
          <h1 className="font-display text-5xl md:text-7xl lg:text-8xl text-text-primary leading-none mb-6">
            Missed the show?
            <br />
            <span className="text-gold-gradient italic">Watch the set.</span>
          </h1>

          <p className="text-lg md:text-xl text-text-secondary max-w-2xl mx-auto mb-10 leading-relaxed">
            Comedians turn past performances into revenue. Fans discover and unlock real full sets from real shows — right here.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/feed"
              className="inline-flex items-center gap-2 px-8 py-4 bg-gold text-black font-medium rounded-xl hover:bg-gold-light transition-colors text-lg"
            >
              <Play className="w-5 h-5 fill-current" />
              Watch Free Previews
            </Link>
            <Link
              href="/onboarding"
              className="inline-flex items-center gap-2 px-8 py-4 border border-border bg-surface text-text-primary font-medium rounded-xl hover:border-gold/30 hover:bg-surface-2 transition-colors text-lg"
            >
              I'm a Comedian
              <ArrowRight className="w-5 h-5" />
            </Link>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border border-white/10 flex items-start justify-center pt-2">
            <div className="w-1 h-2 bg-gold/40 rounded-full" />
          </div>
        </div>
      </section>

      {/* How it works - Fan */}
      <section className="py-24 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <p className="text-gold text-sm font-medium tracking-widest uppercase mb-3">For Fans</p>
            <h2 className="font-display text-4xl md:text-5xl text-text-primary">
              Comedy that actually happened
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Play,
                title: 'Scroll the Feed',
                desc: 'Free 60-second preview clips from real shows. Real venues. Real crowds.',
              },
              {
                icon: Lock,
                title: 'Unlock Full Sets',
                desc: 'Buy individual sets, subscribe to your favorites, or grab a bundle.',
              },
              {
                icon: Star,
                title: 'Discover Your People',
                desc: 'Follow comedians, earn supporter badges, see them live.',
              },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="bg-surface border border-border rounded-2xl p-8 hover:border-gold/20 transition-colors">
                <div className="w-12 h-12 rounded-xl bg-gold/10 flex items-center justify-center mb-5">
                  <Icon className="w-6 h-6 text-gold" />
                </div>
                <h3 className="font-display text-xl text-text-primary mb-3">{title}</h3>
                <p className="text-text-secondary leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* For comedians */}
      <section className="py-24 px-4 bg-surface/50">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <p className="text-gold text-sm font-medium tracking-widest uppercase mb-3">For Comedians</p>
              <h2 className="font-display text-4xl md:text-5xl text-text-primary mb-6">
                Every show is a
                <br />
                <span className="text-gold-gradient italic">revenue stream.</span>
              </h2>
              <p className="text-text-secondary text-lg leading-relaxed mb-8">
                You already did the work. You wrote the jokes, hit the road, killed the room.
                Now let those sets keep paying you.
              </p>
              <ul className="space-y-3 mb-8">
                {[
                  'Upload your 60-second preview clip',
                  'Set your own price — no limits',
                  'Fans subscribe or buy individual sets',
                  'Get paid directly via Stripe',
                  'Bundle your best shows',
                  'Schedule drops for new content',
                ].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-text-secondary">
                    <div className="w-1.5 h-1.5 rounded-full bg-gold shrink-0" />
                    {item}
                  </li>
                ))}
              </ul>
              <Link
                href="/onboarding"
                className="inline-flex items-center gap-2 px-6 py-3 bg-gold text-black font-medium rounded-xl hover:bg-gold-light transition-colors"
              >
                Start Monetizing
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            <div className="relative">
              <div className="bg-surface border border-border rounded-2xl p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-display text-lg text-text-primary">This Month</h4>
                  <span className="text-xs text-text-muted">Creator Dashboard</span>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: 'Revenue', value: '$1,247', trend: '+23%' },
                    { label: 'Subscribers', value: '89', trend: '+12' },
                    { label: 'Preview Views', value: '4.2K', trend: '+31%' },
                    { label: 'Conversion', value: '6.8%', trend: '+1.2%' },
                  ].map(({ label, value, trend }) => (
                    <div key={label} className="bg-surface-2 rounded-xl p-4">
                      <p className="text-xs text-text-muted mb-1">{label}</p>
                      <p className="text-xl font-display text-text-primary">{value}</p>
                      <p className="text-xs text-emerald-400 mt-1">{trend}</p>
                    </div>
                  ))}
                </div>
                <div className="border-t border-border pt-4">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-text-secondary">Top set: "NYC Crowd Work"</span>
                    <span className="text-gold font-medium">$342 earned</span>
                  </div>
                </div>
              </div>
              <div className="absolute -top-3 -right-3 bg-gold rounded-lg px-3 py-1 text-xs font-mono text-black font-medium">
                <TrendingUp className="w-3 h-3 inline mr-1" />
                Live preview
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing transparency */}
      <section className="py-24 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-display text-4xl md:text-5xl text-text-primary mb-6">
            Simple, transparent pricing
          </h2>
          <p className="text-text-secondary text-lg mb-12">
            Comedians keep 80% of every dollar. GreenRoom takes 20% to keep the lights on.
          </p>

          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {[
              { label: 'New / Open Mic', range: '$3–$8', desc: 'Test material, crowd work clips' },
              { label: 'Working Comic', range: '$8–$20', desc: 'Full sets from regular shows' },
              { label: 'Established', range: '$20–$50+', desc: 'Headliner sets, specials' },
            ].map(({ label, range, desc }) => (
              <div key={label} className="bg-surface border border-border rounded-2xl p-6 text-left">
                <p className="text-xs text-gold font-medium uppercase tracking-wider mb-2">{label}</p>
                <p className="font-display text-3xl text-text-primary mb-2">{range}</p>
                <p className="text-sm text-text-secondary">{desc}</p>
              </div>
            ))}
          </div>
          <p className="text-xs text-text-muted">
            These are suggestions only. Comedians set whatever price they want.
          </p>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 px-4 border-t border-border">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="font-display text-5xl text-text-primary mb-6">
            Ready for your
            <br />
            <span className="text-gold-gradient italic">GreenRoom moment?</span>
          </h2>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              href="/signup?role=creator"
              className="px-8 py-4 bg-gold text-black font-medium rounded-xl hover:bg-gold-light transition-colors"
            >
              Start as a Comedian
            </Link>
            <Link
              href="/feed"
              className="px-8 py-4 border border-border bg-surface text-text-primary font-medium rounded-xl hover:border-gold/30 transition-colors"
            >
              Browse the Feed
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 px-4">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-gradient-gold flex items-center justify-center">
              <span className="text-black font-display font-bold text-xs">G</span>
            </div>
            <span className="font-display text-sm text-text-secondary">GreenRoom</span>
          </div>
          <p className="text-xs text-text-muted">
            © {new Date().getFullYear()} GreenRoom. Missed the show? Watch the set here.
          </p>
          <div className="flex gap-4 text-xs text-text-muted">
            <Link href="/privacy" className="hover:text-text-secondary">Privacy</Link>
            <Link href="/terms" className="hover:text-text-secondary">Terms</Link>
            <Link href="/support" className="hover:text-text-secondary">Support</Link>
          </div>
        </div>
      </footer>
    </div>
  )
}
