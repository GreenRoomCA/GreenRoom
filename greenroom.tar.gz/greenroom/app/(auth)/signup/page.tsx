'use client'

import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { createBrowserClient } from '@/lib/supabase'
import { useToast } from '@/components/ui/Toaster'
import { Mic, User } from 'lucide-react'
import { cn } from '@/lib/utils'

type Role = 'viewer' | 'creator'

export default function SignupPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [displayName, setDisplayName] = useState('')
  const [role, setRole] = useState<Role>('viewer')
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()
  const supabase = createBrowserClient()
  const { error, success } = useToast()

  // Pre-select role from URL param
  const defaultRole = searchParams.get('role') as Role | null

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault()
    setIsLoading(true)

    const { data, error: authError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        data: { display_name: displayName, role },
      },
    })

    if (authError) {
      error('Signup failed', authError.message)
      setIsLoading(false)
      return
    }

    // Update user role in DB
    if (data.user) {
      await supabase
        .from('users')
        .update({ role, display_name: displayName })
        .eq('id', data.user.id)
    }

    success('Account created!')

    if (role === 'creator') {
      router.push('/onboarding')
    } else {
      router.push('/feed')
    }
    router.refresh()
  }

  const selectedRole = defaultRole || role

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 bg-background">
      <Link href="/" className="flex items-center gap-2 mb-10">
        <div className="w-10 h-10 rounded-xl bg-gradient-gold flex items-center justify-center">
          <span className="text-black font-display font-bold text-lg">G</span>
        </div>
        <span className="font-display text-2xl text-text-primary">GreenRoom</span>
      </Link>

      <div className="w-full max-w-sm">
        <div className="bg-surface border border-border rounded-2xl p-8">
          <h1 className="font-display text-2xl text-text-primary mb-1">Join GreenRoom</h1>
          <p className="text-text-secondary text-sm mb-6">Create your account</p>

          {/* Role selector */}
          <div className="flex gap-2 mb-6">
            <button
              type="button"
              onClick={() => setRole('viewer')}
              className={cn(
                'flex-1 flex flex-col items-center gap-2 py-4 px-3 rounded-xl border transition-all',
                role === 'viewer'
                  ? 'border-gold bg-gold/5 text-gold'
                  : 'border-border text-text-secondary hover:border-border-hover'
              )}
            >
              <User className="w-5 h-5" />
              <div>
                <p className="text-xs font-medium">I'm a Fan</p>
                <p className="text-[10px] opacity-70">Watch & discover</p>
              </div>
            </button>
            <button
              type="button"
              onClick={() => setRole('creator')}
              className={cn(
                'flex-1 flex flex-col items-center gap-2 py-4 px-3 rounded-xl border transition-all',
                role === 'creator'
                  ? 'border-gold bg-gold/5 text-gold'
                  : 'border-border text-text-secondary hover:border-border-hover'
              )}
            >
              <Mic className="w-5 h-5" />
              <div>
                <p className="text-xs font-medium">I'm a Comedian</p>
                <p className="text-[10px] opacity-70">Upload & monetize</p>
              </div>
            </button>
          </div>

          <form onSubmit={handleSignup} className="space-y-4">
            <div>
              <label className="block text-sm text-text-secondary mb-1.5">Name</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                required
                placeholder={role === 'creator' ? 'Your stage name' : 'Your name'}
                className="w-full px-4 py-3 rounded-xl bg-surface-2 border border-border text-text-primary placeholder-text-muted focus:outline-none focus:border-gold/50 transition-colors text-sm"
              />
            </div>

            <div>
              <label className="block text-sm text-text-secondary mb-1.5">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="your@email.com"
                className="w-full px-4 py-3 rounded-xl bg-surface-2 border border-border text-text-primary placeholder-text-muted focus:outline-none focus:border-gold/50 transition-colors text-sm"
              />
            </div>

            <div>
              <label className="block text-sm text-text-secondary mb-1.5">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={8}
                placeholder="At least 8 characters"
                className="w-full px-4 py-3 rounded-xl bg-surface-2 border border-border text-text-primary placeholder-text-muted focus:outline-none focus:border-gold/50 transition-colors text-sm"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 bg-gold hover:bg-gold-light disabled:opacity-50 text-black font-semibold rounded-xl transition-colors mt-2"
            >
              {isLoading ? 'Creating account...' : 'Create Account'}
            </button>
          </form>

          <p className="text-center text-xs text-text-muted mt-4">
            By signing up, you agree to our Terms & Privacy Policy.
          </p>
        </div>

        <p className="text-center text-sm text-text-secondary mt-6">
          Already have an account?{' '}
          <Link href="/login" className="text-gold hover:text-gold-light">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  )
}
