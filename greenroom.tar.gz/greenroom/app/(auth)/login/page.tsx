'use client'

import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'
import { createBrowserClient } from '@/lib/supabase'
import { useToast } from '@/components/ui/Toaster'

export default function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const router = useRouter()
  const searchParams = useSearchParams()
  const redirect = searchParams.get('redirect') || '/feed'
  const supabase = createBrowserClient()
  const { error, success } = useToast()

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault()
    setIsLoading(true)

    const { error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    })

    if (authError) {
      error('Sign in failed', authError.message)
      setIsLoading(false)
      return
    }

    success('Welcome back!')
    router.push(redirect)
    router.refresh()
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 bg-background">
      {/* Logo */}
      <Link href="/" className="flex items-center gap-2 mb-10">
        <div className="w-10 h-10 rounded-xl bg-gradient-gold flex items-center justify-center">
          <span className="text-black font-display font-bold text-lg">G</span>
        </div>
        <span className="font-display text-2xl text-text-primary">GreenRoom</span>
      </Link>

      <div className="w-full max-w-sm">
        <div className="bg-surface border border-border rounded-2xl p-8">
          <h1 className="font-display text-2xl text-text-primary mb-1">Welcome back</h1>
          <p className="text-text-secondary text-sm mb-8">Sign in to your GreenRoom account</p>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm text-text-secondary mb-1.5">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                placeholder="your@email.com"
                className="w-full px-4 py-3 rounded-xl bg-surface-2 border border-border text-text-primary placeholder-text-muted focus:outline-none focus:border-gold/50 transition-colors text-sm"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-sm text-text-secondary">Password</label>
                <Link href="/forgot-password" className="text-xs text-gold hover:text-gold-light">
                  Forgot?
                </Link>
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                placeholder="••••••••"
                className="w-full px-4 py-3 rounded-xl bg-surface-2 border border-border text-text-primary placeholder-text-muted focus:outline-none focus:border-gold/50 transition-colors text-sm"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 bg-gold hover:bg-gold-light disabled:opacity-50 text-black font-semibold rounded-xl transition-colors mt-2"
            >
              {isLoading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
        </div>

        <p className="text-center text-sm text-text-secondary mt-6">
          New to GreenRoom?{' '}
          <Link href="/signup" className="text-gold hover:text-gold-light">
            Create account
          </Link>
        </p>
      </div>
    </div>
  )
}
