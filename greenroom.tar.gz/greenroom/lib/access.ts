import { createAdminClient } from '@/lib/supabase'
import type { Post } from '@/types'

export async function canUserAccessPost(
  userId: string | null,
  postId: string
): Promise<boolean> {
  const supabase = createAdminClient()

  // Use the DB function for efficient access check
  const { data, error } = await supabase.rpc('can_user_access_post', {
    p_user_id: userId,
    p_post_id: postId,
  })

  if (error) {
    console.error('Access check error:', error)
    return false
  }

  return data === true
}

export async function getUserAccessMap(
  userId: string | null,
  postIds: string[]
): Promise<Record<string, boolean>> {
  if (!postIds.length) return {}

  const supabase = createAdminClient()

  // Batch check all posts
  const results = await Promise.all(
    postIds.map(async (postId) => {
      const { data } = await supabase.rpc('can_user_access_post', {
        p_user_id: userId,
        p_post_id: postId,
      })
      return { postId, hasAccess: data === true }
    })
  )

  return results.reduce(
    (acc, { postId, hasAccess }) => ({ ...acc, [postId]: hasAccess }),
    {}
  )
}

export async function getSignedVideoUrl(
  postId: string,
  userId: string | null
): Promise<{ url: string | null; error: string | null }> {
  const hasAccess = await canUserAccessPost(userId, postId)

  if (!hasAccess) {
    return { url: null, error: 'Access denied. Please purchase or subscribe to watch this content.' }
  }

  const supabase = createAdminClient()
  const { data: post, error } = await supabase
    .from('posts')
    .select('full_mux_playback_id')
    .eq('id', postId)
    .single()

  if (error || !post?.full_mux_playback_id) {
    return { url: null, error: 'Video not found' }
  }

  const { getSignedPlaybackUrl } = await import('@/lib/mux')

  try {
    const url = await getSignedPlaybackUrl(post.full_mux_playback_id)
    return { url, error: null }
  } catch (err) {
    return { url: null, error: 'Failed to generate video URL' }
  }
}

export async function getUserLibrary(userId: string) {
  const supabase = createAdminClient()

  // Get individual purchases
  const { data: purchases } = await supabase
    .from('purchases')
    .select(`
      *,
      post:posts(*, creator:creators(*))
    `)
    .eq('user_id', userId)
    .eq('status', 'completed')
    .order('created_at', { ascending: false })

  // Get bundle purchases
  const { data: bundlePurchases } = await supabase
    .from('bundle_purchases')
    .select(`
      *,
      bundle:bundles(*, creator:creators(*), bundle_posts(post:posts(*)))
    `)
    .eq('user_id', userId)
    .eq('status', 'completed')
    .order('created_at', { ascending: false })

  // Get posts accessible via active subscriptions
  const { data: activeSubscriptions } = await supabase
    .from('subscriptions')
    .select(`
      *,
      creator:creators(*)
    `)
    .eq('user_id', userId)
    .eq('status', 'active')
    .gt('current_period_end', new Date().toISOString())

  return {
    purchases: purchases || [],
    bundlePurchases: bundlePurchases || [],
    activeSubscriptions: activeSubscriptions || [],
  }
}
