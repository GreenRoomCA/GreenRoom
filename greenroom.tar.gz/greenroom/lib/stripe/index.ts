import Stripe from 'stripe'

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error('STRIPE_SECRET_KEY environment variable is not set')
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2024-06-20',
  typescript: true,
})

export const PLATFORM_FEE_PERCENT = parseInt(
  process.env.GREENROOM_PLATFORM_FEE_PERCENT || '20',
  10
)

export function calculatePlatformFee(amount: number): number {
  return Math.round((amount * PLATFORM_FEE_PERCENT) / 100)
}

export function calculateCreatorEarnings(amount: number): number {
  return amount - calculatePlatformFee(amount)
}

// Convert dollars to cents for Stripe
export function toCents(dollars: number): number {
  return Math.round(dollars * 100)
}

// Convert cents to dollars
export function toDollars(cents: number): number {
  return cents / 100
}

export function formatPrice(dollars: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(dollars)
}
