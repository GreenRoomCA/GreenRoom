import Mux from '@mux/mux-node'

if (!process.env.MUX_TOKEN_ID || !process.env.MUX_TOKEN_SECRET) {
  throw new Error('MUX_TOKEN_ID and MUX_TOKEN_SECRET must be set')
}

export const mux = new Mux({
  tokenId: process.env.MUX_TOKEN_ID,
  tokenSecret: process.env.MUX_TOKEN_SECRET,
})

export const MAX_PREVIEW_DURATION_SECONDS = 60

// Generate a signed playback URL for protected content
export async function getSignedPlaybackUrl(
  playbackId: string,
  type: 'video' | 'thumbnail' | 'storyboard' = 'video',
  expirationSeconds = 3600
): Promise<string> {
  const signingKeyId = process.env.MUX_SIGNING_KEY_ID
  const signingKeySecret = process.env.MUX_SIGNING_KEY_SECRET

  if (!signingKeyId || !signingKeySecret) {
    // Fall back to unsigned URL in development
    if (process.env.NODE_ENV === 'development') {
      return `https://stream.mux.com/${playbackId}.m3u8`
    }
    throw new Error('MUX_SIGNING_KEY_ID and MUX_SIGNING_KEY_SECRET must be set for production')
  }

  const token = await mux.jwt.signPlaybackId(playbackId, {
    keyId: signingKeyId,
    keySecret: signingKeySecret,
    type,
    expiration: `${expirationSeconds}s`,
  })

  if (type === 'video') {
    return `https://stream.mux.com/${playbackId}.m3u8?token=${token}`
  } else if (type === 'thumbnail') {
    return `https://image.mux.com/${playbackId}/thumbnail.jpg?token=${token}`
  } else {
    return `https://image.mux.com/${playbackId}/storyboard.vtt?token=${token}`
  }
}

// Create a new Mux direct upload
export async function createMuxUpload(corsOrigin: string) {
  const upload = await mux.video.uploads.create({
    cors_origin: corsOrigin,
    new_asset_settings: {
      playback_policy: ['signed'],
      mp4_support: 'none',
    },
  })
  return upload
}

// Get asset info from Mux
export async function getMuxAsset(assetId: string) {
  return await mux.video.assets.retrieve(assetId)
}

// Get thumbnail URL (public/unsigned for preview thumbnails)
export function getMuxThumbnailUrl(playbackId: string, time = 5): string {
  return `https://image.mux.com/${playbackId}/thumbnail.jpg?time=${time}&width=640`
}

// Get animated GIF preview for feed cards
export function getMuxAnimatedUrl(playbackId: string): string {
  return `https://image.mux.com/${playbackId}/animated.gif?fps=10&width=640`
}

// Delete a Mux asset
export async function deleteMuxAsset(assetId: string) {
  try {
    await mux.video.assets.delete(assetId)
  } catch (error) {
    console.error('Failed to delete Mux asset:', error)
  }
}
