import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { format, formatDistanceToNow, isAfter, isBefore } from 'date-fns'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatPrice(dollars: number): string {
  if (dollars === 0) return 'Free'
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(dollars)
}

export function formatDuration(seconds: number): string {
  if (!seconds) return '0:00'
  const hours = Math.floor(seconds / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const secs = Math.floor(seconds % 60)

  if (hours > 0) {
    return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }
  return `${minutes}:${secs.toString().padStart(2, '0')}`
}

export function formatNumber(num: number): string {
  if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(1)}M`
  if (num >= 1_000) return `${(num / 1_000).toFixed(1)}K`
  return num.toString()
}

export function formatDate(date: string | Date): string {
  return format(new Date(date), 'MMM d, yyyy')
}

export function formatShowDate(date: string | Date): string {
  return format(new Date(date), 'EEEE, MMMM d, yyyy')
}

export function formatRelativeTime(date: string | Date): string {
  return formatDistanceToNow(new Date(date), { addSuffix: true })
}

export function formatCountdown(date: string | Date): string {
  const target = new Date(date)
  const now = new Date()

  if (isBefore(target, now)) return 'Available now'

  const diff = target.getTime() - now.getTime()
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60))
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))

  if (days > 0) return `${days}d ${hours}h`
  if (hours > 0) return `${hours}h ${minutes}m`
  return `${minutes}m`
}

export function isDropLive(dropsAt: string): boolean {
  return isBefore(new Date(dropsAt), new Date())
}

export function getBadgeLabel(level: string): string {
  const labels: Record<string, string> = {
    none: '',
    supporter: 'Supporter',
    real_fan: 'Real Fan',
    top_supporter: 'Top Supporter',
    day_one: 'Day One',
  }
  return labels[level] || ''
}

export function getBadgeColor(level: string): string {
  const colors: Record<string, string> = {
    supporter: 'bg-zinc-700 text-zinc-300',
    real_fan: 'bg-amber-900/60 text-amber-300',
    top_supporter: 'bg-gold/20 text-gold',
    day_one: 'bg-gold/30 text-gold-light',
  }
  return colors[level] || ''
}

export function getPricingGuidance(price: number): string {
  if (price <= 8) return 'Open mic / new comic pricing'
  if (price <= 20) return 'Working comic pricing'
  return 'Established comic pricing'
}

export function generateShareCaption(creatorName: string, postTitle: string): string {
  return `Missed the show? Watch "${postTitle}" by ${creatorName} on GreenRoom.`
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .trim()
}

export function truncate(text: string, length: number): string {
  if (text.length <= length) return text
  return text.slice(0, length) + '...'
}

export function getInitials(name: string): string {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2)
}
