# GreenRoom 🎤

> **"Missed the show? Watch the set here."**

A discovery-first comedy creator marketplace. Comedians upload 60-second preview clips from real shows; fans pay to unlock full sets, subscribe, or buy bundles.

---

## Tech Stack

| Layer | Tech |
|---|---|
| Framework | Next.js 14 (App Router, TypeScript) |
| Styling | Tailwind CSS (custom design system) |
| Auth + DB | Supabase (Postgres + RLS + Auth) |
| Payments | Stripe + Stripe Connect (Express) |
| Video | Mux (upload, processing, signed playback) |
| Deployment | Vercel |

---

## Prerequisites

- Node.js 18+
- A [Supabase](https://supabase.com) account
- A [Stripe](https://stripe.com) account with Connect enabled
- A [Mux](https://mux.com) account

---

## 1. Clone & Install

```bash
git clone <your-repo>
cd greenroom
npm install
```

---

## 2. Environment Variables

Copy `.env.example` to `.env.local` and fill in all values:

```bash
cp .env.example .env.local
```

### Supabase
1. Create a new project at [supabase.com](https://supabase.com)
2. Go to **Settings → API**
3. Copy `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`
4. Copy the **service_role** key as `SUPABASE_SERVICE_ROLE_KEY` (keep this secret!)

### Stripe
1. Get your keys from [dashboard.stripe.com/apikeys](https://dashboard.stripe.com/apikeys)
2. Enable **Connect** at [dashboard.stripe.com/connect/accounts/overview](https://dashboard.stripe.com/connect/accounts/overview)
3. Set the Connect platform settings:
   - Platform profile: Software platform
   - Connected account type: Express
4. For webhooks (see step 5 below)

### Mux
1. Create an account at [mux.com](https://mux.com)
2. Go to **Settings → Access Tokens**
3. Create a token with **Mux Video** read/write access
4. Copy Token ID and Token Secret

---

## 3. Database Setup

Run the migrations in order in your Supabase SQL editor:

```bash
# In Supabase Dashboard → SQL Editor:

# 1. Schema
supabase/migrations/001_schema.sql

# 2. RLS Policies
supabase/policies/002_rls.sql
```

Or using the Supabase CLI:

```bash
npx supabase db push
```

### Verify Tables Created
You should see these tables in **Table Editor**:
- `users`, `creators`, `posts`, `purchases`
- `subscriptions`, `bundles`, `bundle_posts`, `bundle_purchases`
- `follows`, `views`, `likes`, `fan_spend`, `messages`, `drops`

---

## 4. Supabase Storage Buckets

In **Supabase Dashboard → Storage**, create two buckets:

| Bucket Name | Public | Max Size |
|---|---|---|
| `avatars` | ✅ Yes | 5 MB |
| `thumbnails` | ✅ Yes | 10 MB |

---

## 5. Stripe Webhooks

### Local Development (using Stripe CLI)

```bash
# Install Stripe CLI
brew install stripe/stripe-cli/stripe

# Login
stripe login

# Forward webhooks to your local server
stripe listen --forward-to localhost:3000/api/stripe/webhook
```

Copy the **webhook signing secret** shown in the terminal to `STRIPE_WEBHOOK_SECRET`.

### Production (Vercel)

1. Go to [dashboard.stripe.com/webhooks](https://dashboard.stripe.com/webhooks)
2. Click **Add endpoint**
3. URL: `https://yourdomain.com/api/stripe/webhook`
4. Select these events:
   - `checkout.session.completed`
   - `customer.subscription.created`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   - `invoice.payment_failed`
5. Copy the **Signing secret** to `STRIPE_WEBHOOK_SECRET`

---

## 6. Run Locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

---

## 7. Deploy to Vercel

```bash
npx vercel
```

Or connect your GitHub repo at [vercel.com](https://vercel.com) and add all env vars in the Vercel dashboard.

### Important: Disable Body Parsing for Webhook Route

The Stripe webhook route needs raw body access. This is already handled in `next.config.ts` — no action needed.

---

## Project Structure

```
src/
├── app/
│   ├── api/
│   │   ├── mux/
│   │   │   ├── upload/          # Create Mux upload URL
│   │   │   └── asset-status/    # Poll Mux processing
│   │   ├── stripe/
│   │   │   ├── checkout/
│   │   │   │   ├── post/        # Single set purchase
│   │   │   │   ├── subscription/ # Monthly subscription
│   │   │   │   └── bundle/      # Bundle purchase
│   │   │   ├── connect/         # Stripe Connect onboarding
│   │   │   └── webhook/         # All Stripe events
│   │   └── analytics/
│   │       └── view/            # Track view events
│   ├── auth/                    # Login, signup, callback
│   ├── checkout/success/        # Post-payment success page
│   ├── creator/
│   │   ├── [username]/          # Creator profile page
│   │   └── onboarding/          # 3-step creator setup
│   ├── dashboard/               # Creator dashboard
│   │   ├── upload/              # Video upload
│   │   ├── analytics/           # Stats
│   │   ├── bundles/             # Bundle creator
│   │   ├── drops/               # Scheduled releases
│   │   ├── messages/            # Fan inbox
│   │   └── settings/            # Creator settings
│   ├── feed/                    # Main scroll feed
│   ├── library/                 # Fan's purchased content
│   ├── post/[id]/               # Post detail / paywall
│   ├── settings/                # User account settings
│   └── watch/[id]/              # Full set playback
├── components/
│   ├── feed/                    # VideoCard, VideoFeed
│   ├── paywall/                 # PaywallModal
│   ├── shared/                  # Navbar
│   ├── ui/                      # Button, Input, Badge, Toaster
│   └── video/                   # VideoPlayer, PreviewVideo
└── lib/
    ├── mux/                     # Mux helper functions
    ├── stripe/                  # Stripe instance + helpers
    ├── supabase/                # Client, server, middleware
    └── utils/                   # Formatters, access control
```

---

## Key User Flows

### Fan Flow
1. Browse feed at `/feed`
2. Tap preview video → see post detail at `/post/[id]`
3. Unlock via PaywallModal → Stripe checkout
4. Redirected to `/watch/[id]` for full set
5. Library at `/library` shows all unlocked content

### Creator Flow
1. Sign up with "Comedian" role at `/auth/signup`
2. Complete onboarding at `/creator/onboarding` (3 steps)
3. Connect Stripe at `/dashboard/settings`
4. Upload at `/dashboard/upload`:
   - Upload 60s preview clip
   - Upload full set
   - Fill metadata (title, price, venue, date)
   - Set to draft or publish
5. Track earnings at `/dashboard/analytics`

---

## Pricing & Revenue Split

- GreenRoom takes **15%** platform fee on all transactions
- Creators keep **85%** via Stripe Connect (Express)
- Creators can set their own:
  - Per-set price (suggested $5–$15)
  - Monthly subscription price
  - Bundle prices

### Fan Badge Tiers (per creator)
| Tier | Total Spend |
|---|---|
| Fan | $0 |
| Supporter | $10+ |
| Regular | $40+ |
| VIP | $100+ |
| Day One | $200+ |

---

## Testing Checklist

### Auth
- [ ] Sign up as fan
- [ ] Sign up as comedian → redirects to onboarding
- [ ] Log in / log out

### Creator Setup
- [ ] Complete onboarding (3 steps)
- [ ] Connect Stripe Express account

### Upload
- [ ] Upload preview clip (should reject >60s clips via Mux)
- [ ] Upload full set
- [ ] Fill in metadata
- [ ] Publish post
- [ ] Check feed shows new post

### Payments (use Stripe test card `4242 4242 4242 4242`)
- [ ] Purchase individual set → redirects to /watch
- [ ] Subscribe to creator → appears in subscriptions
- [ ] Purchase bundle → appears in library
- [ ] Verify Stripe dashboard shows transfer to connected account
- [ ] Verify purchase appears in Supabase `purchases` table

### Access Control
- [ ] Unpurchased full set redirects to post page
- [ ] Purchased full set plays with signed Mux token
- [ ] Free posts are immediately watchable

### Analytics
- [ ] View counts increment on preview play
- [ ] View counts increment on full set watch
- [ ] Dashboard shows correct stats

---

## Common Issues

**"Creator has not set up payments" error**
→ Creator needs to complete Stripe Connect onboarding in Dashboard → Settings

**Mux upload stuck on "processing"**
→ Normal for first few minutes. The upload page polls every 3 seconds.

**Signed playback URLs expiring**
→ Tokens are set to 24h. For longer content, adjust in `watch/[id]/page.tsx`

**RLS policy blocking access**
→ Double-check you ran both SQL files. Service role key bypasses RLS for webhooks.
