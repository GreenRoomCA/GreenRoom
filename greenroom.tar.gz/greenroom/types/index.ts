// ============================================================
// GREENROOM TYPE DEFINITIONS
// ============================================================

export type UserRole = 'viewer' | 'creator' | 'admin'
export type PostStatus = 'draft' | 'published' | 'scheduled'
export type PostCategory = 'Full Set' | 'Crowd Work' | 'Unreleased' | 'Test Material' | 'Special' | 'Behind the Scenes'
export type SubscriptionStatus = 'active' | 'past_due' | 'canceled' | 'trialing' | 'incomplete'
export type PurchaseStatus = 'pending' | 'completed' | 'refunded' | 'failed'
export type BadgeLevel = 'none' | 'supporter' | 'real_fan' | 'top_supporter' | 'day_one'
export type ViewType = 'preview' | 'full'
export type StripeAccountStatus = 'not_connected' | 'pending' | 'active'

export interface User {
  id: string
  email: string
  role: UserRole
  display_name: string | null
  avatar_url: string | null
  created_at: string
  updated_at: string
}

export interface Creator {
  id: string
  user_id: string
  display_name: string
  username: string
  bio: string | null
  profile_image_url: string | null
  banner_image_url: string | null
  subscription_price: number
  stripe_account_id: string | null
  stripe_account_status: StripeAccountStatus
  ticket_link: string | null
  instagram_handle: string | null
  twitter_handle: string | null
  tiktok_handle: string | null
  website_url: string | null
  message_price: number
  total_earnings: number
  created_at: string
  updated_at: string
  // Computed/joined
  follower_count?: number
  post_count?: number
  subscriber_count?: number
}

export interface Post {
  id: string
  creator_id: string
  title: string
  description: string | null
  preview_video_url: string | null
  preview_mux_asset_id: string | null
  preview_mux_playback_id: string | null
  full_video_url: string | null
  full_mux_asset_id: string | null
  full_mux_playback_id: string | null
  thumbnail_url: string | null
  duration_seconds: number | null
  preview_duration_seconds: number | null
  price: number
  is_free: boolean
  is_subscription_included: boolean
  is_one_time_purchase_enabled: boolean
  is_premium_add_on: boolean
  category: PostCategory
  city: string | null
  venue: string | null
  show_date: string | null
  status: PostStatus
  scheduled_release_at: string | null
  view_count: number
  purchase_count: number
  like_count: number
  created_at: string
  updated_at: string
  // Joined
  creator?: Creator
  is_liked?: boolean
  is_purchased?: boolean
  user_has_access?: boolean
}

export interface Purchase {
  id: string
  user_id: string
  post_id: string
  creator_id: string
  stripe_payment_intent_id: string | null
  stripe_session_id: string | null
  price_paid: number
  platform_fee: number | null
  creator_earnings: number | null
  status: PurchaseStatus
  created_at: string
  // Joined
  post?: Post
  creator?: Creator
}

export interface Subscription {
  id: string
  user_id: string
  creator_id: string
  stripe_subscription_id: string | null
  stripe_customer_id: string | null
  status: SubscriptionStatus
  current_period_start: string | null
  current_period_end: string | null
  cancel_at_period_end: boolean
  canceled_at: string | null
  price_paid: number | null
  created_at: string
  updated_at: string
  // Joined
  creator?: Creator
}

export interface Bundle {
  id: string
  creator_id: string
  title: string
  description: string | null
  price: number
  thumbnail_url: string | null
  is_active: boolean
  total_runtime_seconds: number
  post_count: number
  purchase_count: number
  created_at: string
  updated_at: string
  // Joined
  creator?: Creator
  posts?: Post[]
  is_purchased?: boolean
}

export interface BundlePost {
  id: string
  bundle_id: string
  post_id: string
  position: number
  created_at: string
}

export interface Follow {
  id: string
  user_id: string
  creator_id: string
  created_at: string
}

export interface View {
  id: string
  user_id: string | null
  post_id: string
  creator_id: string
  view_type: ViewType
  watch_duration_seconds: number
  created_at: string
}

export interface Like {
  id: string
  user_id: string
  post_id: string
  created_at: string
}

export interface FanSpend {
  id: string
  user_id: string
  creator_id: string
  total_spent: number
  badge_level: BadgeLevel
  updated_at: string
}

export interface Drop {
  id: string
  creator_id: string
  post_id: string | null
  title: string
  description: string | null
  thumbnail_url: string | null
  drops_at: string
  is_notified: boolean
  created_at: string
  // Joined
  creator?: Creator
  post?: Post
}

export interface Message {
  id: string
  sender_id: string
  receiver_id: string
  creator_id: string
  body: string
  is_paid: boolean
  price_paid: number
  stripe_payment_intent_id: string | null
  is_read: boolean
  thread_id: string | null
  created_at: string
  // Joined
  sender?: User
}

// ============================================================
// ANALYTICS TYPES
// ============================================================
export interface CreatorAnalytics {
  total_revenue: number
  total_views: number
  preview_views: number
  full_views: number
  total_purchases: number
  total_subscribers: number
  conversion_rate: number
  top_posts: PostAnalytics[]
  top_supporters: FanSupporter[]
  revenue_by_day: RevenueDataPoint[]
  views_by_day: ViewDataPoint[]
}

export interface PostAnalytics {
  post_id: string
  title: string
  preview_views: number
  full_views: number
  purchases: number
  revenue: number
  conversion_rate: number
}

export interface FanSupporter {
  user_id: string
  display_name: string | null
  avatar_url: string | null
  total_spent: number
  badge_level: BadgeLevel
}

export interface RevenueDataPoint {
  date: string
  revenue: number
  purchases: number
}

export interface ViewDataPoint {
  date: string
  preview_views: number
  full_views: number
}

// ============================================================
// API RESPONSE TYPES
// ============================================================
export interface ApiResponse<T = void> {
  data?: T
  error?: string
  message?: string
}

export interface PaginatedResponse<T> {
  data: T[]
  count: number
  page: number
  limit: number
  has_more: boolean
}

// ============================================================
// FORM TYPES
// ============================================================
export interface CreatePostForm {
  title: string
  description: string
  price: number
  is_free: boolean
  is_subscription_included: boolean
  is_one_time_purchase_enabled: boolean
  is_premium_add_on: boolean
  category: PostCategory
  city: string
  venue: string
  show_date: string
  status: PostStatus
  scheduled_release_at?: string
}

export interface CreateBundleForm {
  title: string
  description: string
  price: number
  post_ids: string[]
}

export interface CreateDropForm {
  title: string
  description: string
  post_id: string
  drops_at: string
}

export interface CreatorProfileForm {
  display_name: string
  username: string
  bio: string
  subscription_price: number
  ticket_link: string
  instagram_handle: string
  twitter_handle: string
  tiktok_handle: string
  website_url: string
  message_price: number
}

// ============================================================
// MUX TYPES
// ============================================================
export interface MuxUpload {
  upload_id: string
  url: string
}

export interface MuxAsset {
  asset_id: string
  playback_id: string
  status: string
  duration: number | null
}

// ============================================================
// CHECKOUT TYPES
// ============================================================
export type CheckoutType = 'post' | 'bundle' | 'subscription' | 'message'

export interface CheckoutSession {
  checkout_url: string
  session_id: string
}
