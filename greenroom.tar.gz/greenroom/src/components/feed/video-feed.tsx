'use client'
import { useState, useRef, useEffect, useCallback } from 'react'
import { VideoCard } from './video-card'
import type { Post, Creator } from '@/types'
import { Mic2 } from 'lucide-react'

interface VideoFeedProps {
  posts: (Post & { creator: Creator })[]
  currentUserId?: string | null
}

export function VideoFeed({ posts, currentUserId }: VideoFeedProps) {
  const [activeIndex, setActiveIndex] = useState(0)
  const containerRef = useRef<HTMLDivElement>(null)
  const observerRef = useRef<IntersectionObserver | null>(null)

  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    observerRef.current = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            const index = parseInt(entry.target.getAttribute('data-index') || '0')
            setActiveIndex(index)
          }
        })
      },
      { root: container, threshold: 0.6 }
    )

    const items = container.querySelectorAll('[data-index]')
    items.forEach(item => observerRef.current?.observe(item))

    return () => observerRef.current?.disconnect()
  }, [posts])

  if (posts.length === 0) {
    return (
      <div className="h-dvh flex flex-col items-center justify-center text-center px-8 bg-gr-bg">
        <Mic2 className="w-16 h-16 text-gr-accent mb-4 opacity-50" />
        <h2 className="font-display text-2xl font-bold mb-2">No sets yet</h2>
        <p className="text-gr-dim">Check back soon — comedians are uploading.</p>
      </div>
    )
  }

  return (
    <div
      ref={containerRef}
      className="feed-container no-scrollbar"
    >
      {posts.map((post, i) => (
        <div key={post.id} data-index={i} className="feed-item">
          <VideoCard
            post={post}
            isActive={activeIndex === i}
            currentUserId={currentUserId}
          />
        </div>
      ))}
    </div>
  )
}
