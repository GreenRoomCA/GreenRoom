'use client'
import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { createClient } from '@/lib/supabase/client'
import { PaywallModal } from '@/components/paywall/paywall-modal'
import { CategoryBadge, Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { formatPrice, formatCount, formatShowDate, cn } from '@/lib/utils'
import type { Post, Creator, Bundle } from '@/types'
import { Heart, MapPin, Calendar, Ticket, Share2, Lock, Play, ChevronDown } from 'lucide-react'

interface VideoCardProps {
  post: Post & { creator: Creator }
  isActive: boolean
  currentUserId?: string | null
}

export function VideoCard({ post, isActive, currentUserId }: VideoCardProps) {
  const [liked, setLiked] = useState(post.is_liked || false)
  const [likeCount, setLikeCount] = useState(post.like_count)
  const [following, setFollowing] = useState(false)
  const [showPaywall, setShowPaywall] = useState(false)
  const [bundles, setBundles] = useState<Bundle[]>([])
  const [showPlayer, setShowPlayer] = useState(false)
  const [MuxPlayer, setMuxPlayer] = useState<any>(null)
  const supabase = createClient()

  useEffect(() => {
    import('@mux/mux-player-react').then(mod => setMuxPlayer(() => mod.default))
  }, [])

  const handleLike = async () => {
    if (!currentUserId) {
      window.location.href = '/auth/login'
      return
    }
    if (liked) {
      await supabase.from('likes').delete().eq('user_id', currentUserId).eq('post_id', post.id)
      setLiked(false)
      setLikeCount(c => c - 1)
    } else {
      await supabase.from('likes').insert({ user_id: currentUserId, post_id: post.id })
      setLiked(true)
      setLikeCount(c => c + 1)
    }
  }

  const handleFollow = async () => {
    if (!currentUserId) {
      window.location.href = '/auth/login'
      return
    }
    if (following) {
      await supabase.from('follows').delete().eq('user_id', currentUserId).eq('creator_id', post.creator_id)
      setFollowing(false)
    } else {
      await supabase.from('follows').insert({ user_id: currentUserId, creator_id: post.creator_id })
      setFollowing(true)
    }
  }

  const handleUnlock = async () => {
    if (!currentUserId) {
      window.location.href = '/auth/login'
      return
    }
    if (post.has_access) {
      window.location.href = `/watch/${post.id}`
      return
    }
    // Load bundles
    const { data } = await supabase
      .from('bundles')
      .select('*, bundle_posts!inner(post_id)')
      .eq('bundle_posts.post_id', post.id)
      .eq('is_active', true)
    setBundles(data || [])
    setShowPaywall(true)
  }

  const handleShare = async () => {
    const url = `${window.location.origin}/post/${post.id}`
    if (navigator.share) {
      await navigator.share({ title: post.title, url })
    } else {
      await navigator.clipboard.writeText(url)
    }
  }

  return (
    <div className="feed-item relative h-dvh w-full bg-black flex items-center justify-center overflow-hidden">
      {/* Background video / thumbnail */}
      {post.preview_mux_playback_id && MuxPlayer && isActive ? (
        <div className="absolute inset-0" onContextMenu={e => e.preventDefault()}>
          <MuxPlayer
            playbackId={post.preview_mux_playback_id}
            autoPlay
            muted
            loop
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            streamType="on-demand"
            controls={false}
          />
        </div>
      ) : post.thumbnail_url ? (
        <Image src={post.thumbnail_url} alt={post.title} fill className="object-cover" />
      ) : (
        <div className="absolute inset-0 bg-gr-surface" />
      )}

      {/* Dark gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-black/20" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/40 to-transparent" />

      {/* Right action bar */}
      <div className="absolute right-3 bottom-32 flex flex-col items-center gap-5 z-10">
        {/* Creator avatar */}
        <Link href={`/creator/${post.creator.username}`} className="flex flex-col items-center gap-1">
          <div className="w-11 h-11 rounded-full border-2 border-gr-accent overflow-hidden bg-gr-muted">
            {post.creator.profile_image_url ? (
              <Image src={post.creator.profile_image_url} alt={post.creator.display_name} width={44} height={44} className="object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-sm font-bold text-gr-accent">
                {post.creator.display_name[0]}
              </div>
            )}
          </div>
        </Link>

        {/* Like */}
        <button onClick={handleLike} className="flex flex-col items-center gap-1">
          <Heart className={cn('w-7 h-7 transition-colors', liked ? 'fill-gr-red text-gr-red' : 'text-white')} />
          <span className="text-white text-xs">{formatCount(likeCount)}</span>
        </button>

        {/* Share */}
        <button onClick={handleShare} className="flex flex-col items-center gap-1">
          <Share2 className="w-6 h-6 text-white" />
          <span className="text-white text-xs">Share</span>
        </button>

        {/* Ticket link */}
        {post.creator.ticket_link && (
          <a href={post.creator.ticket_link} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-1">
            <Ticket className="w-6 h-6 text-white" />
            <span className="text-white text-xs">Tickets</span>
          </a>
        )}
      </div>

      {/* Bottom metadata */}
      <div className="absolute bottom-20 left-0 right-16 px-4 z-10">
        {/* Creator + follow */}
        <div className="flex items-center gap-2 mb-2">
          <Link href={`/creator/${post.creator.username}`} className="font-display font-bold text-white text-base hover:text-gr-accent transition-colors">
            {post.creator.display_name}
          </Link>
          <button
            onClick={handleFollow}
            className={cn(
              'text-xs px-2 py-0.5 border rounded-sm transition-colors',
              following
                ? 'border-gr-dim text-gr-dim'
                : 'border-gr-accent text-gr-accent hover:bg-gr-accent/10'
            )}
          >
            {following ? 'Following' : 'Follow'}
          </button>
        </div>

        <h3 className="text-white font-medium text-sm mb-1 line-clamp-1">{post.title}</h3>

        {/* Show metadata */}
        <div className="flex items-center gap-3 text-white/60 text-xs mb-3">
          {post.city && (
            <span className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              {post.city}{post.venue ? ` · ${post.venue}` : ''}
            </span>
          )}
          {post.show_date && (
            <span className="flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              {formatShowDate(post.show_date)}
            </span>
          )}
        </div>

        {/* Category */}
        <div className="mb-3">
          <CategoryBadge category={post.category} />
        </div>

        {/* Unlock / Watch CTA */}
        {post.has_access ? (
          <Link href={`/watch/${post.id}`}>
            <Button size="lg" className="w-full gap-2">
              <Play className="w-4 h-4" />
              Watch Full Set
            </Button>
          </Link>
        ) : (
          <Button size="lg" className="w-full gap-2" onClick={handleUnlock}>
            <Lock className="w-4 h-4" />
            Unlock Full Set — {formatPrice(post.price)}
          </Button>
        )}

        {/* Missed the show prompt */}
        <p className="text-white/40 text-xs text-center mt-2">
          Missed the show? Watch the full set here.
        </p>
      </div>

      {/* Scroll hint */}
      {isActive && (
        <div className="absolute top-4 right-1/2 translate-x-1/2 text-white/30 animate-bounce">
          <ChevronDown className="w-5 h-5" />
        </div>
      )}

      {showPaywall && (
        <PaywallModal
          post={post}
          creator={post.creator}
          availableBundles={bundles}
          onClose={() => setShowPaywall(false)}
        />
      )}
    </div>
  )
}
