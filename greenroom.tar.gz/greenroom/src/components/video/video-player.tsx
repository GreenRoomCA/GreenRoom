'use client'
import { useEffect, useRef, useState } from 'react'

interface VideoPlayerProps {
  playbackId: string
  token?: string
  autoPlay?: boolean
  muted?: boolean
  loop?: boolean
  watermark?: boolean
  className?: string
  onEnded?: () => void
}

export function VideoPlayer({
  playbackId,
  token,
  autoPlay = false,
  muted = false,
  loop = false,
  watermark = false,
  className = '',
  onEnded,
}: VideoPlayerProps) {
  const [MuxPlayer, setMuxPlayer] = useState<any>(null)

  useEffect(() => {
    import('@mux/mux-player-react').then(mod => setMuxPlayer(() => mod.default))
  }, [])

  if (!MuxPlayer) {
    return (
      <div className={`bg-gr-surface flex items-center justify-center ${className}`}>
        <div className="w-8 h-8 border-2 border-gr-accent border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  return (
    <div className={`relative ${className}`} onContextMenu={e => e.preventDefault()}>
      <MuxPlayer
        playbackId={playbackId}
        tokens={token ? { playback: token } : undefined}
        autoPlay={autoPlay}
        muted={muted}
        loop={loop}
        onEnded={onEnded}
        style={{ width: '100%', height: '100%', aspectRatio: '9/16' }}
        streamType="on-demand"
      />
      {watermark && (
        <div className="absolute bottom-16 right-3 text-white/30 text-xs font-body pointer-events-none select-none">
          Full set on GreenRoom
        </div>
      )}
    </div>
  )
}

// Preview autoplay video for feed
export function PreviewVideo({
  playbackId,
  isActive,
  className = '',
}: {
  playbackId: string
  isActive: boolean
  className?: string
}) {
  const [MuxPlayer, setMuxPlayer] = useState<any>(null)

  useEffect(() => {
    import('@mux/mux-player-react').then(mod => setMuxPlayer(() => mod.default))
  }, [])

  if (!MuxPlayer) return (
    <div className={`bg-gr-surface ${className}`} />
  )

  return (
    <div className={`relative ${className}`} onContextMenu={e => e.preventDefault()}>
      <MuxPlayer
        playbackId={playbackId}
        autoPlay={isActive}
        muted
        loop
        style={{ width: '100%', height: '100%' }}
        streamType="on-demand"
        controls={false}
      />
    </div>
  )
}
