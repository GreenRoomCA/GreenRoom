'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'
import type { User } from '@/types'
import { Home, Library, User as UserIcon, LayoutDashboard, LogOut, Mic2 } from 'lucide-react'

export function Navbar() {
  const pathname = usePathname()
  const [user, setUser] = useState<any>(null)
  const [userRole, setUserRole] = useState<string>('viewer')
  const supabase = createClient()

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user)
      if (user) {
        supabase.from('users').select('role').eq('id', user.id).single()
          .then(({ data }) => { if (data) setUserRole(data.role) })
      }
    })
  }, [])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    window.location.href = '/'
  }

  // Hide navbar on feed (it has its own overlay nav)
  if (pathname === '/feed') return null

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 border-b border-gr-border bg-gr-bg/90 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <Mic2 className="w-5 h-5 text-gr-accent" />
          <span className="font-display text-lg font-bold text-gr-text tracking-tight">GreenRoom</span>
        </Link>

        <div className="flex items-center gap-1">
          <Link href="/feed" className={cn(
            'px-3 py-1.5 text-sm transition-colors',
            pathname === '/feed' ? 'text-gr-accent' : 'text-gr-dim hover:text-gr-text'
          )}>
            Feed
          </Link>

          {user ? (
            <>
              <Link href="/library" className={cn(
                'px-3 py-1.5 text-sm transition-colors',
                pathname === '/library' ? 'text-gr-accent' : 'text-gr-dim hover:text-gr-text'
              )}>
                Library
              </Link>
              {userRole === 'creator' && (
                <Link href="/dashboard" className={cn(
                  'px-3 py-1.5 text-sm transition-colors',
                  pathname.startsWith('/dashboard') ? 'text-gr-accent' : 'text-gr-dim hover:text-gr-text'
                )}>
                  Dashboard
                </Link>
              )}
              <Link href="/settings" className="p-2 text-gr-dim hover:text-gr-text transition-colors">
                <UserIcon className="w-4 h-4" />
              </Link>
              <button onClick={handleSignOut} className="p-2 text-gr-dim hover:text-gr-text transition-colors">
                <LogOut className="w-4 h-4" />
              </button>
            </>
          ) : (
            <>
              <Link href="/auth/login" className="px-3 py-1.5 text-sm text-gr-dim hover:text-gr-text transition-colors">
                Log in
              </Link>
              <Link href="/auth/signup" className="px-3 py-2 text-xs font-medium bg-gr-accent text-gr-bg rounded-sm hover:bg-gr-accent-dim transition-colors">
                Sign up
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  )
}

// Mobile bottom nav for feed
export function MobileNav() {
  const pathname = usePathname()
  const [user, setUser] = useState<any>(null)
  const [userRole, setUserRole] = useState<string>('viewer')
  const supabase = createClient()

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      setUser(user)
      if (user) {
        supabase.from('users').select('role').eq('id', user.id).single()
          .then(({ data }) => { if (data) setUserRole(data.role) })
      }
    })
  }, [])

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 border-t border-gr-border bg-gr-bg/95 backdrop-blur-md md:hidden">
      <div className="flex items-center justify-around h-16">
        <Link href="/feed" className={cn('flex flex-col items-center gap-1 p-2', pathname === '/feed' ? 'text-gr-accent' : 'text-gr-dim')}>
          <Home className="w-5 h-5" />
          <span className="text-xs">Feed</span>
        </Link>
        {user ? (
          <>
            <Link href="/library" className={cn('flex flex-col items-center gap-1 p-2', pathname === '/library' ? 'text-gr-accent' : 'text-gr-dim')}>
              <Library className="w-5 h-5" />
              <span className="text-xs">Library</span>
            </Link>
            {userRole === 'creator' && (
              <Link href="/dashboard" className={cn('flex flex-col items-center gap-1 p-2', pathname.startsWith('/dashboard') ? 'text-gr-accent' : 'text-gr-dim')}>
                <LayoutDashboard className="w-5 h-5" />
                <span className="text-xs">Dashboard</span>
              </Link>
            )}
            <Link href="/settings" className={cn('flex flex-col items-center gap-1 p-2', pathname === '/settings' ? 'text-gr-accent' : 'text-gr-dim')}>
              <UserIcon className="w-5 h-5" />
              <span className="text-xs">Profile</span>
            </Link>
          </>
        ) : (
          <Link href="/auth/login" className="flex flex-col items-center gap-1 p-2 text-gr-dim">
            <UserIcon className="w-5 h-5" />
            <span className="text-xs">Sign in</span>
          </Link>
        )}
      </div>
    </div>
  )
}
