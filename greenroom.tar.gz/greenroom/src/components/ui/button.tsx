import { cn } from '@/lib/utils'
import { forwardRef } from 'react'

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline'
  size?: 'sm' | 'md' | 'lg'
  loading?: boolean
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(({
  className,
  variant = 'primary',
  size = 'md',
  loading,
  disabled,
  children,
  ...props
}, ref) => {
  const base = 'inline-flex items-center justify-center gap-2 font-body font-medium transition-all duration-200 rounded-sm disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap'

  const variants = {
    primary: 'bg-gr-accent text-gr-bg hover:bg-gr-accent-dim active:scale-95',
    secondary: 'bg-gr-muted text-gr-text hover:bg-gr-border active:scale-95',
    ghost: 'text-gr-dim hover:text-gr-text hover:bg-gr-surface active:scale-95',
    danger: 'bg-gr-red text-white hover:bg-red-700 active:scale-95',
    outline: 'border border-gr-border text-gr-text hover:border-gr-dim active:scale-95',
  }

  const sizes = {
    sm: 'text-xs px-3 py-1.5',
    md: 'text-sm px-4 py-2.5',
    lg: 'text-base px-6 py-3',
  }

  return (
    <button
      ref={ref}
      disabled={disabled || loading}
      className={cn(base, variants[variant], sizes[size], className)}
      {...props}
    >
      {loading && (
        <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
        </svg>
      )}
      {children}
    </button>
  )
})

Button.displayName = 'Button'
export { Button }
