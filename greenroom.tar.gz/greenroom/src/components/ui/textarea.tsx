import { cn } from '@/lib/utils'
import { forwardRef } from 'react'

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label?: string
  error?: string
  hint?: string
}

const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(({
  className, label, error, hint, id, ...props
}, ref) => {
  const inputId = id || label?.toLowerCase().replace(/\s+/g, '-')
  return (
    <div className="space-y-1.5">
      {label && (
        <label htmlFor={inputId} className="block text-xs font-medium text-gr-dim uppercase tracking-wider">
          {label}
        </label>
      )}
      <textarea
        ref={ref}
        id={inputId}
        className={cn(
          'w-full bg-gr-surface border border-gr-border rounded-sm px-3 py-2.5 text-sm text-gr-text',
          'placeholder:text-gr-muted resize-none',
          'focus:outline-none focus:border-gr-accent focus:ring-1 focus:ring-gr-accent/30',
          'transition-colors duration-150',
          error && 'border-gr-red',
          className
        )}
        {...props}
      />
      {hint && !error && <p className="text-xs text-gr-dim">{hint}</p>}
      {error && <p className="text-xs text-gr-red">{error}</p>}
    </div>
  )
})

Textarea.displayName = 'Textarea'
export { Textarea }
