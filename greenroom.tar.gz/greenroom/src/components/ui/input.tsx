import { cn } from '@/lib/utils'
import { forwardRef } from 'react'

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  hint?: string
}

const Input = forwardRef<HTMLInputElement, InputProps>(({
  className, label, error, hint, id, ...props
}, ref) => {
  const inputId = id || label?.toLowerCase().replace(/\s+/g, '-')
  return (
    <div className="space-y-1.5">
      {label && (
        <label htmlFor={inputId} className="block text-xs font-medium text-gr-dim uppercase tracking-wider">
          {label}
        </label>
      )}
      <input
        ref={ref}
        id={inputId}
        className={cn(
          'w-full bg-gr-surface border border-gr-border rounded-sm px-3 py-2.5 text-sm text-gr-text',
          'placeholder:text-gr-muted',
          'focus:outline-none focus:border-gr-accent focus:ring-1 focus:ring-gr-accent/30',
          'transition-colors duration-150',
          error && 'border-gr-red focus:border-gr-red focus:ring-gr-red/30',
          className
        )}
        {...props}
      />
      {hint && !error && <p className="text-xs text-gr-dim">{hint}</p>}
      {error && <p className="text-xs text-gr-red">{error}</p>}
    </div>
  )
})

Input.displayName = 'Input'
export { Input }
