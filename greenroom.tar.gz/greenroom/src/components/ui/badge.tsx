import { cn, getBadgeLabel, getBadgeColor } from '@/lib/utils'
import type { BadgeLevel } from '@/types'

interface BadgeProps {
  level: BadgeLevel
  className?: string
}

export function Badge({ level, className }: BadgeProps) {
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 text-xs border rounded-sm font-medium',
      getBadgeColor(level),
      className
    )}>
      {getBadgeLabel(level)}
    </span>
  )
}

interface CategoryBadgeProps {
  category: string
  className?: string
}

export function CategoryBadge({ category, className }: CategoryBadgeProps) {
  return (
    <span className={cn(
      'inline-flex items-center px-2 py-0.5 text-xs bg-gr-muted text-gr-dim rounded-sm',
      className
    )}>
      {category}
    </span>
  )
}
