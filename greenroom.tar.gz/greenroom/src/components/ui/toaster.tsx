'use client'
import { useEffect, useState } from 'react'
import { cn } from '@/lib/utils'

interface Toast {
  id: string
  message: string
  type: 'success' | 'error' | 'info'
}

let addToastFn: ((toast: Omit<Toast, 'id'>) => void) | null = null

export function toast(message: string, type: Toast['type'] = 'info') {
  addToastFn?.({ message, type })
}

export function Toaster() {
  const [toasts, setToasts] = useState<Toast[]>([])

  useEffect(() => {
    addToastFn = (t) => {
      const id = Math.random().toString(36).slice(2)
      setToasts(prev => [...prev, { ...t, id }])
      setTimeout(() => setToasts(prev => prev.filter(x => x.id !== id)), 4000)
    }
    return () => { addToastFn = null }
  }, [])

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 pointer-events-none">
      {toasts.map(t => (
        <div key={t.id} className={cn(
          'px-4 py-3 rounded-sm text-sm font-medium shadow-lg animate-slide-up pointer-events-auto',
          t.type === 'success' && 'bg-gr-green text-black',
          t.type === 'error' && 'bg-gr-red text-white',
          t.type === 'info' && 'bg-gr-card border border-gr-border text-gr-text',
        )}>
          {t.message}
        </div>
      ))}
    </div>
  )
}
