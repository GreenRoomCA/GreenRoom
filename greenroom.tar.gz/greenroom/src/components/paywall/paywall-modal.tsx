'use client'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { formatPrice } from '@/lib/utils'
import type { Post, Creator, Bundle } from '@/types'
import { Lock, Zap, Crown, X } from 'lucide-react'
import { loadStripe } from '@stripe/stripe-js'

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY!)

interface PaywallModalProps {
  post: Post
  creator: Creator
  availableBundles?: Bundle[]
  onClose: () => void
}

export function PaywallModal({ post, creator, availableBundles = [], onClose }: PaywallModalProps) {
  const [loading, setLoading] = useState<string | null>(null)

  const handleBuyPost = async () => {
    setLoading('post')
    try {
      const res = await fetch('/api/stripe/checkout/post', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ postId: post.id }),
      })
      const { url, error } = await res.json()
      if (error) throw new Error(error)
      window.location.href = url
    } catch (e: any) {
      alert(e.message)
    } finally {
      setLoading(null)
    }
  }

  const handleSubscribe = async () => {
    setLoading('sub')
    try {
      const res = await fetch('/api/stripe/checkout/subscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ creatorId: creator.id }),
      })
      const { url, error } = await res.json()
      if (error) throw new Error(error)
      window.location.href = url
    } catch (e: any) {
      alert(e.message)
    } finally {
      setLoading(null)
    }
  }

  const handleBuyBundle = async (bundleId: string) => {
    setLoading(`bundle-${bundleId}`)
    try {
      const res = await fetch('/api/stripe/checkout/bundle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bundleId }),
      })
      const { url, error } = await res.json()
      if (error) throw new Error(error)
      window.location.href = url
    } catch (e: any) {
      alert(e.message)
    } finally {
      setLoading(null)
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-md bg-gr-card border border-gr-border rounded-sm overflow-hidden">
        {/* Header */}
        <div className="relative p-6 border-b border-gr-border">
          <button onClick={onClose} className="absolute top-4 right-4 text-gr-dim hover:text-gr-text transition-colors">
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-full bg-gr-muted flex items-center justify-center">
              <Lock className="w-5 h-5 text-gr-accent" />
            </div>
            <div>
              <p className="text-xs text-gr-dim uppercase tracking-wider">Full Set Locked</p>
              <h2 className="font-display text-lg font-bold">{post.title}</h2>
            </div>
          </div>
          <p className="text-sm text-gr-dim">
            {creator.display_name} · {post.city}{post.venue ? ` @ ${post.venue}` : ''}
          </p>
        </div>

        {/* Options */}
        <div className="p-6 space-y-3">
          {/* Buy this set */}
          {post.is_one_time_purchase_enabled && (
            <div className="border border-gr-border rounded-sm p-4 hover:border-gr-dim transition-colors">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-gr-accent" />
                  <span className="text-sm font-medium">Buy This Set</span>
                </div>
                <span className="text-lg font-display font-bold text-gr-accent">{formatPrice(post.price)}</span>
              </div>
              <p className="text-xs text-gr-dim mb-3">Permanent access to this full set.</p>
              <Button
                className="w-full"
                onClick={handleBuyPost}
                loading={loading === 'post'}
              >
                Buy for {formatPrice(post.price)}
              </Button>
            </div>
          )}

          {/* Subscribe */}
          {post.is_subscription_included && (
            <div className="border border-gr-accent/40 rounded-sm p-4 bg-gr-accent/5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Crown className="w-4 h-4 text-gr-accent" />
                  <span className="text-sm font-medium">Subscribe to {creator.display_name}</span>
                </div>
                <span className="text-lg font-display font-bold text-gr-accent">
                  {formatPrice(creator.subscription_price)}<span className="text-xs text-gr-dim">/mo</span>
                </span>
              </div>
              <p className="text-xs text-gr-dim mb-3">
                Unlock all {creator.display_name}'s sets included with subscription.
              </p>
              <Button
                className="w-full"
                variant="primary"
                onClick={handleSubscribe}
                loading={loading === 'sub'}
              >
                Subscribe — {formatPrice(creator.subscription_price)}/mo
              </Button>
            </div>
          )}

          {/* Bundles */}
          {availableBundles.map(bundle => (
            <div key={bundle.id} className="border border-gr-border rounded-sm p-4 hover:border-gr-dim transition-colors">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <span className="text-sm font-medium">{bundle.title}</span>
                  <span className="ml-2 text-xs text-gr-dim">Bundle</span>
                </div>
                <span className="text-base font-bold">{formatPrice(bundle.price)}</span>
              </div>
              {bundle.description && <p className="text-xs text-gr-dim mb-3">{bundle.description}</p>}
              <Button
                variant="outline"
                className="w-full"
                onClick={() => handleBuyBundle(bundle.id)}
                loading={loading === `bundle-${bundle.id}`}
              >
                Buy Bundle — {formatPrice(bundle.price)}
              </Button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
