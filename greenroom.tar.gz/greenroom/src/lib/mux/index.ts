import Mux from '@mux/mux-node'

export const mux = new Mux({
  tokenId: process.env.MUX_TOKEN_ID!,
  tokenSecret: process.env.MUX_TOKEN_SECRET!,
})

export async function createUploadUrl(isPreview: boolean = false): Promise<{
  upload_id: string
  url: string
}> {
  const upload = await mux.video.uploads.create({
    cors_origin: process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000',
    new_asset_settings: {
      playback_policy: ['signed'],
      max_resolution_tier: '1080p',
      ...(isPreview && { max_resolution_tier: '720p' }),
    },
  })

  return { upload_id: upload.id, url: upload.url }
}

export async function getAsset(assetId: string) {
  return mux.video.assets.retrieve(assetId)
}

export async function deleteAsset(assetId: string) {
  await mux.video.assets.delete(assetId)
}

export async function createSignedPlaybackUrl(playbackId: string): Promise<string> {
  const token = await mux.jwt.signPlaybackId(playbackId, {
    type: 'video',
    expiration: '6h',
  })
  return `https://stream.mux.com/${playbackId}.m3u8?token=${token}`
}

export async function createSignedThumbnailUrl(playbackId: string): Promise<string> {
  const token = await mux.jwt.signPlaybackId(playbackId, {
    type: 'thumbnail',
    expiration: '24h',
  })
  return `https://image.mux.com/${playbackId}/thumbnail.jpg?token=${token}`
}

export function getPublicThumbnailUrl(playbackId: string): string {
  return `https://image.mux.com/${playbackId}/thumbnail.jpg`
}
