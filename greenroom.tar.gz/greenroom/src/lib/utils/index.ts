import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { formatDistanceToNow, format } from 'date-fns'
import type { AccessResult } from '@/types'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatPrice(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount)
}

export function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${m}:${s.toString().padStart(2, '0')}`
}

export function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return n.toString()
}

export function formatRelativeTime(date: string): string {
  return formatDistanceToNow(new Date(date), { addSuffix: true })
}

export function formatShowDate(date: string): string {
  return format(new Date(date), 'MMM d, yyyy')
}

export function getBadgeLabel(level: string): string {
  const labels: Record<string, string> = {
    supporter: 'Supporter',
    real_fan: 'Real Fan',
    top_supporter: '⭐ Top Supporter',
    day_one: '🔥 Day One',
  }
  return labels[level] || level
}

export function getBadgeColor(level: string): string {
  const colors: Record<string, string> = {
    supporter: 'text-gr-dim border-gr-dim',
    real_fan: 'text-blue-400 border-blue-400',
    top_supporter: 'text-gr-accent border-gr-accent',
    day_one: 'text-gr-red border-gr-red',
  }
  return colors[level] || 'text-gr-dim border-gr-dim'
}

export function getPricingGuidance(price: number): string {
  if (price <= 8) return 'New / Open Mic Range'
  if (price <= 20) return 'Working Comic Range'
  return 'Established Comic Range'
}

export function getPublicUrl(path: string): string {
  return `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}${path}`
}

export const CATEGORIES = [
  'Full Set',
  'Crowd Work',
  'Unreleased',
  'Test Material',
  'Special',
  'Behind the Scenes',
] as const
