import { createClient } from '@/lib/supabase/server'
import type { AccessResult } from '@/types'

export async function canUserAccessPost(
  userId: string | null,
  postId: string
): Promise<AccessResult> {
  const supabase = await createClient()

  // Get post details
  const { data: post } = await supabase
    .from('posts')
    .select('price, is_subscription_included, creator_id, creators(user_id)')
    .eq('id', postId)
    .single()

  if (!post) return { has_access: false }

  // Free post
  if (post.price === 0) return { has_access: true, reason: 'free' }

  if (!userId) return { has_access: false }

  // Owner check
  const creator = post.creators as any
  if (creator?.user_id === userId) {
    return { has_access: true, reason: 'owner' }
  }

  // Direct purchase
  const { data: purchase } = await supabase
    .from('purchases')
    .select('id')
    .eq('user_id', userId)
    .eq('post_id', postId)
    .maybeSingle()

  if (purchase) return { has_access: true, reason: 'purchased' }

  // Bundle purchase
  const { data: bundlePurchase } = await supabase
    .from('bundle_purchases')
    .select('id')
    .eq('user_id', userId)
    .in('bundle_id',
      supabase
        .from('bundle_posts')
        .select('bundle_id')
        .eq('post_id', postId)
    )
    .maybeSingle()

  if (bundlePurchase) return { has_access: true, reason: 'bundle' }

  // Active subscription
  if (post.is_subscription_included) {
    const { data: sub } = await supabase
      .from('subscriptions')
      .select('id')
      .eq('user_id', userId)
      .eq('creator_id', post.creator_id)
      .eq('status', 'active')
      .maybeSingle()

    if (sub) return { has_access: true, reason: 'subscription' }
  }

  return { has_access: false }
}
