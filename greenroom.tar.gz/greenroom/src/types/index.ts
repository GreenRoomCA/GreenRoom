export type UserRole = 'viewer' | 'creator' | 'admin'
export type PostStatus = 'draft' | 'published' | 'scheduled'
export type ViewType = 'preview' | 'full'
export type SubscriptionStatus = 'active' | 'canceled' | 'past_due' | 'incomplete'
export type BadgeLevel = 'supporter' | 'real_fan' | 'top_supporter' | 'day_one'

export interface User {
  id: string
  email: string
  role: UserRole
  username?: string
  display_name?: string
  avatar_url?: string
  created_at: string
}

export interface Creator {
  id: string
  user_id: string
  display_name: string
  username: string
  bio?: string
  profile_image_url?: string
  banner_image_url?: string
  subscription_price: number
  stripe_account_id?: string
  stripe_account_enabled: boolean
  ticket_link?: string
  message_price: number
  watermark_enabled: boolean
  created_at: string
  // computed
  follower_count?: number
  is_following?: boolean
}

export interface Post {
  id: string
  creator_id: string
  title: string
  description?: string
  preview_video_url?: string
  preview_mux_asset_id?: string
  preview_mux_playback_id?: string
  full_video_url?: string
  full_mux_asset_id?: string
  full_mux_playback_id?: string
  thumbnail_url?: string
  duration_seconds?: number
  preview_duration_seconds?: number
  price: number
  is_subscription_included: boolean
  is_one_time_purchase_enabled: boolean
  is_premium_add_on: boolean
  category: string
  city?: string
  venue?: string
  show_date?: string
  status: PostStatus
  scheduled_release_at?: string
  view_count: number
  like_count: number
  purchase_count: number
  created_at: string
  // joined
  creator?: Creator
  is_liked?: boolean
  is_purchased?: boolean
  has_access?: boolean
}

export interface Purchase {
  id: string
  user_id: string
  post_id: string
  creator_id: string
  stripe_payment_intent_id?: string
  price_paid: number
  created_at: string
  post?: Post
}

export interface Subscription {
  id: string
  user_id: string
  creator_id: string
  stripe_subscription_id?: string
  stripe_customer_id?: string
  status: SubscriptionStatus
  current_period_end?: string
  canceled_at?: string
  created_at: string
  creator?: Creator
}

export interface Bundle {
  id: string
  creator_id: string
  title: string
  description?: string
  price: number
  thumbnail_url?: string
  is_active: boolean
  created_at: string
  creator?: Creator
  posts?: Post[]
  post_count?: number
}

export interface BundlePurchase {
  id: string
  user_id: string
  bundle_id: string
  creator_id: string
  stripe_payment_intent_id?: string
  price_paid: number
  created_at: string
}

export interface Follow {
  id: string
  user_id: string
  creator_id: string
  created_at: string
}

export interface FanSpend {
  id: string
  user_id: string
  creator_id: string
  total_spent: number
  badge_level?: BadgeLevel
  updated_at: string
}

export interface Message {
  id: string
  sender_id: string
  receiver_id: string
  creator_id: string
  body: string
  is_paid: boolean
  price_paid: number
  stripe_payment_intent_id?: string
  read_at?: string
  created_at: string
  sender?: User
}

export interface Drop {
  id: string
  post_id: string
  creator_id: string
  release_at: string
  teaser_text?: string
  created_at: string
  post?: Post
}

export interface Analytics {
  total_preview_views: number
  total_full_views: number
  total_purchases: number
  total_revenue: number
  total_subscribers: number
  posts: PostAnalytics[]
  top_supporters: TopSupporter[]
}

export interface PostAnalytics {
  post_id: string
  title: string
  preview_views: number
  full_views: number
  purchases: number
  revenue: number
  conversion_rate: number
}

export interface TopSupporter {
  user_id: string
  display_name?: string
  avatar_url?: string
  total_spent: number
  badge_level?: BadgeLevel
}

// Access check result
export interface AccessResult {
  has_access: boolean
  reason?: 'free' | 'purchased' | 'bundle' | 'subscription' | 'owner'
}
