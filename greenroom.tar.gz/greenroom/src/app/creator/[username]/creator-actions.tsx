'use client'
import { useState } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { formatPrice } from '@/lib/utils'
import type { Creator } from '@/types'

interface Props {
  creator: Creator
  isFollowing: boolean
  isSubscribed: boolean
  currentUserId: string | null
}

export function CreatorActionButtons({ creator, isFollowing: initFollowing, isSubscribed, currentUserId }: Props) {
  const supabase = createClient()
  const [following, setFollowing] = useState(initFollowing)
  const [loading, setLoading] = useState<string | null>(null)

  const handleFollow = async () => {
    if (!currentUserId) { window.location.href = '/auth/login'; return }
    if (following) {
      await supabase.from('follows').delete().eq('user_id', currentUserId).eq('creator_id', creator.id)
      setFollowing(false)
    } else {
      await supabase.from('follows').insert({ user_id: currentUserId, creator_id: creator.id })
      setFollowing(true)
    }
  }

  const handleSubscribe = async () => {
    if (!currentUserId) { window.location.href = '/auth/login'; return }
    setLoading('sub')
    const res = await fetch('/api/stripe/checkout/subscription', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ creatorId: creator.id }),
    })
    const { url, error } = await res.json()
    if (url) window.location.href = url
    else setLoading(null)
  }

  return (
    <div className="flex items-center gap-2 flex-wrap">
      <Button
        variant={following ? 'secondary' : 'outline'}
        onClick={handleFollow}
      >
        {following ? 'Following' : 'Follow'}
      </Button>
      {!isSubscribed && (
        <Button onClick={handleSubscribe} loading={loading === 'sub'}>
          Subscribe · {formatPrice(creator.subscription_price)}/mo
        </Button>
      )}
      {isSubscribed && (
        <span className="text-sm text-gr-green border border-gr-green/30 px-3 py-2 rounded-sm">
          ✓ Subscribed
        </span>
      )}
    </div>
  )
}
