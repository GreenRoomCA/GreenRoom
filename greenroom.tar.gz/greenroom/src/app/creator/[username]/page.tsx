import { createClient } from '@/lib/supabase/server'
import { notFound } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import { formatPrice, formatCount, formatShowDate } from '@/lib/utils'
import { Badge, CategoryBadge } from '@/components/ui/badge'
import { MapPin, Calendar, Ticket, Lock, Play } from 'lucide-react'
import { CreatorActionButtons } from './creator-actions'
import type { Post, Creator } from '@/types'

interface Props {
  params: { username: string }
}

export default async function CreatorProfilePage({ params }: Props) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: creator } = await supabase
    .from('creators')
    .select('*')
    .eq('username', params.username)
    .single()

  if (!creator) notFound()

  const [postsRes, followRes, subRes, followCountRes] = await Promise.all([
    supabase.from('posts').select('*').eq('creator_id', creator.id).eq('status', 'published').order('created_at', { ascending: false }),
    user ? supabase.from('follows').select('id').eq('user_id', user.id).eq('creator_id', creator.id).maybeSingle() : Promise.resolve({ data: null }),
    user ? supabase.from('subscriptions').select('status').eq('user_id', user.id).eq('creator_id', creator.id).maybeSingle() : Promise.resolve({ data: null }),
    supabase.from('follows').select('id', { count: 'exact' }).eq('creator_id', creator.id),
  ])

  const posts = postsRes.data || []
  const isFollowing = !!followRes.data
  const isSubscribed = subRes.data?.status === 'active'
  const followerCount = followCountRes.count || 0

  // Check access for each post
  let accessibleIds = new Set<string>()
  if (user) {
    const isOwner = creator.user_id === user.id
    if (isOwner) {
      posts.forEach(p => accessibleIds.add(p.id))
    } else {
      const [purchasesRes, bundlePurchasesRes] = await Promise.all([
        supabase.from('purchases').select('post_id').eq('user_id', user.id).eq('creator_id', creator.id),
        supabase.from('bundle_purchases').select('bundle_id').eq('user_id', user.id).eq('creator_id', creator.id),
      ])
      const purchasedPostIds = new Set(purchasesRes.data?.map(p => p.post_id) || [])
      posts.forEach(p => {
        if (purchasedPostIds.has(p.id)) accessibleIds.add(p.id)
        if (p.is_subscription_included && isSubscribed) accessibleIds.add(p.id)
        if (p.price === 0) accessibleIds.add(p.id)
      })
    }
  } else {
    posts.forEach(p => { if (p.price === 0) accessibleIds.add(p.id) })
  }

  return (
    <div className="min-h-screen bg-gr-bg">
      {/* Banner */}
      <div className="h-48 sm:h-64 bg-gr-surface relative overflow-hidden">
        {creator.banner_image_url ? (
          <Image src={creator.banner_image_url} alt="" fill className="object-cover opacity-60" />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-gr-muted to-gr-surface" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-gr-bg via-gr-bg/20 to-transparent" />
      </div>

      {/* Profile header */}
      <div className="max-w-4xl mx-auto px-4 -mt-16 relative z-10">
        <div className="flex items-end gap-4 mb-6">
          <div className="w-24 h-24 rounded-full border-4 border-gr-bg bg-gr-card overflow-hidden flex-shrink-0">
            {creator.profile_image_url ? (
              <Image src={creator.profile_image_url} alt={creator.display_name} width={96} height={96} className="object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center text-3xl font-display font-bold text-gr-accent">
                {creator.display_name[0]}
              </div>
            )}
          </div>
          <div className="flex-1 pb-2">
            <h1 className="font-display text-2xl sm:text-3xl font-bold">{creator.display_name}</h1>
            <p className="text-gr-dim text-sm">@{creator.username}</p>
          </div>
        </div>

        {creator.bio && <p className="text-gr-dim mb-4 max-w-xl">{creator.bio}</p>}

        <div className="flex items-center gap-4 mb-6">
          <span className="text-sm"><span className="font-bold">{formatCount(followerCount)}</span> <span className="text-gr-dim">followers</span></span>
          <span className="text-sm"><span className="font-bold">{posts.length}</span> <span className="text-gr-dim">sets</span></span>
        </div>

        <CreatorActionButtons
          creator={creator}
          isFollowing={isFollowing}
          isSubscribed={isSubscribed}
          currentUserId={user?.id || null}
        />

        {creator.ticket_link && (
          <a href={creator.ticket_link} target="_blank" rel="noopener noreferrer"
            className="mt-3 inline-flex items-center gap-2 text-sm text-gr-dim hover:text-gr-text transition-colors">
            <Ticket className="w-4 h-4" />
            See live shows
          </a>
        )}
      </div>

      {/* Sets grid */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h2 className="font-display text-xl font-bold mb-4">Sets</h2>

        {posts.length > 0 ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {posts.map(post => {
              const hasAccess = accessibleIds.has(post.id)
              return (
                <Link key={post.id} href={hasAccess ? `/watch/${post.id}` : `/post/${post.id}`}
                  className="group bg-gr-card border border-gr-border rounded-sm overflow-hidden hover:border-gr-dim transition-colors">
                  {/* Thumbnail */}
                  <div className="aspect-video bg-gr-surface relative overflow-hidden">
                    {post.thumbnail_url ? (
                      <Image src={post.thumbnail_url} alt={post.title} fill className="object-cover group-hover:scale-105 transition-transform duration-300" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <div className="text-4xl text-gr-dim/20">🎤</div>
                      </div>
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                    <div className="absolute top-2 left-2">
                      <CategoryBadge category={post.category} />
                    </div>
                    {!hasAccess && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-10 h-10 rounded-full bg-black/60 flex items-center justify-center">
                          <Lock className="w-5 h-5 text-gr-accent" />
                        </div>
                      </div>
                    )}
                    {hasAccess && (
                      <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="w-8 h-8 rounded-full bg-gr-accent flex items-center justify-center">
                          <Play className="w-4 h-4 text-gr-bg" />
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="p-3">
                    <h3 className="font-medium text-sm mb-1 line-clamp-1">{post.title}</h3>
                    <div className="flex items-center gap-2 text-xs text-gr-dim">
                      {post.city && <span className="flex items-center gap-0.5"><MapPin className="w-3 h-3" />{post.city}</span>}
                      {post.show_date && <span>{formatShowDate(post.show_date)}</span>}
                    </div>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-gr-dim">{post.view_count} views</span>
                      {hasAccess ? (
                        <span className="text-xs text-gr-green">Unlocked</span>
                      ) : (
                        <span className="text-sm font-bold text-gr-accent">{formatPrice(post.price)}</span>
                      )}
                    </div>
                  </div>
                </Link>
              )
            })}
          </div>
        ) : (
          <div className="text-center py-16 border border-dashed border-gr-border rounded-sm">
            <p className="text-gr-dim">No sets uploaded yet.</p>
          </div>
        )}
      </div>
    </div>
  )
}
