'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Mic2 } from 'lucide-react'

export default function CreatorOnboarding() {
  const [step, setStep] = useState(1)
  const [displayName, setDisplayName] = useState('')
  const [username, setUsername] = useState('')
  const [bio, setBio] = useState('')
  const [subscriptionPrice, setSubscriptionPrice] = useState('9.99')
  const [ticketLink, setTicketLink] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const router = useRouter()
  const supabase = createClient()

  const handleSubmit = async () => {
    setLoading(true)
    setError('')

    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      router.push('/auth/login')
      return
    }

    // Check username availability
    const { data: existing } = await supabase
      .from('creators')
      .select('id')
      .eq('username', username.toLowerCase())
      .maybeSingle()

    if (existing) {
      setError('Username already taken')
      setLoading(false)
      return
    }

    // Create creator profile
    const { error: createError } = await supabase.from('creators').insert({
      user_id: user.id,
      display_name: displayName,
      username: username.toLowerCase().replace(/[^a-z0-9_]/g, ''),
      bio,
      subscription_price: parseFloat(subscriptionPrice),
      ticket_link: ticketLink || null,
    })

    if (createError) {
      setError(createError.message)
      setLoading(false)
      return
    }

    // Update user role to creator
    await supabase.from('users').update({ role: 'creator' }).eq('id', user.id)

    router.push('/dashboard')
  }

  return (
    <div className="min-h-screen bg-gr-bg flex items-center justify-center px-4 py-16">
      <div className="w-full max-w-lg">
        <div className="text-center mb-10">
          <Mic2 className="w-10 h-10 text-gr-accent mx-auto mb-4" />
          <h1 className="font-display text-3xl font-bold">Set up your GreenRoom</h1>
          <p className="text-gr-dim mt-2">Get your profile ready to start earning from your sets.</p>
        </div>

        {/* Progress */}
        <div className="flex gap-1 mb-10">
          {[1, 2, 3].map(s => (
            <div key={s} className={`h-1 flex-1 rounded-full transition-colors ${s <= step ? 'bg-gr-accent' : 'bg-gr-muted'}`} />
          ))}
        </div>

        {step === 1 && (
          <div className="space-y-5">
            <h2 className="font-display text-xl font-bold">Who are you?</h2>
            <Input
              label="Stage Name"
              value={displayName}
              onChange={e => setDisplayName(e.target.value)}
              placeholder="Your name on stage"
            />
            <Input
              label="Username"
              value={username}
              onChange={e => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''))}
              placeholder="your_handle"
              hint="greenroom.tv/@your_handle"
            />
            <Button
              className="w-full"
              size="lg"
              onClick={() => setStep(2)}
              disabled={!displayName || !username}
            >
              Continue
            </Button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-5">
            <h2 className="font-display text-xl font-bold">Tell fans about yourself</h2>
            <Textarea
              label="Bio"
              value={bio}
              onChange={e => setBio(e.target.value)}
              placeholder="Working comic based in NYC. Host of The Cellar Sessions. Seen on..."
              rows={4}
            />
            <Input
              label="Live Ticket Link (optional)"
              type="url"
              value={ticketLink}
              onChange={e => setTicketLink(e.target.value)}
              placeholder="https://dice.fm/your-shows"
              hint="Where fans can buy tickets to see you live"
            />
            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(1)}>Back</Button>
              <Button className="flex-1" size="lg" onClick={() => setStep(3)}>Continue</Button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-5">
            <h2 className="font-display text-xl font-bold">Set your subscription price</h2>
            <p className="text-gr-dim text-sm">
              Fans who subscribe get access to all your content marked "Subscription Included."
            </p>

            <Input
              label="Monthly Subscription Price (USD)"
              type="number"
              min="1"
              step="0.01"
              value={subscriptionPrice}
              onChange={e => setSubscriptionPrice(e.target.value)}
            />

            {/* Pricing guidance */}
            <div className="bg-gr-surface border border-gr-border rounded-sm p-4 text-sm space-y-2">
              <p className="text-gr-dim text-xs uppercase tracking-wider font-medium">Pricing guidance</p>
              <div className="text-gr-dim space-y-1">
                <p><span className="text-gr-text">$4–8/mo</span> · New / Open Mic</p>
                <p><span className="text-gr-text">$8–15/mo</span> · Working Comic</p>
                <p><span className="text-gr-text">$15+/mo</span> · Established / Touring</p>
              </div>
              <p className="text-xs text-gr-dim/60">This is informational only. Set any price you want.</p>
            </div>

            {error && (
              <div className="text-gr-red text-sm bg-gr-red/10 border border-gr-red/20 px-3 py-2 rounded-sm">
                {error}
              </div>
            )}

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep(2)}>Back</Button>
              <Button className="flex-1" size="lg" onClick={handleSubmit} loading={loading}>
                Launch My GreenRoom
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
