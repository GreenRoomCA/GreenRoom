import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase/server'
import { stripe, calculatePlatformFee, getOrCreateStripeCustomer } from '@/lib/stripe'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createServerClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { bundleId } = body

    if (!bundleId) {
      return NextResponse.json({ error: 'bundleId required' }, { status: 400 })
    }

    const { data: bundle } = await supabase
      .from('bundles')
      .select(`
        id, title, price,
        creators!inner (
          id, display_name, stripe_account_id
        )
      `)
      .eq('id', bundleId)
      .single()

    if (!bundle) {
      return NextResponse.json({ error: 'Bundle not found' }, { status: 404 })
    }

    const creator = bundle.creators as any
    if (!creator.stripe_account_id) {
      return NextResponse.json({ error: 'Creator has not set up payments' }, { status: 400 })
    }

    // Check not already purchased
    const { data: existing } = await supabase
      .from('bundle_purchases')
      .select('id')
      .eq('user_id', user.id)
      .eq('bundle_id', bundleId)
      .single()

    if (existing) {
      return NextResponse.json({ error: 'Already purchased' }, { status: 400 })
    }

    const customerId = await getOrCreateStripeCustomer(user.id, user.email!)
    const platformFee = calculatePlatformFee(bundle.price)
    const origin = request.headers.get('origin') || process.env.NEXT_PUBLIC_APP_URL

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: bundle.title,
              description: `Comedy bundle by ${creator.display_name}`,
            },
            unit_amount: bundle.price,
          },
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${origin}/checkout/success?type=bundle&bundleId=${bundleId}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/creator/${creator.display_name}`,
      payment_intent_data: {
        application_fee_amount: platformFee,
        transfer_data: {
          destination: creator.stripe_account_id,
        },
      },
      metadata: {
        type: 'bundle_purchase',
        bundle_id: bundleId,
        user_id: user.id,
        creator_id: creator.id,
      },
    })

    return NextResponse.json({ url: session.url })
  } catch (error) {
    console.error('Checkout bundle error:', error)
    return NextResponse.json({ error: 'Failed to create checkout session' }, { status: 500 })
  }
}
