import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase/server'
import { stripe, calculatePlatformFee, getOrCreateStripeCustomer } from '@/lib/stripe'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createServerClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { postId } = body

    if (!postId) {
      return NextResponse.json({ error: 'postId required' }, { status: 400 })
    }

    // Get post with creator info
    const { data: post } = await supabase
      .from('posts')
      .select(`
        id, title, price, status,
        creators!inner (
          id, display_name, stripe_account_id,
          users!inner (id)
        )
      `)
      .eq('id', postId)
      .eq('status', 'published')
      .single()

    if (!post) {
      return NextResponse.json({ error: 'Post not found' }, { status: 404 })
    }

    if (!post.price || post.price === 0) {
      return NextResponse.json({ error: 'This post is free' }, { status: 400 })
    }

    const creator = post.creators as any
    if (!creator.stripe_account_id) {
      return NextResponse.json({ error: 'Creator has not set up payments' }, { status: 400 })
    }

    // Check not already purchased
    const { data: existingPurchase } = await supabase
      .from('purchases')
      .select('id')
      .eq('user_id', user.id)
      .eq('post_id', postId)
      .single()

    if (existingPurchase) {
      return NextResponse.json({ error: 'Already purchased' }, { status: 400 })
    }

    const customerId = await getOrCreateStripeCustomer(user.id, user.email!)
    const platformFee = calculatePlatformFee(post.price)
    const origin = request.headers.get('origin') || process.env.NEXT_PUBLIC_APP_URL

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: post.title,
              description: `Full comedy set by ${creator.display_name}`,
            },
            unit_amount: post.price,
          },
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${origin}/checkout/success?type=post&postId=${postId}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/post/${postId}`,
      payment_intent_data: {
        application_fee_amount: platformFee,
        transfer_data: {
          destination: creator.stripe_account_id,
        },
      },
      metadata: {
        type: 'post_purchase',
        post_id: postId,
        user_id: user.id,
        creator_id: creator.id,
      },
    })

    return NextResponse.json({ url: session.url })
  } catch (error) {
    console.error('Checkout post error:', error)
    return NextResponse.json({ error: 'Failed to create checkout session' }, { status: 500 })
  }
}
