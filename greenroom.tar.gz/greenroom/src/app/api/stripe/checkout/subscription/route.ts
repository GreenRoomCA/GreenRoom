import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase/server'
import { stripe, calculatePlatformFee, getOrCreateStripeCustomer } from '@/lib/stripe'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createServerClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { creatorId } = body

    if (!creatorId) {
      return NextResponse.json({ error: 'creatorId required' }, { status: 400 })
    }

    const { data: creator } = await supabase
      .from('creators')
      .select('id, display_name, subscription_price, stripe_account_id, stripe_price_id')
      .eq('id', creatorId)
      .single()

    if (!creator) {
      return NextResponse.json({ error: 'Creator not found' }, { status: 404 })
    }

    if (!creator.subscription_price) {
      return NextResponse.json({ error: 'Creator does not offer subscriptions' }, { status: 400 })
    }

    if (!creator.stripe_account_id) {
      return NextResponse.json({ error: 'Creator has not set up payments' }, { status: 400 })
    }

    // Check for existing active subscription
    const { data: existingSub } = await supabase
      .from('subscriptions')
      .select('id, status')
      .eq('user_id', user.id)
      .eq('creator_id', creatorId)
      .eq('status', 'active')
      .single()

    if (existingSub) {
      return NextResponse.json({ error: 'Already subscribed' }, { status: 400 })
    }

    const customerId = await getOrCreateStripeCustomer(user.id, user.email!)
    const platformFee = calculatePlatformFee(creator.subscription_price)
    const origin = request.headers.get('origin') || process.env.NEXT_PUBLIC_APP_URL

    // Get or create a Stripe price for this creator's subscription
    let priceId = creator.stripe_price_id

    if (!priceId) {
      // Create a product + price on the connected account
      const product = await stripe.products.create(
        { name: `${creator.display_name} — Monthly Subscription` },
        { stripeAccount: creator.stripe_account_id }
      )

      const price = await stripe.prices.create(
        {
          product: product.id,
          unit_amount: creator.subscription_price,
          currency: 'usd',
          recurring: { interval: 'month' },
        },
        { stripeAccount: creator.stripe_account_id }
      )

      priceId = price.id

      // Save price ID for future use
      await supabase
        .from('creators')
        .update({ stripe_price_id: priceId })
        .eq('id', creatorId)
    }

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ['card'],
      line_items: [{ price: priceId, quantity: 1 }],
      mode: 'subscription',
      success_url: `${origin}/checkout/success?type=subscription&creatorId=${creatorId}&session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/creator/${creator.display_name}`,
      subscription_data: {
        application_fee_percent: 15,
        transfer_data: {
          destination: creator.stripe_account_id,
        },
        metadata: {
          user_id: user.id,
          creator_id: creatorId,
        },
      },
      metadata: {
        type: 'subscription',
        user_id: user.id,
        creator_id: creatorId,
      },
    })

    return NextResponse.json({ url: session.url })
  } catch (error) {
    console.error('Checkout subscription error:', error)
    return NextResponse.json({ error: 'Failed to create checkout session' }, { status: 500 })
  }
}
