import { NextRequest, NextResponse } from 'next/server'
import { createServiceRoleClient } from '@/lib/supabase/server'
import { stripe } from '@/lib/stripe'
import Stripe from 'stripe'

export async function POST(request: NextRequest) {
  const body = await request.text()
  const signature = request.headers.get('stripe-signature')!

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    )
  } catch (err) {
    console.error('Webhook signature verification failed:', err)
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  const supabase = createServiceRoleClient()

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.CheckoutSession
        await handleCheckoutCompleted(supabase, session)
        break
      }

      case 'customer.subscription.created':
      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription
        await handleSubscriptionUpdate(supabase, subscription)
        break
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription
        await handleSubscriptionDeleted(supabase, subscription)
        break
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice
        await handlePaymentFailed(supabase, invoice)
        break
      }

      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error(`Error handling webhook ${event.type}:`, error)
    return NextResponse.json({ error: 'Webhook handler failed' }, { status: 500 })
  }
}

async function handleCheckoutCompleted(supabase: any, session: Stripe.CheckoutSession) {
  const { metadata, customer, amount_total } = session
  if (!metadata) return

  const { type, user_id, post_id, bundle_id, creator_id } = metadata
  const amountCents = amount_total || 0

  if (type === 'post_purchase' && post_id) {
    // Record purchase
    await supabase.from('purchases').insert({
      user_id,
      post_id,
      amount_paid: amountCents,
      stripe_payment_intent_id: session.payment_intent,
    })

    // Update fan_spend
    await upsertFanSpend(supabase, user_id, creator_id, amountCents)
  }

  if (type === 'bundle_purchase' && bundle_id) {
    // Record bundle purchase
    await supabase.from('bundle_purchases').insert({
      user_id,
      bundle_id,
      amount_paid: amountCents,
      stripe_payment_intent_id: session.payment_intent,
    })

    // Update fan_spend
    await upsertFanSpend(supabase, user_id, creator_id, amountCents)
  }
}

async function handleSubscriptionUpdate(supabase: any, subscription: Stripe.Subscription) {
  const { metadata } = subscription
  if (!metadata?.user_id || !metadata?.creator_id) return

  const { user_id, creator_id } = metadata

  const subData = {
    user_id,
    creator_id,
    stripe_subscription_id: subscription.id,
    stripe_customer_id: subscription.customer as string,
    status: subscription.status,
    current_period_start: new Date(subscription.current_period_start * 1000).toISOString(),
    current_period_end: new Date(subscription.current_period_end * 1000).toISOString(),
  }

  await supabase
    .from('subscriptions')
    .upsert(subData, { onConflict: 'stripe_subscription_id' })
}

async function handleSubscriptionDeleted(supabase: any, subscription: Stripe.Subscription) {
  await supabase
    .from('subscriptions')
    .update({ status: 'canceled' })
    .eq('stripe_subscription_id', subscription.id)
}

async function handlePaymentFailed(supabase: any, invoice: Stripe.Invoice) {
  if (!invoice.subscription) return

  await supabase
    .from('subscriptions')
    .update({ status: 'past_due' })
    .eq('stripe_subscription_id', invoice.subscription)
}

async function upsertFanSpend(
  supabase: any,
  userId: string,
  creatorId: string,
  amountCents: number
) {
  // Upsert fan_spend record (trigger will handle badge updates)
  const { data: existing } = await supabase
    .from('fan_spend')
    .select('id, total_spent')
    .eq('user_id', userId)
    .eq('creator_id', creatorId)
    .single()

  if (existing) {
    await supabase
      .from('fan_spend')
      .update({ total_spent: existing.total_spent + amountCents })
      .eq('id', existing.id)
  } else {
    await supabase.from('fan_spend').insert({
      user_id: userId,
      creator_id: creatorId,
      total_spent: amountCents,
    })
  }
}
