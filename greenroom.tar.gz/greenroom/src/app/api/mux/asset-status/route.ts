import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase/server'
import Mux from '@mux/mux-node'

const mux = new Mux({
  tokenId: process.env.MUX_TOKEN_ID!,
  tokenSecret: process.env.MUX_TOKEN_SECRET!,
})

export async function GET(request: NextRequest) {
  try {
    const supabase = await createServerClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const uploadId = searchParams.get('uploadId')
    const assetId = searchParams.get('assetId')

    if (uploadId) {
      // Check upload status to get asset ID
      const upload = await mux.video.uploads.retrieve(uploadId)
      return NextResponse.json({
        status: upload.status,
        assetId: upload.asset_id,
      })
    }

    if (assetId) {
      // Check asset processing status
      const asset = await mux.video.assets.retrieve(assetId)
      return NextResponse.json({
        status: asset.status,
        playbackId: asset.playback_ids?.[0]?.id,
        duration: asset.duration,
        aspectRatio: asset.aspect_ratio,
      })
    }

    return NextResponse.json({ error: 'uploadId or assetId required' }, { status: 400 })
  } catch (error) {
    console.error('Mux asset status error:', error)
    return NextResponse.json({ error: 'Failed to get asset status' }, { status: 500 })
  }
}
