import { NextRequest, NextResponse } from 'next/server'
import { createServerClient } from '@/lib/supabase/server'

export async function POST(request: NextRequest) {
  try {
    const supabase = await createServerClient()
    const { data: { user } } = await supabase.auth.getUser()

    const body = await request.json()
    const { postId, viewType } = body // viewType: 'preview' | 'full'

    if (!postId || !viewType) {
      return NextResponse.json({ error: 'postId and viewType required' }, { status: 400 })
    }

    if (!['preview', 'full'].includes(viewType)) {
      return NextResponse.json({ error: 'Invalid viewType' }, { status: 400 })
    }

    // Insert view record
    await supabase.from('views').insert({
      post_id: postId,
      user_id: user?.id || null,
      view_type: viewType,
      ip_hash: null, // Could hash IP for dedup if needed
    })

    // Increment cached count on posts table
    await supabase.rpc('increment_view_count', {
      post_id: postId,
      view_type: viewType,
    })

    return NextResponse.json({ ok: true })
  } catch (error) {
    // Silently fail view tracking — don't block the user
    console.error('View tracking error:', error)
    return NextResponse.json({ ok: true })
  }
}
