import Link from 'next/link'
import { Mic2, Play, Lock, Crown, TrendingUp, Star } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Navbar } from '@/components/shared/navbar'

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gr-bg grain spotlight-bg">
      <Navbar />

      {/* Hero */}
      <section className="relative min-h-screen flex flex-col items-center justify-center text-center px-6 pt-20 pb-16">
        {/* Spotlight glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-gr-accent/5 blur-3xl rounded-full pointer-events-none" />

        <div className="relative z-10 max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 border border-gr-border bg-gr-card px-3 py-1.5 rounded-sm text-xs text-gr-dim mb-8">
            <Mic2 className="w-3.5 h-3.5 text-gr-accent" />
            Discovery-first creator marketplace for stand-up comedy
          </div>

          <h1 className="font-display text-5xl sm:text-7xl font-black text-gr-text mb-6 leading-[0.9] tracking-tight">
            Missed the show?<br />
            <span className="text-gr-accent">Watch the set here.</span>
          </h1>

          <p className="text-gr-dim text-lg sm:text-xl max-w-xl mx-auto mb-10 leading-relaxed">
            GreenRoom lets comedians turn live performances into a second revenue stream.
            Fans discover sets, subscribe to creators, and never miss a bit.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link href="/feed">
              <Button size="lg" className="gap-2 px-8 text-base">
                <Play className="w-4 h-4" />
                Browse Sets
              </Button>
            </Link>
            <Link href="/auth/signup?role=creator">
              <Button size="lg" variant="outline" className="gap-2 px-8 text-base">
                <Mic2 className="w-4 h-4" />
                Upload Your Set
              </Button>
            </Link>
          </div>
        </div>

        {/* Mock phone */}
        <div className="relative mt-16 mx-auto w-[220px] h-[440px] bg-gr-card border border-gr-border rounded-2xl overflow-hidden shadow-2xl shadow-black/60">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black/90" />
          <div className="w-full h-full bg-gradient-to-b from-gr-muted/20 to-gr-surface flex items-center justify-center">
            <Mic2 className="w-16 h-16 text-gr-accent/30" />
          </div>
          <div className="absolute bottom-4 left-3 right-3">
            <div className="text-white font-display font-bold text-sm mb-1">Dave Chappelle</div>
            <div className="text-white/60 text-xs mb-2">Comedy Cellar · NYC</div>
            <div className="bg-gr-accent text-gr-bg text-xs text-center py-1.5 rounded-sm font-medium">
              Unlock Full Set — $12
            </div>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 px-6 border-t border-gr-border">
        <div className="max-w-5xl mx-auto">
          <p className="text-center text-xs text-gr-dim uppercase tracking-widest mb-4">How it works</p>
          <h2 className="font-display text-4xl font-bold text-center mb-16">
            Your live set, now a product.
          </h2>

          <div className="grid sm:grid-cols-3 gap-8">
            {[
              {
                icon: <Mic2 className="w-8 h-8 text-gr-accent" />,
                title: 'Perform',
                desc: 'You do the show. The audience is there. The bit lands. The crowd goes wild.',
              },
              {
                icon: <TrendingUp className="w-8 h-8 text-gr-accent" />,
                title: 'Upload',
                desc: 'Upload a 60-second preview clip and your full set. Set your price. You control everything.',
              },
              {
                icon: <Crown className="w-8 h-8 text-gr-accent" />,
                title: 'Earn',
                desc: 'Fans discover your clip, unlock the full set, subscribe to you. Revenue hits your account.',
              },
            ].map(item => (
              <div key={item.title} className="bg-gr-card border border-gr-border rounded-sm p-6">
                <div className="mb-4">{item.icon}</div>
                <h3 className="font-display text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-gr-dim text-sm leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* For fans */}
      <section className="py-24 px-6 border-t border-gr-border bg-gr-surface/30">
        <div className="max-w-5xl mx-auto">
          <div className="grid sm:grid-cols-2 gap-16 items-center">
            <div>
              <p className="text-xs text-gr-dim uppercase tracking-widest mb-4">For Fans</p>
              <h2 className="font-display text-4xl font-bold mb-6">
                Never miss a set again.
              </h2>
              <p className="text-gr-dim mb-8 leading-relaxed">
                Browse short previews in a scrollable feed. Discover new comedians.
                Follow your favorites, buy sets à la carte, or subscribe for full access.
              </p>
              <ul className="space-y-3 text-sm text-gr-dim">
                {['Free 60-second previews', 'One-time set purchases', 'Creator subscriptions', 'Curated bundles', 'Top Supporter badges'].map(f => (
                  <li key={f} className="flex items-center gap-2">
                    <Star className="w-3 h-3 text-gr-accent flex-shrink-0" />
                    {f}
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-gr-card border border-gr-border rounded-sm p-8">
              <Lock className="w-12 h-12 text-gr-accent mb-4 opacity-60" />
              <h3 className="font-display text-2xl font-bold mb-2">Full Set Locked</h3>
              <p className="text-gr-dim text-sm mb-6">
                Unlock access to the complete performance — every bit, every callback.
              </p>
              <div className="space-y-2">
                <div className="bg-gr-accent text-gr-bg text-sm text-center py-2.5 rounded-sm font-medium">
                  Buy This Set — $12
                </div>
                <div className="border border-gr-accent/40 text-gr-accent text-sm text-center py-2.5 rounded-sm">
                  Subscribe — $9.99/mo
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Creator CTA */}
      <section className="py-24 px-6 border-t border-gr-border">
        <div className="max-w-3xl mx-auto text-center">
          <p className="text-xs text-gr-dim uppercase tracking-widest mb-4">For Comedians</p>
          <h2 className="font-display text-4xl font-bold mb-6">
            You already did the hard part.<br />
            <span className="text-gr-accent">Now get paid for it.</span>
          </h2>
          <p className="text-gr-dim mb-10 text-lg">
            Every show you've performed is content waiting to earn. Upload your archive.
            Set your prices. GreenRoom handles the rest.
          </p>
          <Link href="/auth/signup?role=creator">
            <Button size="lg" className="text-base px-10">
              Start Uploading Sets
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gr-border py-8 px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Mic2 className="w-4 h-4 text-gr-accent" />
            <span className="font-display font-bold text-sm">GreenRoom</span>
          </div>
          <p className="text-gr-dim text-xs">© 2026 GreenRoom. Missed the show? Watch the set here.</p>
        </div>
      </footer>
    </div>
  )
}
