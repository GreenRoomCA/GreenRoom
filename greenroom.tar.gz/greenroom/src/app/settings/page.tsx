import { redirect } from 'next/navigation'
import { createServerClient } from '@/lib/supabase/server'
import UserSettingsClient from './user-settings-client'

export default async function UserSettingsPage() {
  const supabase = await createServerClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    redirect('/auth/login?redirect=/settings')
  }

  const { data: userData } = await supabase
    .from('users')
    .select('id, email, display_name, avatar_url, role')
    .eq('id', user.id)
    .single()

  // Get active subscriptions
  const { data: subscriptions } = await supabase
    .from('subscriptions')
    .select(`
      id, status, current_period_end,
      creators!inner (display_name, username, avatar_url)
    `)
    .eq('user_id', user.id)
    .eq('status', 'active')
    .order('created_at', { ascending: false })

  return (
    <UserSettingsClient
      user={userData || { id: user.id, email: user.email || '', display_name: '', avatar_url: null, role: 'fan' }}
      subscriptions={subscriptions || []}
    />
  )
}
