'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { createClient } from '@/lib/supabase/client'
import { User, CreditCard, LogOut, ChevronRight, ExternalLink } from 'lucide-react'
import { addToast } from '@/components/ui/toaster'

interface UserSettingsClientProps {
  user: {
    id: string
    email: string
    display_name: string | null
    avatar_url: string | null
    role: string
  }
  subscriptions: any[]
}

export default function UserSettingsClient({ user, subscriptions }: UserSettingsClientProps) {
  const [displayName, setDisplayName] = useState(user.display_name || '')
  const [saving, setSaving] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  async function handleSave() {
    setSaving(true)
    try {
      const { error } = await supabase
        .from('users')
        .update({ display_name: displayName })
        .eq('id', user.id)

      if (error) throw error
      addToast({ type: 'success', message: 'Profile updated' })
      router.refresh()
    } catch {
      addToast({ type: 'error', message: 'Failed to save' })
    } finally {
      setSaving(false)
    }
  }

  async function handleSignOut() {
    await supabase.auth.signOut()
    router.push('/')
  }

  return (
    <div className="min-h-screen bg-gr-bg">
      <div className="max-w-lg mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-white">Settings</h1>
        </div>

        {/* Profile */}
        <section className="mb-6">
          <h2 className="text-sm font-medium text-gr-muted uppercase tracking-wider mb-3">Profile</h2>
          <div className="bg-gr-card rounded-xl border border-white/5 p-4 space-y-4">
            <div>
              <label className="block text-sm text-gr-muted mb-1.5">Display Name</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-gr-surface border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-gr-accent/50"
                placeholder="Your name"
              />
            </div>
            <div>
              <label className="block text-sm text-gr-muted mb-1.5">Email</label>
              <p className="text-sm text-white bg-gr-surface border border-white/5 rounded-lg px-3 py-2">
                {user.email}
              </p>
            </div>
            <button
              onClick={handleSave}
              disabled={saving}
              className="w-full bg-gr-accent text-black font-semibold py-2 rounded-lg hover:bg-gr-accent/90 transition-colors disabled:opacity-50 text-sm"
            >
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </section>

        {/* Subscriptions */}
        <section className="mb-6">
          <h2 className="text-sm font-medium text-gr-muted uppercase tracking-wider mb-3">
            Subscriptions
          </h2>
          <div className="bg-gr-card rounded-xl border border-white/5 overflow-hidden">
            {subscriptions.length > 0 ? (
              subscriptions.map((sub, i) => {
                const creator = sub.creators
                return (
                  <div
                    key={sub.id}
                    className={`flex items-center justify-between p-4 ${i < subscriptions.length - 1 ? 'border-b border-white/5' : ''}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-gr-surface flex items-center justify-center text-sm font-bold text-gr-accent">
                        {creator.display_name?.[0]}
                      </div>
                      <div>
                        <Link
                          href={`/creator/${creator.username}`}
                          className="text-sm font-medium text-white hover:text-gr-accent transition-colors"
                        >
                          {creator.display_name}
                        </Link>
                        <p className="text-xs text-gr-muted">
                          Renews {new Date(sub.current_period_end).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs bg-green-500/10 text-green-400 px-2 py-1 rounded-full">
                      Active
                    </span>
                  </div>
                )
              })
            ) : (
              <div className="p-4 text-sm text-gr-muted text-center">
                No active subscriptions.{' '}
                <Link href="/feed" className="text-gr-accent hover:underline">
                  Browse creators →
                </Link>
              </div>
            )}
          </div>
        </section>

        {/* Creator dashboard link */}
        {user.role === 'creator' && (
          <section className="mb-6">
            <h2 className="text-sm font-medium text-gr-muted uppercase tracking-wider mb-3">
              Creator
            </h2>
            <div className="bg-gr-card rounded-xl border border-white/5 overflow-hidden">
              <Link
                href="/dashboard"
                className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors"
              >
                <div className="flex items-center gap-3 text-white">
                  <ExternalLink size={16} className="text-gr-muted" />
                  <span className="text-sm font-medium">Creator Dashboard</span>
                </div>
                <ChevronRight size={16} className="text-gr-muted" />
              </Link>
            </div>
          </section>
        )}

        {/* Account actions */}
        <section>
          <h2 className="text-sm font-medium text-gr-muted uppercase tracking-wider mb-3">Account</h2>
          <div className="bg-gr-card rounded-xl border border-white/5 overflow-hidden">
            <button
              onClick={handleSignOut}
              className="w-full flex items-center gap-3 p-4 hover:bg-white/5 transition-colors text-left text-red-400 hover:text-red-300"
            >
              <LogOut size={16} />
              <span className="text-sm font-medium">Sign Out</span>
            </button>
          </div>
        </section>
      </div>
    </div>
  )
}
