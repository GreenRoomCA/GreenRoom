import { redirect } from 'next/navigation'
import { createServerClient } from '@/lib/supabase/server'
import { canUserAccessPost } from '@/lib/utils/access'
import { createSignedPlaybackUrl } from '@/lib/mux'
import WatchClient from './watch-client'

interface WatchPageProps {
  params: Promise<{ id: string }>
}

export default async function WatchPage({ params }: WatchPageProps) {
  const { id } = await params
  const supabase = await createServerClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    redirect(`/auth/login?redirect=/watch/${id}`)
  }

  // Get post details
  const { data: post } = await supabase
    .from('posts')
    .select(`
      id, title, description, status,
      full_mux_playback_id, preview_mux_playback_id,
      show_date, venue, city, duration_seconds,
      creators!inner (
        id, display_name, username, avatar_url
      )
    `)
    .eq('id', id)
    .single()

  if (!post || post.status !== 'published') {
    redirect('/feed')
  }

  // Check access
  const access = await canUserAccessPost(user.id, id)

  if (!access.canAccess) {
    redirect(`/post/${id}`)
  }

  if (!post.full_mux_playback_id) {
    redirect(`/post/${id}`)
  }

  // Generate signed playback URL (expires in 24h)
  const signedToken = await createSignedPlaybackUrl(
    post.full_mux_playback_id,
    86400 // 24 hours
  )

  const creator = post.creators as any

  return (
    <WatchClient
      post={{
        id: post.id,
        title: post.title,
        description: post.description,
        fullPlaybackId: post.full_mux_playback_id,
        signedToken,
        showDate: post.show_date,
        venue: post.venue,
        city: post.city,
        durationSeconds: post.duration_seconds,
      }}
      creator={{
        id: creator.id,
        displayName: creator.display_name,
        username: creator.username,
        avatarUrl: creator.avatar_url,
      }}
      accessType={access.reason}
    />
  )
}
