'use client'

import { useEffect, useRef } from 'react'
import Link from 'next/link'
import MuxPlayer from '@mux/mux-player-react'
import { ArrowLeft, Calendar, MapPin, Clock } from 'lucide-react'
import { formatShowDate, formatDuration } from '@/lib/utils'

interface WatchClientProps {
  post: {
    id: string
    title: string
    description: string | null
    fullPlaybackId: string
    signedToken: string
    showDate: string | null
    venue: string | null
    city: string | null
    durationSeconds: number | null
  }
  creator: {
    id: string
    displayName: string
    username: string
    avatarUrl: string | null
  }
  accessType: string
}

export default function WatchClient({ post, creator, accessType }: WatchClientProps) {
  const hasTrackedView = useRef(false)

  useEffect(() => {
    if (hasTrackedView.current) return
    hasTrackedView.current = true

    // Track full view
    fetch('/api/analytics/view', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ postId: post.id, viewType: 'full' }),
    }).catch(console.error)
  }, [post.id])

  return (
    <div className="min-h-screen bg-gr-bg">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-gr-bg/90 backdrop-blur border-b border-white/5 px-4 py-3 flex items-center gap-3">
        <Link
          href={`/post/${post.id}`}
          className="p-2 rounded-lg hover:bg-white/5 transition-colors text-gr-muted hover:text-white"
        >
          <ArrowLeft size={20} />
        </Link>
        <div className="flex-1 min-w-0">
          <h1 className="font-display text-base font-semibold text-white truncate">
            {post.title}
          </h1>
          <Link
            href={`/creator/${creator.username}`}
            className="text-sm text-gr-muted hover:text-gr-accent transition-colors"
          >
            {creator.displayName}
          </Link>
        </div>
      </div>

      {/* Video Player */}
      <div className="relative w-full bg-black" style={{ aspectRatio: '16/9', maxHeight: '75vh' }}>
        <MuxPlayer
          playbackId={post.fullPlaybackId}
          tokens={{ playback: post.signedToken }}
          streamType="on-demand"
          autoPlay={false}
          style={{ width: '100%', height: '100%' }}
          accentColor="#f5c842"
        />

        {/* Watermark */}
        <div className="absolute bottom-16 right-4 text-white/20 text-xs font-mono select-none pointer-events-none">
          greenroom.tv
        </div>
      </div>

      {/* Metadata */}
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
        <div>
          <h2 className="font-display text-2xl font-bold text-white mb-2">{post.title}</h2>

          <div className="flex flex-wrap items-center gap-4 text-sm text-gr-muted">
            {post.showDate && (
              <span className="flex items-center gap-1.5">
                <Calendar size={14} />
                {formatShowDate(post.showDate)}
              </span>
            )}
            {(post.venue || post.city) && (
              <span className="flex items-center gap-1.5">
                <MapPin size={14} />
                {[post.venue, post.city].filter(Boolean).join(', ')}
              </span>
            )}
            {post.durationSeconds && (
              <span className="flex items-center gap-1.5">
                <Clock size={14} />
                {formatDuration(post.durationSeconds)}
              </span>
            )}
          </div>
        </div>

        {post.description && (
          <p className="text-gr-muted leading-relaxed">{post.description}</p>
        )}

        {/* Creator card */}
        <div className="flex items-center gap-3 pt-4 border-t border-white/5">
          {creator.avatarUrl ? (
            <img
              src={creator.avatarUrl}
              alt={creator.displayName}
              className="w-10 h-10 rounded-full object-cover"
            />
          ) : (
            <div className="w-10 h-10 rounded-full bg-gr-surface flex items-center justify-center text-gr-accent font-bold">
              {creator.displayName[0]}
            </div>
          )}
          <div>
            <p className="text-sm font-medium text-white">{creator.displayName}</p>
            <Link
              href={`/creator/${creator.username}`}
              className="text-xs text-gr-muted hover:text-gr-accent transition-colors"
            >
              View all sets →
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
