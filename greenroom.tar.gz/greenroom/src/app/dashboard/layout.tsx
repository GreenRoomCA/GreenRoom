import { createClient } from '@/lib/supabase/server'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import { Mic2, LayoutDashboard, Upload, BarChart2, Package, Clock, Settings, LogOut, MessageSquare } from 'lucide-react'
import { cn } from '@/lib/utils'

const navItems = [
  { href: '/dashboard', label: 'Overview', icon: LayoutDashboard },
  { href: '/dashboard/upload', label: 'Upload', icon: Upload },
  { href: '/dashboard/analytics', label: 'Analytics', icon: BarChart2 },
  { href: '/dashboard/bundles', label: 'Bundles', icon: Package },
  { href: '/dashboard/drops', label: 'Drops', icon: Clock },
  { href: '/dashboard/messages', label: 'Messages', icon: MessageSquare },
  { href: '/dashboard/settings', label: 'Settings', icon: Settings },
]

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) redirect('/auth/login?redirect=/dashboard')

  const { data: creator } = await supabase
    .from('creators')
    .select('*')
    .eq('user_id', user.id)
    .maybeSingle()

  if (!creator) redirect('/creator/onboarding')

  return (
    <div className="min-h-screen bg-gr-bg flex">
      {/* Sidebar */}
      <aside className="fixed left-0 top-0 bottom-0 w-56 border-r border-gr-border bg-gr-surface flex flex-col z-20 hidden lg:flex">
        <div className="p-5 border-b border-gr-border">
          <Link href="/" className="flex items-center gap-2">
            <Mic2 className="w-5 h-5 text-gr-accent" />
            <span className="font-display font-bold text-lg">GreenRoom</span>
          </Link>
        </div>

        <nav className="flex-1 p-3 space-y-0.5">
          {navItems.map(item => (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 px-3 py-2.5 text-sm text-gr-dim hover:text-gr-text hover:bg-gr-card rounded-sm transition-colors group"
            >
              <item.icon className="w-4 h-4 group-hover:text-gr-accent transition-colors" />
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="p-3 border-t border-gr-border">
          <div className="px-3 py-2">
            <p className="text-xs font-medium text-gr-text truncate">{creator.display_name}</p>
            <p className="text-xs text-gr-dim">@{creator.username}</p>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 lg:ml-56 min-h-screen">
        {/* Mobile header */}
        <div className="lg:hidden sticky top-0 z-20 border-b border-gr-border bg-gr-bg/95 backdrop-blur px-4 h-14 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Mic2 className="w-5 h-5 text-gr-accent" />
            <span className="font-display font-bold">GreenRoom</span>
          </Link>
          {/* mobile nav dropdown would go here */}
        </div>
        {children}
      </main>
    </div>
  )
}
