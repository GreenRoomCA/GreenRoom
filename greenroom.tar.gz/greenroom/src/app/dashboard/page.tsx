import { createClient } from '@/lib/supabase/server'
import Link from 'next/link'
import { formatPrice, formatCount } from '@/lib/utils'
import { Upload, DollarSign, Eye, Users, TrendingUp, ArrowRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: creator } = await supabase
    .from('creators')
    .select('*')
    .eq('user_id', user!.id)
    .single()

  // Stats
  const [postsRes, purchasesRes, subsRes, viewsRes] = await Promise.all([
    supabase.from('posts').select('id, title, price, purchase_count, view_count, status').eq('creator_id', creator.id),
    supabase.from('purchases').select('price_paid').eq('creator_id', creator.id),
    supabase.from('subscriptions').select('id').eq('creator_id', creator.id).eq('status', 'active'),
    supabase.from('views').select('id').eq('creator_id', creator.id),
  ])

  const posts = postsRes.data || []
  const totalRevenue = (purchasesRes.data || []).reduce((sum, p) => sum + p.price_paid, 0)
  const activeSubscribers = subsRes.data?.length || 0
  const totalViews = viewsRes.data?.length || 0
  const publishedPosts = posts.filter(p => p.status === 'published').length

  const stats = [
    { label: 'Total Revenue', value: formatPrice(totalRevenue), icon: DollarSign, color: 'text-gr-accent' },
    { label: 'Active Subscribers', value: formatCount(activeSubscribers), icon: Users, color: 'text-blue-400' },
    { label: 'Total Views', value: formatCount(totalViews), icon: Eye, color: 'text-purple-400' },
    { label: 'Published Sets', value: publishedPosts.toString(), icon: TrendingUp, color: 'text-gr-green' },
  ]

  const recentPosts = posts.slice(0, 5)

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Welcome */}
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold">
          Hey, {creator.display_name.split(' ')[0]} 👋
        </h1>
        <p className="text-gr-dim mt-1">Here's what's happening with your GreenRoom.</p>
      </div>

      {/* Connect Stripe banner */}
      {!creator.stripe_account_enabled && (
        <div className="mb-6 bg-gr-accent/10 border border-gr-accent/30 rounded-sm p-4 flex items-center justify-between">
          <div>
            <p className="font-medium text-gr-accent text-sm">Connect Stripe to start getting paid</p>
            <p className="text-gr-dim text-xs mt-0.5">You need a Stripe account to receive payouts.</p>
          </div>
          <Link href="/api/stripe/connect">
            <Button size="sm">Connect Stripe</Button>
          </Link>
        </div>
      )}

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
        {stats.map(stat => (
          <div key={stat.label} className="bg-gr-card border border-gr-border rounded-sm p-4">
            <div className="flex items-center gap-2 mb-2">
              <stat.icon className={`w-4 h-4 ${stat.color}`} />
              <span className="text-xs text-gr-dim">{stat.label}</span>
            </div>
            <p className="font-display text-2xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div className="grid sm:grid-cols-2 gap-3 mb-8">
        <Link href="/dashboard/upload" className="bg-gr-card border border-gr-border hover:border-gr-dim rounded-sm p-5 flex items-center gap-4 transition-colors group">
          <div className="w-10 h-10 bg-gr-accent/10 rounded-sm flex items-center justify-center">
            <Upload className="w-5 h-5 text-gr-accent" />
          </div>
          <div>
            <p className="font-medium">Upload New Set</p>
            <p className="text-gr-dim text-xs mt-0.5">Add a preview clip and full set</p>
          </div>
          <ArrowRight className="w-4 h-4 text-gr-dim ml-auto group-hover:text-gr-text transition-colors" />
        </Link>
        <Link href="/dashboard/analytics" className="bg-gr-card border border-gr-border hover:border-gr-dim rounded-sm p-5 flex items-center gap-4 transition-colors group">
          <div className="w-10 h-10 bg-purple-400/10 rounded-sm flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-purple-400" />
          </div>
          <div>
            <p className="font-medium">View Analytics</p>
            <p className="text-gr-dim text-xs mt-0.5">See which sets are performing</p>
          </div>
          <ArrowRight className="w-4 h-4 text-gr-dim ml-auto group-hover:text-gr-text transition-colors" />
        </Link>
      </div>

      {/* Recent posts */}
      {recentPosts.length > 0 && (
        <div>
          <h2 className="font-display text-lg font-bold mb-4">Your Sets</h2>
          <div className="space-y-2">
            {recentPosts.map(post => (
              <div key={post.id} className="bg-gr-card border border-gr-border rounded-sm p-4 flex items-center justify-between">
                <div>
                  <p className="font-medium text-sm">{post.title}</p>
                  <p className="text-xs text-gr-dim mt-0.5">
                    {post.view_count} views · {post.purchase_count} purchases · {formatPrice(post.price)}
                  </p>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-sm ${
                  post.status === 'published'
                    ? 'bg-gr-green/10 text-gr-green'
                    : 'bg-gr-muted text-gr-dim'
                }`}>
                  {post.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {posts.length === 0 && (
        <div className="text-center py-16 border border-dashed border-gr-border rounded-sm">
          <Upload className="w-12 h-12 text-gr-dim mx-auto mb-3" />
          <h3 className="font-display text-xl font-bold mb-2">No sets yet</h3>
          <p className="text-gr-dim text-sm mb-4">Upload your first set to start earning.</p>
          <Link href="/dashboard/upload">
            <Button>Upload Your First Set</Button>
          </Link>
        </div>
      )}
    </div>
  )
}
