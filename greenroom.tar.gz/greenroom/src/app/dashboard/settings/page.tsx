'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { toast } from '@/components/ui/toaster'
import { ExternalLink, CheckCircle } from 'lucide-react'

export default function DashboardSettings() {
  const supabase = createClient()
  const [creator, setCreator] = useState<any>(null)
  const [displayName, setDisplayName] = useState('')
  const [bio, setBio] = useState('')
  const [subscriptionPrice, setSubscriptionPrice] = useState('')
  const [messagePrice, setMessagePrice] = useState('')
  const [ticketLink, setTicketLink] = useState('')
  const [saving, setSaving] = useState(false)
  const [connectingStripe, setConnectingStripe] = useState(false)

  useEffect(() => {
    loadCreator()
  }, [])

  const loadCreator = async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const { data } = await supabase.from('creators').select('*').eq('user_id', user.id).single()
    if (data) {
      setCreator(data)
      setDisplayName(data.display_name)
      setBio(data.bio || '')
      setSubscriptionPrice(data.subscription_price?.toString() || '9.99')
      setMessagePrice(data.message_price?.toString() || '5.00')
      setTicketLink(data.ticket_link || '')
    }
  }

  const handleSave = async () => {
    setSaving(true)
    await supabase.from('creators').update({
      display_name: displayName,
      bio,
      subscription_price: parseFloat(subscriptionPrice),
      message_price: parseFloat(messagePrice),
      ticket_link: ticketLink || null,
    }).eq('id', creator.id)
    toast('Settings saved', 'success')
    setSaving(false)
  }

  const handleConnectStripe = async () => {
    setConnectingStripe(true)
    const res = await fetch('/api/stripe/connect')
    const { url } = await res.json()
    window.location.href = url
  }

  if (!creator) return <div className="p-6 text-gr-dim">Loading...</div>

  return (
    <div className="p-6 max-w-xl mx-auto">
      <h1 className="font-display text-3xl font-bold mb-8">Settings</h1>

      <div className="space-y-6">
        {/* Stripe */}
        <div className="bg-gr-card border border-gr-border rounded-sm p-5">
          <h2 className="font-display text-lg font-bold mb-1">Payouts</h2>
          <p className="text-gr-dim text-sm mb-4">Connect your Stripe account to receive earnings.</p>
          {creator.stripe_account_enabled ? (
            <div className="flex items-center gap-2 text-gr-green text-sm">
              <CheckCircle className="w-4 h-4" />
              Stripe connected — you're ready to earn
            </div>
          ) : (
            <Button onClick={handleConnectStripe} loading={connectingStripe} className="gap-2">
              <ExternalLink className="w-4 h-4" />
              Connect Stripe
            </Button>
          )}
        </div>

        {/* Profile */}
        <div className="space-y-4">
          <h2 className="font-display text-lg font-bold">Profile</h2>
          <Input label="Stage Name" value={displayName} onChange={e => setDisplayName(e.target.value)} />
          <Textarea label="Bio" value={bio} onChange={e => setBio(e.target.value)} rows={4} />
          <Input label="Ticket / Show Link" type="url" value={ticketLink} onChange={e => setTicketLink(e.target.value)} placeholder="https://dice.fm/your-shows" />
        </div>

        {/* Pricing */}
        <div className="space-y-4">
          <h2 className="font-display text-lg font-bold">Pricing</h2>
          <Input label="Monthly Subscription Price (USD)" type="number" min="1" step="0.01" value={subscriptionPrice} onChange={e => setSubscriptionPrice(e.target.value)} />
          <Input label="Paid Message Price (USD)" type="number" min="1" step="0.01" value={messagePrice} onChange={e => setMessagePrice(e.target.value)} />
        </div>

        <Button className="w-full" size="lg" onClick={handleSave} loading={saving}>
          Save Settings
        </Button>
      </div>
    </div>
  )
}
