import { createClient } from '@/lib/supabase/server'
import { formatPrice, formatRelativeTime } from '@/lib/utils'
import { MessageSquare } from 'lucide-react'

export default async function MessagesPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: creator } = await supabase.from('creators').select('id').eq('user_id', user!.id).single()

  const { data: messages } = await supabase
    .from('messages')
    .select('*, sender:users!sender_id(display_name, avatar_url, email)')
    .eq('receiver_id', user!.id)
    .order('created_at', { ascending: false })

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="font-display text-3xl font-bold mb-2">Messages</h1>
      <p className="text-gr-dim mb-8">Fan messages — only paid messages appear here.</p>

      {messages && messages.length > 0 ? (
        <div className="space-y-3">
          {messages.map((msg: any) => (
            <div key={msg.id} className={`bg-gr-card border rounded-sm p-4 ${msg.read_at ? 'border-gr-border' : 'border-gr-accent/30'}`}>
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-full bg-gr-muted flex items-center justify-center text-sm font-bold flex-shrink-0">
                  {msg.sender?.display_name?.[0] || msg.sender?.email?.[0] || '?'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium">{msg.sender?.display_name || msg.sender?.email}</span>
                    {msg.is_paid && (
                      <span className="text-xs text-gr-accent border border-gr-accent/30 px-1.5 py-0.5 rounded-sm">
                        Paid · {formatPrice(msg.price_paid)}
                      </span>
                    )}
                    {!msg.read_at && (
                      <span className="w-2 h-2 bg-gr-accent rounded-full" />
                    )}
                  </div>
                  <p className="text-sm text-gr-text">{msg.body}</p>
                  <p className="text-xs text-gr-dim mt-1">{formatRelativeTime(msg.created_at)}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-16 border border-dashed border-gr-border rounded-sm">
          <MessageSquare className="w-12 h-12 text-gr-dim mx-auto mb-3" />
          <h3 className="font-display text-xl font-bold mb-2">No messages yet</h3>
          <p className="text-gr-dim text-sm">Paid fan messages will appear here.</p>
        </div>
      )}
    </div>
  )
}
