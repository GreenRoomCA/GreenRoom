'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { formatPrice } from '@/lib/utils'
import type { Bundle, Post } from '@/types'
import { Package, Plus, X, Check } from 'lucide-react'

export default function BundlesPage() {
  const supabase = createClient()
  const [bundles, setBundles] = useState<Bundle[]>([])
  const [posts, setPosts] = useState<Post[]>([])
  const [creatorId, setCreatorId] = useState('')
  const [creating, setCreating] = useState(false)
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [price, setPrice] = useState('')
  const [selectedPosts, setSelectedPosts] = useState<string[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const { data: creator } = await supabase.from('creators').select('id').eq('user_id', user.id).single()
    if (!creator) return
    setCreatorId(creator.id)

    const [bundlesRes, postsRes] = await Promise.all([
      supabase.from('bundles').select('*, bundle_posts(post_id)').eq('creator_id', creator.id).order('created_at', { ascending: false }),
      supabase.from('posts').select('id, title, price, thumbnail_url').eq('creator_id', creator.id).eq('status', 'published'),
    ])
    setBundles(bundlesRes.data || [])
    setPosts(postsRes.data || [])
  }

  const handleCreate = async () => {
    if (!title || !price || selectedPosts.length < 2) return
    setLoading(true)

    const { data: bundle, error } = await supabase.from('bundles').insert({
      creator_id: creatorId,
      title,
      description,
      price: parseFloat(price),
    }).select().single()

    if (error || !bundle) { setLoading(false); return }

    await supabase.from('bundle_posts').insert(
      selectedPosts.map(postId => ({ bundle_id: bundle.id, post_id: postId }))
    )

    setCreating(false)
    setTitle('')
    setDescription('')
    setPrice('')
    setSelectedPosts([])
    loadData()
    setLoading(false)
  }

  const togglePost = (id: string) => {
    setSelectedPosts(prev => prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id])
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold">Bundles</h1>
          <p className="text-gr-dim mt-1">Package multiple sets at a discount</p>
        </div>
        <Button onClick={() => setCreating(true)} className="gap-2">
          <Plus className="w-4 h-4" />
          New Bundle
        </Button>
      </div>

      {creating && (
        <div className="bg-gr-card border border-gr-border rounded-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-lg font-bold">Create Bundle</h2>
            <button onClick={() => setCreating(false)} className="text-gr-dim hover:text-gr-text">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-4">
            <Input label="Bundle Title" value={title} onChange={e => setTitle(e.target.value)} placeholder="NYC Shows Pack" />
            <Textarea label="Description" value={description} onChange={e => setDescription(e.target.value)} rows={2} />
            <Input label="Bundle Price (USD)" type="number" min="0" step="0.01" value={price} onChange={e => setPrice(e.target.value)} />

            <div>
              <p className="text-xs text-gr-dim uppercase tracking-wider mb-2">Select Sets (min. 2)</p>
              <div className="space-y-2">
                {posts.map(post => (
                  <label key={post.id} className="flex items-center gap-3 p-3 border border-gr-border rounded-sm cursor-pointer hover:border-gr-dim transition-colors">
                    <div className={`w-5 h-5 rounded-sm border-2 flex items-center justify-center transition-colors ${selectedPosts.includes(post.id) ? 'border-gr-accent bg-gr-accent' : 'border-gr-dim'}`}>
                      {selectedPosts.includes(post.id) && <Check className="w-3 h-3 text-gr-bg" />}
                    </div>
                    <input type="checkbox" className="hidden" onChange={() => togglePost(post.id)} />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{post.title}</p>
                    </div>
                    <p className="text-sm text-gr-dim">{formatPrice(post.price)}</p>
                  </label>
                ))}
              </div>
            </div>

            <Button
              className="w-full"
              onClick={handleCreate}
              loading={loading}
              disabled={!title || !price || selectedPosts.length < 2}
            >
              Create Bundle
            </Button>
          </div>
        </div>
      )}

      {bundles.length > 0 ? (
        <div className="space-y-3">
          {bundles.map((bundle: any) => (
            <div key={bundle.id} className="bg-gr-card border border-gr-border rounded-sm p-4">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-medium">{bundle.title}</h3>
                  {bundle.description && <p className="text-gr-dim text-sm mt-0.5">{bundle.description}</p>}
                  <p className="text-xs text-gr-dim mt-1">{bundle.bundle_posts?.length || 0} sets</p>
                </div>
                <p className="font-display text-xl font-bold text-gr-accent">{formatPrice(bundle.price)}</p>
              </div>
            </div>
          ))}
        </div>
      ) : !creating && (
        <div className="text-center py-16 border border-dashed border-gr-border rounded-sm">
          <Package className="w-12 h-12 text-gr-dim mx-auto mb-3" />
          <h3 className="font-display text-xl font-bold mb-2">No bundles yet</h3>
          <p className="text-gr-dim text-sm mb-4">Create bundles like "NYC Tour Pack" or "Best Crowd Work".</p>
          <Button onClick={() => setCreating(true)} className="gap-2"><Plus className="w-4 h-4" />Create First Bundle</Button>
        </div>
      )}
    </div>
  )
}
