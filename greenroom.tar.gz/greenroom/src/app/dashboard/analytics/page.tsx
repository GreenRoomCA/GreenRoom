import { createClient } from '@/lib/supabase/server'
import { formatPrice, formatCount } from '@/lib/utils'
import { TrendingUp, Eye, ShoppingBag, Users, DollarSign, Star } from 'lucide-react'

export default async function AnalyticsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()
  const { data: creator } = await supabase.from('creators').select('id').eq('user_id', user!.id).single()

  const [postsRes, purchasesRes, viewsRes, subsRes, fansRes] = await Promise.all([
    supabase.from('posts').select('id, title, view_count, like_count, purchase_count, price, status').eq('creator_id', creator.id).eq('status', 'published'),
    supabase.from('purchases').select('post_id, price_paid, created_at').eq('creator_id', creator.id),
    supabase.from('views').select('post_id, view_type, created_at').eq('creator_id', creator.id),
    supabase.from('subscriptions').select('id, created_at, status').eq('creator_id', creator.id),
    supabase.from('fan_spend').select('user_id, total_spent, badge_level, users(display_name, avatar_url)').eq('creator_id', creator.id).order('total_spent', { ascending: false }).limit(10),
  ])

  const posts = postsRes.data || []
  const purchases = purchasesRes.data || []
  const views = viewsRes.data || []
  const subs = subsRes.data || []
  const fans = fansRes.data || []

  const totalRevenue = purchases.reduce((s, p) => s + p.price_paid, 0)
  const totalViews = views.length
  const previewViews = views.filter(v => v.view_type === 'preview').length
  const fullViews = views.filter(v => v.view_type === 'full').length
  const activeSubs = subs.filter(s => s.status === 'active').length

  // Per-post analytics
  const postStats = posts.map(post => {
    const postPurchases = purchases.filter(p => p.post_id === post.id)
    const postViews = views.filter(v => v.post_id === post.id)
    const revenue = postPurchases.reduce((s, p) => s + p.price_paid, 0)
    const conversionRate = postViews.length > 0 ? (postPurchases.length / postViews.length * 100) : 0
    return { ...post, postRevenue: revenue, totalPostViews: postViews.length, conversionRate }
  }).sort((a, b) => b.postRevenue - a.postRevenue)

  const overviewStats = [
    { label: 'Total Revenue', value: formatPrice(totalRevenue), icon: DollarSign, color: 'text-gr-accent' },
    { label: 'Active Subs', value: activeSubs.toString(), icon: Users, color: 'text-blue-400' },
    { label: 'Total Views', value: formatCount(totalViews), icon: Eye, color: 'text-purple-400' },
    { label: 'Total Purchases', value: purchases.length.toString(), icon: ShoppingBag, color: 'text-gr-green' },
  ]

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="font-display text-3xl font-bold mb-2">Analytics</h1>
      <p className="text-gr-dim mb-8">Your performance at a glance.</p>

      {/* Overview stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
        {overviewStats.map(stat => (
          <div key={stat.label} className="bg-gr-card border border-gr-border rounded-sm p-4">
            <div className="flex items-center gap-2 mb-2">
              <stat.icon className={`w-4 h-4 ${stat.color}`} />
              <span className="text-xs text-gr-dim">{stat.label}</span>
            </div>
            <p className="font-display text-2xl font-bold">{stat.value}</p>
          </div>
        ))}
      </div>

      {/* View breakdown */}
      <div className="grid sm:grid-cols-2 gap-3 mb-8">
        <div className="bg-gr-card border border-gr-border rounded-sm p-4">
          <p className="text-xs text-gr-dim mb-3">Preview Views</p>
          <p className="font-display text-3xl font-bold">{formatCount(previewViews)}</p>
        </div>
        <div className="bg-gr-card border border-gr-border rounded-sm p-4">
          <p className="text-xs text-gr-dim mb-3">Full Set Views</p>
          <p className="font-display text-3xl font-bold">{formatCount(fullViews)}</p>
        </div>
      </div>

      {/* Per-post performance */}
      <div className="mb-8">
        <h2 className="font-display text-xl font-bold mb-4">Set Performance</h2>
        {postStats.length > 0 ? (
          <div className="space-y-2">
            {postStats.map(post => (
              <div key={post.id} className="bg-gr-card border border-gr-border rounded-sm p-4">
                <div className="flex items-start justify-between mb-2">
                  <p className="font-medium text-sm">{post.title}</p>
                  <p className="text-gr-accent font-bold text-sm">{formatPrice(post.postRevenue)}</p>
                </div>
                <div className="flex items-center gap-4 text-xs text-gr-dim">
                  <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{formatCount(post.totalPostViews)} views</span>
                  <span className="flex items-center gap-1"><ShoppingBag className="w-3 h-3" />{post.purchase_count} sold</span>
                  <span className="flex items-center gap-1"><TrendingUp className="w-3 h-3" />{post.conversionRate.toFixed(1)}% CVR</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 border border-dashed border-gr-border rounded-sm">
            <TrendingUp className="w-10 h-10 text-gr-dim mx-auto mb-3" />
            <p className="text-gr-dim">Publish sets to see analytics</p>
          </div>
        )}
      </div>

      {/* Top supporters */}
      {fans.length > 0 && (
        <div>
          <h2 className="font-display text-xl font-bold mb-4">Top Supporters</h2>
          <div className="space-y-2">
            {fans.map((fan: any, i) => (
              <div key={fan.user_id} className="bg-gr-card border border-gr-border rounded-sm p-4 flex items-center gap-3">
                <span className="text-gr-dim text-sm w-6">#{i + 1}</span>
                <div className="w-8 h-8 rounded-full bg-gr-muted flex items-center justify-center text-xs font-bold">
                  {fan.users?.display_name?.[0] || '?'}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{fan.users?.display_name || 'Anonymous'}</p>
                  {fan.badge_level && (
                    <span className="text-xs text-gr-accent">{fan.badge_level}</span>
                  )}
                </div>
                <p className="text-gr-accent font-bold">{formatPrice(fan.total_spent)}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
