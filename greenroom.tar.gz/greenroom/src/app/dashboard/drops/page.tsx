'use client'
import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { formatRelativeTime } from '@/lib/utils'
import type { Post } from '@/types'
import { Clock, Plus, X } from 'lucide-react'

export default function DropsPage() {
  const supabase = createClient()
  const [drops, setDrops] = useState<any[]>([])
  const [posts, setPosts] = useState<Post[]>([])
  const [creatorId, setCreatorId] = useState('')
  const [creating, setCreating] = useState(false)
  const [postId, setPostId] = useState('')
  const [releaseAt, setReleaseAt] = useState('')
  const [teaserText, setTeaserText] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => { loadData() }, [])

  const loadData = async () => {
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return
    const { data: creator } = await supabase.from('creators').select('id').eq('user_id', user.id).single()
    if (!creator) return
    setCreatorId(creator.id)

    const [dropsRes, postsRes] = await Promise.all([
      supabase.from('drops').select('*, posts(title)').eq('creator_id', creator.id).order('release_at'),
      supabase.from('posts').select('id, title').eq('creator_id', creator.id).eq('status', 'draft'),
    ])
    setDrops(dropsRes.data || [])
    setPosts(postsRes.data || [])
  }

  const handleCreate = async () => {
    if (!postId || !releaseAt) return
    setLoading(true)

    await supabase.from('drops').insert({
      post_id: postId,
      creator_id: creatorId,
      release_at: new Date(releaseAt).toISOString(),
      teaser_text: teaserText || null,
    })

    setCreating(false)
    setPostId('')
    setReleaseAt('')
    setTeaserText('')
    loadData()
    setLoading(false)
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold">Drops</h1>
          <p className="text-gr-dim mt-1">Schedule set releases to build anticipation</p>
        </div>
        {posts.length > 0 && (
          <Button onClick={() => setCreating(true)} className="gap-2"><Plus className="w-4 h-4" />Schedule Drop</Button>
        )}
      </div>

      {creating && (
        <div className="bg-gr-card border border-gr-border rounded-sm p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display text-lg font-bold">Schedule a Drop</h2>
            <button onClick={() => setCreating(false)} className="text-gr-dim hover:text-gr-text"><X className="w-5 h-5" /></button>
          </div>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-gr-dim uppercase tracking-wider">Select Draft Set</label>
              <select value={postId} onChange={e => setPostId(e.target.value)} className="w-full bg-gr-surface border border-gr-border rounded-sm px-3 py-2.5 text-sm text-gr-text focus:outline-none focus:border-gr-accent">
                <option value="">Choose a draft...</option>
                {posts.map(p => <option key={p.id} value={p.id}>{p.title}</option>)}
              </select>
            </div>
            <Input label="Release Date & Time" type="datetime-local" value={releaseAt} onChange={e => setReleaseAt(e.target.value)} />
            <Textarea label="Teaser Text (optional)" value={teaserText} onChange={e => setTeaserText(e.target.value)} placeholder="Something new is coming..." rows={2} />
            <Button className="w-full" onClick={handleCreate} loading={loading} disabled={!postId || !releaseAt}>
              Schedule Drop
            </Button>
          </div>
        </div>
      )}

      {drops.length > 0 ? (
        <div className="space-y-3">
          {drops.map(drop => {
            const isLive = new Date(drop.release_at) <= new Date()
            return (
              <div key={drop.id} className="bg-gr-card border border-gr-border rounded-sm p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-medium">{(drop.posts as any)?.title}</h3>
                    {drop.teaser_text && <p className="text-gr-dim text-sm mt-0.5">{drop.teaser_text}</p>}
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-sm ${isLive ? 'bg-gr-green/10 text-gr-green' : 'bg-gr-muted text-gr-dim'}`}>
                    {isLive ? 'LIVE' : 'SCHEDULED'}
                  </span>
                </div>
                <div className="flex items-center gap-1 mt-2 text-xs text-gr-dim">
                  <Clock className="w-3 h-3" />
                  {isLive ? 'Dropped ' : 'Drops '}{formatRelativeTime(drop.release_at)}
                </div>
              </div>
            )
          })}
        </div>
      ) : !creating && (
        <div className="text-center py-16 border border-dashed border-gr-border rounded-sm">
          <Clock className="w-12 h-12 text-gr-dim mx-auto mb-3" />
          <h3 className="font-display text-xl font-bold mb-2">No drops scheduled</h3>
          <p className="text-gr-dim text-sm">Schedule future releases to build hype.</p>
        </div>
      )}
    </div>
  )
}
