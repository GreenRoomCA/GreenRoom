'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { CATEGORIES, formatPrice } from '@/lib/utils'
import { Upload, AlertCircle, CheckCircle } from 'lucide-react'

interface UploadState {
  uploadId: string
  url: string
  status: 'idle' | 'uploading' | 'processing' | 'ready' | 'error'
  progress: number
  playbackId?: string
  assetId?: string
}

export default function UploadPage() {
  const supabase = createClient()
  const router = useRouter()

  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [price, setPrice] = useState('9.99')
  const [category, setCategory] = useState('Full Set')
  const [city, setCity] = useState('')
  const [venue, setVenue] = useState('')
  const [showDate, setShowDate] = useState('')
  const [isSubIncluded, setIsSubIncluded] = useState(true)
  const [isOneTimePurchase, setIsOneTimePurchase] = useState(true)

  const [preview, setPreview] = useState<UploadState>({ uploadId: '', url: '', status: 'idle', progress: 0 })
  const [full, setFull] = useState<UploadState>({ uploadId: '', url: '', status: 'idle', progress: 0 })

  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [creatorId, setCreatorId] = useState('')

  useEffect(() => {
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (user) {
        supabase.from('creators').select('id').eq('user_id', user.id).single()
          .then(({ data }) => { if (data) setCreatorId(data.id) })
      }
    })
  }, [])

  const initUpload = async (isPreview: boolean) => {
    const res = await fetch('/api/mux/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isPreview }),
    })
    const { uploadId, url } = await res.json()
    if (isPreview) {
      setPreview(prev => ({ ...prev, uploadId, url, status: 'idle' }))
    } else {
      setFull(prev => ({ ...prev, uploadId, url, status: 'idle' }))
    }
    return { uploadId, url }
  }

  const handleFileUpload = async (file: File, isPreview: boolean) => {
    // Validate preview duration client-side (best effort)
    if (isPreview && file.type.startsWith('video/')) {
      const duration = await getVideoDuration(file)
      if (duration > 61) {
        setError('Preview clip must be 60 seconds or less.')
        return
      }
    }

    const { url } = await initUpload(isPreview)
    const setter = isPreview ? setPreview : setFull

    setter(prev => ({ ...prev, status: 'uploading', progress: 0 }))

    const xhr = new XMLHttpRequest()
    xhr.open('PUT', url, true)

    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) {
        setter(prev => ({ ...prev, progress: Math.round((e.loaded / e.total) * 100) }))
      }
    }

    xhr.onload = async () => {
      if (xhr.status === 200) {
        setter(prev => ({ ...prev, status: 'processing' }))
        // Poll for asset readiness
        pollAsset(isPreview)
      } else {
        setter(prev => ({ ...prev, status: 'error' }))
      }
    }

    xhr.setRequestHeader('Content-Type', file.type)
    xhr.send(file)
  }

  const pollAsset = async (isPreview: boolean) => {
    const state = isPreview ? preview : full
    const setter = isPreview ? setPreview : setFull
    let attempts = 0

    const poll = async () => {
      attempts++
      if (attempts > 60) { setter(prev => ({ ...prev, status: 'error' })); return }

      const res = await fetch(`/api/mux/asset-status?uploadId=${isPreview ? preview.uploadId : full.uploadId}`)
      const { status, playbackId, assetId } = await res.json()

      if (status === 'ready') {
        setter(prev => ({ ...prev, status: 'ready', playbackId, assetId }))
      } else {
        setTimeout(poll, 3000)
      }
    }
    poll()
  }

  const getVideoDuration = (file: File): Promise<number> => {
    return new Promise(resolve => {
      const video = document.createElement('video')
      video.src = URL.createObjectURL(file)
      video.onloadedmetadata = () => {
        resolve(video.duration)
        URL.revokeObjectURL(video.src)
      }
    })
  }

  const handlePublish = async (status: 'draft' | 'published') => {
    if (!preview.playbackId || !full.playbackId) {
      setError('Both preview and full set must be uploaded and processed.')
      return
    }
    if (!title) { setError('Title is required.'); return }

    setSaving(true)
    setError('')

    const { error: insertError } = await supabase.from('posts').insert({
      creator_id: creatorId,
      title,
      description,
      preview_mux_asset_id: preview.assetId,
      preview_mux_playback_id: preview.playbackId,
      full_mux_asset_id: full.assetId,
      full_mux_playback_id: full.playbackId,
      thumbnail_url: `https://image.mux.com/${preview.playbackId}/thumbnail.jpg`,
      price: parseFloat(price),
      is_subscription_included: isSubIncluded,
      is_one_time_purchase_enabled: isOneTimePurchase,
      category,
      city: city || null,
      venue: venue || null,
      show_date: showDate || null,
      status,
    })

    if (insertError) {
      setError(insertError.message)
    } else {
      router.push('/dashboard')
    }
    setSaving(false)
  }

  const UploadBox = ({ isPreview }: { isPreview: boolean }) => {
    const state = isPreview ? preview : full
    return (
      <div className="border-2 border-dashed border-gr-border rounded-sm p-8 text-center hover:border-gr-dim transition-colors">
        {state.status === 'idle' && (
          <>
            <Upload className="w-10 h-10 text-gr-dim mx-auto mb-3" />
            <p className="text-sm text-gr-text font-medium mb-1">
              {isPreview ? 'Upload Preview Clip (≤60s)' : 'Upload Full Set'}
            </p>
            <p className="text-xs text-gr-dim mb-4">{isPreview ? 'MP4, MOV · max 60 seconds' : 'MP4, MOV · any duration'}</p>
            <label className="cursor-pointer">
              <Button size="sm" variant="outline" as="span">Choose File</Button>
              <input
                type="file"
                accept="video/*"
                className="hidden"
                onChange={e => e.target.files?.[0] && handleFileUpload(e.target.files[0], isPreview)}
              />
            </label>
          </>
        )}
        {state.status === 'uploading' && (
          <div>
            <div className="h-2 bg-gr-muted rounded-full mb-3">
              <div className="h-full bg-gr-accent rounded-full transition-all" style={{ width: `${state.progress}%` }} />
            </div>
            <p className="text-sm text-gr-dim">Uploading... {state.progress}%</p>
          </div>
        )}
        {state.status === 'processing' && (
          <div className="flex flex-col items-center gap-2">
            <div className="w-8 h-8 border-2 border-gr-accent border-t-transparent rounded-full animate-spin" />
            <p className="text-sm text-gr-dim">Processing video...</p>
          </div>
        )}
        {state.status === 'ready' && (
          <div className="flex flex-col items-center gap-2 text-gr-green">
            <CheckCircle className="w-10 h-10" />
            <p className="text-sm font-medium">Ready!</p>
          </div>
        )}
        {state.status === 'error' && (
          <div className="flex flex-col items-center gap-2 text-gr-red">
            <AlertCircle className="w-8 h-8" />
            <p className="text-sm">Upload failed. Try again.</p>
            <Button size="sm" variant="outline" onClick={() => {
              const setter = isPreview ? setPreview : setFull
              setter(prev => ({ ...prev, status: 'idle' }))
            }}>Retry</Button>
          </div>
        )}
      </div>
    )
  }

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="font-display text-3xl font-bold mb-2">Upload Set</h1>
      <p className="text-gr-dim mb-8">Turn your live performance into a product.</p>

      <div className="space-y-6">
        {/* Videos */}
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-gr-dim uppercase tracking-wider mb-2">Preview Clip</p>
            <UploadBox isPreview={true} />
          </div>
          <div>
            <p className="text-xs text-gr-dim uppercase tracking-wider mb-2">Full Set</p>
            <UploadBox isPreview={false} />
          </div>
        </div>

        {/* Metadata */}
        <div className="space-y-4">
          <Input label="Title" value={title} onChange={e => setTitle(e.target.value)} placeholder="Comedy Cellar — March 2026" />
          <Textarea label="Description" value={description} onChange={e => setDescription(e.target.value)} placeholder="New material from last week's late show..." rows={3} />

          <div className="grid grid-cols-2 gap-4">
            <Input label="City" value={city} onChange={e => setCity(e.target.value)} placeholder="New York City" />
            <Input label="Venue" value={venue} onChange={e => setVenue(e.target.value)} placeholder="Comedy Cellar" />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Input label="Show Date" type="date" value={showDate} onChange={e => setShowDate(e.target.value)} />
            <div className="space-y-1.5">
              <label className="block text-xs font-medium text-gr-dim uppercase tracking-wider">Category</label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value)}
                className="w-full bg-gr-surface border border-gr-border rounded-sm px-3 py-2.5 text-sm text-gr-text focus:outline-none focus:border-gr-accent"
              >
                {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
          </div>
        </div>

        {/* Pricing */}
        <div className="bg-gr-card border border-gr-border rounded-sm p-4 space-y-4">
          <h3 className="font-medium">Pricing & Access</h3>

          <Input
            label="Price (USD)"
            type="number"
            min="0"
            step="0.01"
            value={price}
            onChange={e => setPrice(e.target.value)}
          />

          <div className="space-y-3">
            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <p className="text-sm font-medium">Subscription Included</p>
                <p className="text-xs text-gr-dim">Subscribers get access to this set</p>
              </div>
              <div
                onClick={() => setIsSubIncluded(!isSubIncluded)}
                className={`w-10 h-6 rounded-full transition-colors cursor-pointer relative ${isSubIncluded ? 'bg-gr-accent' : 'bg-gr-muted'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${isSubIncluded ? 'translate-x-5' : 'translate-x-1'}`} />
              </div>
            </label>

            <label className="flex items-center justify-between cursor-pointer">
              <div>
                <p className="text-sm font-medium">One-Time Purchase</p>
                <p className="text-xs text-gr-dim">Fans can buy this set directly</p>
              </div>
              <div
                onClick={() => setIsOneTimePurchase(!isOneTimePurchase)}
                className={`w-10 h-6 rounded-full transition-colors cursor-pointer relative ${isOneTimePurchase ? 'bg-gr-accent' : 'bg-gr-muted'}`}
              >
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-transform ${isOneTimePurchase ? 'translate-x-5' : 'translate-x-1'}`} />
              </div>
            </label>
          </div>
        </div>

        {error && (
          <div className="text-gr-red text-sm bg-gr-red/10 border border-gr-red/20 px-3 py-2 rounded-sm flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0" />
            {error}
          </div>
        )}

        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => handlePublish('draft')}
            loading={saving}
            disabled={saving}
          >
            Save Draft
          </Button>
          <Button
            className="flex-1"
            onClick={() => handlePublish('published')}
            loading={saving}
            disabled={saving}
          >
            Publish Set
          </Button>
        </div>
      </div>
    </div>
  )
}
