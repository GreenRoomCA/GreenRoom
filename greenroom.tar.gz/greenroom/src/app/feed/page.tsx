import { createClient } from '@/lib/supabase/server'
import { VideoFeed } from '@/components/feed/video-feed'
import { MobileNav } from '@/components/shared/navbar'
import type { Post, Creator } from '@/types'
import Link from 'next/link'
import { Mic2, SlidersHorizontal } from 'lucide-react'
import { CATEGORIES } from '@/lib/utils'

interface FeedPageProps {
  searchParams: { category?: string }
}

export default async function FeedPage({ searchParams }: FeedPageProps) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const category = searchParams.category

  let query = supabase
    .from('posts')
    .select(`
      *,
      creator:creators(*)
    `)
    .eq('status', 'published')
    .not('preview_mux_playback_id', 'is', null)
    .order('created_at', { ascending: false })
    .limit(30)

  if (category) {
    query = query.eq('category', category)
  }

  const { data: posts } = await query

  // Get user's likes and purchases if logged in
  let likedPostIds: Set<string> = new Set()
  let accessiblePostIds: Set<string> = new Set()

  if (user && posts) {
    const [likesRes, purchasesRes, subsRes] = await Promise.all([
      supabase.from('likes').select('post_id').eq('user_id', user.id),
      supabase.from('purchases').select('post_id').eq('user_id', user.id),
      supabase.from('subscriptions').select('creator_id').eq('user_id', user.id).eq('status', 'active'),
    ])

    likedPostIds = new Set(likesRes.data?.map(l => l.post_id) || [])
    const purchasedPostIds = new Set(purchasesRes.data?.map(p => p.post_id) || [])
    const subscribedCreatorIds = new Set(subsRes.data?.map(s => s.creator_id) || [])

    posts?.forEach(post => {
      if (purchasedPostIds.has(post.id)) {
        accessiblePostIds.add(post.id)
      }
      if (post.is_subscription_included && subscribedCreatorIds.has(post.creator_id)) {
        accessiblePostIds.add(post.id)
      }
      if (post.price === 0) {
        accessiblePostIds.add(post.id)
      }
    })
  }

  const enrichedPosts = (posts || []).map(post => ({
    ...post,
    is_liked: likedPostIds.has(post.id),
    has_access: accessiblePostIds.has(post.id),
  })) as (Post & { creator: Creator })[]

  return (
    <div className="bg-gr-bg">
      {/* Top overlay nav for feed */}
      <div className="fixed top-0 left-0 right-0 z-30 pt-safe">
        <div className="flex items-center justify-between px-4 py-3">
          <Link href="/" className="flex items-center gap-1.5">
            <Mic2 className="w-5 h-5 text-gr-accent" />
            <span className="font-display font-bold text-white text-lg tracking-tight">GreenRoom</span>
          </Link>

          {/* Category filter pills */}
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar max-w-[60vw]">
            <Link
              href="/feed"
              className={`text-xs px-2.5 py-1 rounded-full whitespace-nowrap transition-colors ${
                !category ? 'bg-gr-accent text-gr-bg font-medium' : 'text-white/60 hover:text-white'
              }`}
            >
              All
            </Link>
            {CATEGORIES.slice(0, 4).map(cat => (
              <Link
                key={cat}
                href={`/feed?category=${encodeURIComponent(cat)}`}
                className={`text-xs px-2.5 py-1 rounded-full whitespace-nowrap transition-colors ${
                  category === cat ? 'bg-gr-accent text-gr-bg font-medium' : 'text-white/60 hover:text-white'
                }`}
              >
                {cat}
              </Link>
            ))}
          </div>
        </div>
      </div>

      <VideoFeed posts={enrichedPosts} currentUserId={user?.id || null} />

      <MobileNav />
    </div>
  )
}
