import { redirect } from 'next/navigation'
import Link from 'next/link'
import { createServerClient } from '@/lib/supabase/server'
import { Play, Lock, Calendar } from 'lucide-react'
import { formatShowDate, formatDuration, getPublicThumbnailUrl } from '@/lib/utils'

export default async function LibraryPage() {
  const supabase = await createServerClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    redirect('/auth/login?redirect=/library')
  }

  // Get purchased posts
  const { data: purchases } = await supabase
    .from('purchases')
    .select(`
      id, created_at, amount_paid,
      posts!inner (
        id, title, show_date, venue, city, duration_seconds,
        full_mux_playback_id, preview_mux_playback_id,
        creators!inner (display_name, username)
      )
    `)
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })

  // Get bundle purchases
  const { data: bundlePurchases } = await supabase
    .from('bundle_purchases')
    .select(`
      id, created_at, amount_paid,
      bundles!inner (
        id, title,
        creators!inner (display_name, username),
        bundle_posts!inner (
          posts!inner (
            id, title, show_date, full_mux_playback_id, preview_mux_playback_id, duration_seconds
          )
        )
      )
    `)
    .eq('user_id', user.id)
    .order('created_at', { ascending: false })

  // Get active subscriptions
  const { data: subscriptions } = await supabase
    .from('subscriptions')
    .select(`
      id, current_period_end, status,
      creators!inner (id, display_name, username, avatar_url)
    `)
    .eq('user_id', user.id)
    .eq('status', 'active')

  const totalItems = (purchases?.length || 0) + (bundlePurchases?.length || 0)

  return (
    <div className="min-h-screen bg-gr-bg">
      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="font-display text-3xl font-bold text-white mb-1">Your Library</h1>
          <p className="text-gr-muted">
            {totalItems} {totalItems === 1 ? 'set' : 'sets'} unlocked
          </p>
        </div>

        {/* Active Subscriptions */}
        {subscriptions && subscriptions.length > 0 && (
          <section className="mb-8">
            <h2 className="text-lg font-semibold text-white mb-3">Active Subscriptions</h2>
            <div className="space-y-2">
              {subscriptions.map((sub) => {
                const creator = sub.creators as any
                return (
                  <div
                    key={sub.id}
                    className="flex items-center justify-between p-4 bg-gr-card rounded-xl border border-white/5"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-gr-surface flex items-center justify-center text-gr-accent font-bold">
                        {creator.display_name[0]}
                      </div>
                      <div>
                        <Link
                          href={`/creator/${creator.username}`}
                          className="font-medium text-white hover:text-gr-accent transition-colors"
                        >
                          {creator.display_name}
                        </Link>
                        <p className="text-xs text-gr-muted">
                          Renews {new Date(sub.current_period_end).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs bg-gr-accent/10 text-gr-accent px-2 py-1 rounded-full font-medium">
                      Active
                    </span>
                  </div>
                )
              })}
            </div>
          </section>
        )}

        {/* Individual Sets */}
        {purchases && purchases.length > 0 && (
          <section className="mb-8">
            <h2 className="text-lg font-semibold text-white mb-3">Individual Sets</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {purchases.map((purchase) => {
                const post = purchase.posts as any
                const creator = post.creators
                return (
                  <PostCard
                    key={purchase.id}
                    post={post}
                    creator={creator}
                    watchPath={`/watch/${post.id}`}
                    purchasedAt={purchase.created_at}
                  />
                )
              })}
            </div>
          </section>
        )}

        {/* Bundles */}
        {bundlePurchases && bundlePurchases.length > 0 && (
          <section className="mb-8">
            <h2 className="text-lg font-semibold text-white mb-3">Bundles</h2>
            <div className="space-y-4">
              {bundlePurchases.map((bp) => {
                const bundle = bp.bundles as any
                const creator = bundle.creators
                const posts = bundle.bundle_posts?.map((bp: any) => bp.posts) || []
                return (
                  <div key={bp.id} className="bg-gr-card rounded-xl border border-white/5 p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-white">{bundle.title}</h3>
                        <p className="text-sm text-gr-muted">by {creator.display_name}</p>
                      </div>
                      <span className="text-xs text-gr-muted">{posts.length} sets</span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {posts.map((post: any) => (
                        <Link
                          key={post.id}
                          href={`/watch/${post.id}`}
                          className="flex items-center gap-3 p-2 rounded-lg hover:bg-white/5 transition-colors group"
                        >
                          <div className="w-16 h-10 rounded bg-gr-surface flex-shrink-0 overflow-hidden relative">
                            {post.preview_mux_playback_id && (
                              <img
                                src={getPublicThumbnailUrl(post.preview_mux_playback_id)}
                                alt={post.title}
                                className="w-full h-full object-cover"
                              />
                            )}
                            <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Play size={14} className="text-white" />
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-white truncate">{post.title}</p>
                            {post.duration_seconds && (
                              <p className="text-xs text-gr-muted">{formatDuration(post.duration_seconds)}</p>
                            )}
                          </div>
                        </Link>
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          </section>
        )}

        {/* Empty state */}
        {totalItems === 0 && (!subscriptions || subscriptions.length === 0) && (
          <div className="text-center py-20">
            <Lock size={40} className="text-gr-muted mx-auto mb-4" />
            <h2 className="font-display text-xl font-semibold text-white mb-2">
              Your library is empty
            </h2>
            <p className="text-gr-muted mb-6">
              Unlock full sets from the comedians you love.
            </p>
            <Link
              href="/feed"
              className="inline-block bg-gr-accent text-black font-semibold px-6 py-2.5 rounded-full hover:bg-gr-accent/90 transition-colors"
            >
              Browse the Feed
            </Link>
          </div>
        )}
      </div>
    </div>
  )
}

function PostCard({
  post,
  creator,
  watchPath,
  purchasedAt,
}: {
  post: any
  creator: any
  watchPath: string
  purchasedAt: string
}) {
  return (
    <Link href={watchPath} className="group block">
      <div className="bg-gr-card rounded-xl border border-white/5 overflow-hidden hover:border-white/10 transition-all">
        {/* Thumbnail */}
        <div className="relative aspect-video bg-gr-surface">
          {post.preview_mux_playback_id && (
            <img
              src={getPublicThumbnailUrl(post.preview_mux_playback_id)}
              alt={post.title}
              className="w-full h-full object-cover"
            />
          )}
          <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
            <div className="w-12 h-12 rounded-full bg-gr-accent flex items-center justify-center">
              <Play size={20} className="text-black ml-1" />
            </div>
          </div>
          {post.duration_seconds && (
            <span className="absolute bottom-2 right-2 text-xs bg-black/70 text-white px-1.5 py-0.5 rounded">
              {formatDuration(post.duration_seconds)}
            </span>
          )}
        </div>

        {/* Info */}
        <div className="p-3">
          <h3 className="font-semibold text-white text-sm line-clamp-1 group-hover:text-gr-accent transition-colors">
            {post.title}
          </h3>
          <p className="text-xs text-gr-muted mt-0.5">{creator.display_name}</p>
          {post.show_date && (
            <p className="text-xs text-gr-muted mt-1 flex items-center gap-1">
              <Calendar size={10} />
              {formatShowDate(post.show_date)}
            </p>
          )}
        </div>
      </div>
    </Link>
  )
}
