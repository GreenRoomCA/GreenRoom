'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useRouter, useSearchParams } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Mic2, User, Mic } from 'lucide-react'
import { cn } from '@/lib/utils'

export default function SignupPage() {
  const searchParams = useSearchParams()
  const defaultRole = searchParams.get('role') || 'viewer'

  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState<'viewer' | 'creator'>(defaultRole as 'viewer' | 'creator')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    const { data, error: signupError } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    })

    if (signupError) {
      setError(signupError.message)
      setLoading(false)
      return
    }

    // Update user role
    if (data.user) {
      await supabase.from('users').update({ role }).eq('id', data.user.id)

      if (role === 'creator') {
        router.push('/creator/onboarding')
      } else {
        router.push('/feed')
      }
    } else {
      setSuccess(true)
    }
    setLoading(false)
  }

  if (success) {
    return (
      <div className="min-h-screen bg-gr-bg flex items-center justify-center px-4">
        <div className="text-center max-w-sm">
          <Mic2 className="w-12 h-12 text-gr-accent mx-auto mb-4" />
          <h2 className="font-display text-2xl font-bold mb-2">Check your email</h2>
          <p className="text-gr-dim">We sent a confirmation link to {email}. Click it to activate your account.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gr-bg flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        <div className="text-center mb-10">
          <Link href="/" className="inline-flex items-center gap-2 mb-6">
            <Mic2 className="w-6 h-6 text-gr-accent" />
            <span className="font-display text-xl font-bold">GreenRoom</span>
          </Link>
          <h1 className="font-display text-3xl font-bold">Create account</h1>
          <p className="text-gr-dim mt-2 text-sm">Join GreenRoom for free.</p>
        </div>

        {/* Role selector */}
        <div className="grid grid-cols-2 gap-2 mb-6">
          {([
            { val: 'viewer', icon: <User className="w-4 h-4" />, label: 'Fan', sub: 'Watch sets' },
            { val: 'creator', icon: <Mic className="w-4 h-4" />, label: 'Comedian', sub: 'Upload sets' },
          ] as const).map(opt => (
            <button
              key={opt.val}
              type="button"
              onClick={() => setRole(opt.val)}
              className={cn(
                'border rounded-sm p-4 flex flex-col items-center gap-1.5 transition-all',
                role === opt.val
                  ? 'border-gr-accent bg-gr-accent/10 text-gr-accent'
                  : 'border-gr-border text-gr-dim hover:border-gr-dim'
              )}
            >
              {opt.icon}
              <span className="text-sm font-medium">{opt.label}</span>
              <span className="text-xs opacity-70">{opt.sub}</span>
            </button>
          ))}
        </div>

        <form onSubmit={handleSignup} className="space-y-4">
          <Input
            label="Email"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="you@example.com"
            required
          />
          <Input
            label="Password"
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="Min. 8 characters"
            minLength={8}
            required
          />

          {error && (
            <div className="text-gr-red text-sm bg-gr-red/10 border border-gr-red/20 px-3 py-2 rounded-sm">
              {error}
            </div>
          )}

          <Button type="submit" className="w-full" size="lg" loading={loading}>
            {role === 'creator' ? 'Create Creator Account' : 'Create Fan Account'}
          </Button>
        </form>

        <p className="text-center text-sm text-gr-dim mt-6">
          Already have an account?{' '}
          <Link href="/auth/login" className="text-gr-accent hover:underline">
            Sign in
          </Link>
        </p>
      </div>
    </div>
  )
}
