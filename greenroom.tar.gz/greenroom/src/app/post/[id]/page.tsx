import { createClient } from '@/lib/supabase/server'
import { canUserAccessPost } from '@/lib/utils/access'
import { notFound, redirect } from 'next/navigation'
import Image from 'next/image'
import Link from 'next/link'
import { formatPrice, formatShowDate } from '@/lib/utils'
import { CategoryBadge } from '@/components/ui/badge'
import { MapPin, Calendar, Eye, Heart, Ticket } from 'lucide-react'
import { PostActions } from './post-actions'
import type { Bundle } from '@/types'

interface Props { params: { id: string } }

export default async function PostPage({ params }: Props) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: post } = await supabase
    .from('posts')
    .select('*, creator:creators(*)')
    .eq('id', params.id)
    .eq('status', 'published')
    .single()

  if (!post) notFound()

  const { has_access } = await canUserAccessPost(user?.id || null, params.id)

  if (has_access) redirect(`/watch/${params.id}`)

  const { data: bundles } = await supabase
    .from('bundles')
    .select('*, bundle_posts!inner(post_id)')
    .eq('bundle_posts.post_id', params.id)
    .eq('is_active', true)

  const creator = post.creator as any

  return (
    <div className="min-h-screen bg-gr-bg pt-14">
      <div className="max-w-3xl mx-auto px-4 py-8">
        {/* Thumbnail */}
        <div className="aspect-video bg-gr-surface rounded-sm overflow-hidden relative mb-6">
          {post.thumbnail_url ? (
            <Image src={post.thumbnail_url} alt={post.title} fill className="object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-6xl">🎤</div>
          )}
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <div className="text-center">
              <p className="text-white/60 text-sm mb-2">60-second preview available in feed</p>
              <Link href="/feed" className="text-gr-accent text-sm underline">Browse Feed</Link>
            </div>
          </div>
        </div>

        {/* Meta */}
        <div className="mb-4">
          <CategoryBadge category={post.category} />
        </div>
        <h1 className="font-display text-3xl font-bold mb-2">{post.title}</h1>
        <div className="flex items-center gap-4 text-sm text-gr-dim mb-4">
          {post.city && <span className="flex items-center gap-1"><MapPin className="w-4 h-4" />{post.city}{post.venue ? ` · ${post.venue}` : ''}</span>}
          {post.show_date && <span className="flex items-center gap-1"><Calendar className="w-4 h-4" />{formatShowDate(post.show_date)}</span>}
        </div>
        <div className="flex items-center gap-4 text-sm text-gr-dim mb-6">
          <span className="flex items-center gap-1"><Eye className="w-4 h-4" />{post.view_count}</span>
          <span className="flex items-center gap-1"><Heart className="w-4 h-4" />{post.like_count}</span>
        </div>

        {/* Creator */}
        <Link href={`/creator/${creator.username}`} className="flex items-center gap-3 mb-6 group">
          <div className="w-10 h-10 rounded-full bg-gr-muted flex items-center justify-center font-bold text-gr-accent">
            {creator.display_name[0]}
          </div>
          <div>
            <p className="font-medium group-hover:text-gr-accent transition-colors">{creator.display_name}</p>
            <p className="text-xs text-gr-dim">@{creator.username}</p>
          </div>
        </Link>

        {post.description && <p className="text-gr-dim mb-8">{post.description}</p>}

        {/* Missed show prompt */}
        <div className="bg-gr-card border border-gr-border rounded-sm p-4 mb-6 text-center">
          <p className="text-gr-dim text-sm">🎤 Missed this show? Watch the full set here.</p>
        </div>

        {/* Purchase options */}
        <PostActions
          post={post as any}
          creator={creator}
          bundles={(bundles || []) as Bundle[]}
          currentUserId={user?.id || null}
        />

        {/* Ticket link */}
        {creator.ticket_link && (
          <a href={creator.ticket_link} target="_blank" rel="noopener noreferrer"
            className="mt-4 flex items-center justify-center gap-2 text-sm text-gr-dim hover:text-gr-text transition-colors">
            <Ticket className="w-4 h-4" />
            See {creator.display_name} live
          </a>
        )}
      </div>
    </div>
  )
}
