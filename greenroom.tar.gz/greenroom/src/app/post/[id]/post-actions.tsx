'use client'
import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { formatPrice } from '@/lib/utils'
import type { Post, Creator, Bundle } from '@/types'
import { Lock, Crown, Zap } from 'lucide-react'

interface Props {
  post: Post
  creator: Creator
  bundles: Bundle[]
  currentUserId: string | null
}

export function PostActions({ post, creator, bundles, currentUserId }: Props) {
  const [loading, setLoading] = useState<string | null>(null)

  const checkout = async (endpoint: string, body: object) => {
    if (!currentUserId) { window.location.href = '/auth/login'; return }
    setLoading(endpoint)
    const res = await fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    const { url, error } = await res.json()
    if (url) window.location.href = url
    else { alert(error || 'Something went wrong'); setLoading(null) }
  }

  return (
    <div className="space-y-3">
      {post.is_one_time_purchase_enabled && (
        <div className="border border-gr-border rounded-sm p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2"><Zap className="w-4 h-4 text-gr-accent" /><span className="font-medium">Buy This Set</span></div>
            <span className="font-display text-xl font-bold text-gr-accent">{formatPrice(post.price)}</span>
          </div>
          <Button className="w-full" onClick={() => checkout('/api/stripe/checkout/post', { postId: post.id })} loading={loading === '/api/stripe/checkout/post'}>
            Buy for {formatPrice(post.price)}
          </Button>
        </div>
      )}
      {post.is_subscription_included && (
        <div className="border border-gr-accent/40 bg-gr-accent/5 rounded-sm p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2"><Crown className="w-4 h-4 text-gr-accent" /><span className="font-medium">Subscribe to {creator.display_name}</span></div>
            <span className="font-display text-xl font-bold text-gr-accent">{formatPrice(creator.subscription_price)}<span className="text-xs text-gr-dim">/mo</span></span>
          </div>
          <Button className="w-full" onClick={() => checkout('/api/stripe/checkout/subscription', { creatorId: creator.id })} loading={loading === '/api/stripe/checkout/subscription'}>
            Subscribe · {formatPrice(creator.subscription_price)}/mo
          </Button>
        </div>
      )}
      {bundles.map(bundle => (
        <div key={bundle.id} className="border border-gr-border rounded-sm p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium">{bundle.title}</span>
            <span className="font-bold">{formatPrice(bundle.price)}</span>
          </div>
          {bundle.description && <p className="text-xs text-gr-dim mb-3">{bundle.description}</p>}
          <Button variant="outline" className="w-full" onClick={() => checkout('/api/stripe/checkout/bundle', { bundleId: bundle.id })} loading={loading === '/api/stripe/checkout/bundle'}>
            Buy Bundle
          </Button>
        </div>
      ))}
    </div>
  )
}
