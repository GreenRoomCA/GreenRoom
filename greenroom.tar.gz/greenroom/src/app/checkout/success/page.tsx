'use client'

import { useEffect, useState, Suspense } from 'react'
import { useSearchParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { CheckCircle, Loader2 } from 'lucide-react'

function SuccessContent() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const [countdown, setCountdown] = useState(5)

  const type = searchParams.get('type')
  const postId = searchParams.get('postId')
  const creatorId = searchParams.get('creatorId')
  const bundleId = searchParams.get('bundleId')

  const redirectPath =
    type === 'post' && postId
      ? `/watch/${postId}`
      : type === 'bundle' && bundleId
      ? '/library'
      : '/library'

  useEffect(() => {
    const interval = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          clearInterval(interval)
          router.push(redirectPath)
        }
        return c - 1
      })
    }, 1000)
    return () => clearInterval(interval)
  }, [redirectPath, router])

  const messages: Record<string, { title: string; subtitle: string }> = {
    post: {
      title: "You're in! Set unlocked.",
      subtitle: "Enjoy the full set.",
    },
    subscription: {
      title: 'Subscribed!',
      subtitle: "You now have unlimited access to all their sets.",
    },
    bundle: {
      title: 'Bundle unlocked!',
      subtitle: 'All sets in this bundle are now in your library.',
    },
  }

  const msg = messages[type || ''] || {
    title: 'Payment successful!',
    subtitle: 'Your content is ready to watch.',
  }

  return (
    <div className="min-h-screen bg-gr-bg flex items-center justify-center px-4">
      <div className="text-center max-w-sm">
        {/* Success icon */}
        <div className="flex justify-center mb-6">
          <div className="w-20 h-20 rounded-full bg-green-500/10 flex items-center justify-center">
            <CheckCircle size={40} className="text-green-400" />
          </div>
        </div>

        <h1 className="font-display text-3xl font-bold text-white mb-2">{msg.title}</h1>
        <p className="text-gr-muted mb-8">{msg.subtitle}</p>

        {/* Redirect countdown */}
        <div className="bg-gr-card rounded-xl border border-white/5 p-4 mb-6 text-sm text-gr-muted">
          Redirecting in <span className="text-white font-semibold">{countdown}</span>s...
        </div>

        <div className="flex flex-col gap-3">
          <Link
            href={redirectPath}
            className="w-full bg-gr-accent text-black font-semibold py-3 px-6 rounded-full hover:bg-gr-accent/90 transition-colors"
          >
            {type === 'post' ? 'Watch Now' : 'Go to Library'}
          </Link>
          <Link
            href="/feed"
            className="w-full border border-white/10 text-white py-3 px-6 rounded-full hover:bg-white/5 transition-colors"
          >
            Back to Feed
          </Link>
        </div>
      </div>
    </div>
  )
}

export default function CheckoutSuccessPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen bg-gr-bg flex items-center justify-center">
          <Loader2 size={24} className="animate-spin text-gr-accent" />
        </div>
      }
    >
      <SuccessContent />
    </Suspense>
  )
}
