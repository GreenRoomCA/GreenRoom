import type { Metadata } from 'next'
import { Playfair_Display, DM_Sans } from 'next/font/google'
import './globals.css'
import { Toaster } from '@/components/ui/toaster'

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-display',
  weight: ['400', '600', '700', '900'],
})

const dmSans = DM_Sans({
  subsets: ['latin'],
  variable: '--font-body',
  weight: ['300', '400', '500', '600'],
})

export const metadata: Metadata = {
  title: 'GreenRoom — Missed the show? Watch the set here.',
  description: 'Discover stand-up comedy sets from real shows. Watch 60-second previews, unlock full sets, and subscribe to your favorite comedians.',
  openGraph: {
    title: 'GreenRoom',
    description: 'Missed the show? Watch the set here.',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className={`${playfair.variable} ${dmSans.variable} font-body bg-gr-bg text-gr-text antialiased`}>
        {children}
        <Toaster />
      </body>
    </html>
  )
}
