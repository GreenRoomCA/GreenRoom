-- ============================================================
-- GreenRoom Database Schema
-- ============================================================
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

create type user_role as enum ('viewer', 'creator', 'admin');
create type post_status as enum ('draft', 'published', 'scheduled');
create type view_type as enum ('preview', 'full');
create type subscription_status as enum ('active', 'canceled', 'past_due', 'incomplete');
create type badge_level as enum ('supporter', 'real_fan', 'top_supporter', 'day_one');

create table public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  role user_role not null default 'viewer',
  username text unique,
  display_name text,
  avatar_url text,
  created_at timestamptz not null default now()
);

create table public.creators (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null unique references public.users(id) on delete cascade,
  display_name text not null,
  username text not null unique,
  bio text,
  profile_image_url text,
  banner_image_url text,
  subscription_price numeric(10,2) default 9.99,
  stripe_account_id text,
  stripe_account_enabled boolean default false,
  ticket_link text,
  message_price numeric(10,2) default 5.00,
  watermark_enabled boolean default true,
  created_at timestamptz not null default now()
);

create table public.posts (
  id uuid primary key default uuid_generate_v4(),
  creator_id uuid not null references public.creators(id) on delete cascade,
  title text not null,
  description text,
  preview_video_url text,
  preview_mux_asset_id text,
  preview_mux_playback_id text,
  full_video_url text,
  full_mux_asset_id text,
  full_mux_playback_id text,
  thumbnail_url text,
  duration_seconds integer,
  preview_duration_seconds integer,
  price numeric(10,2) not null default 9.99,
  is_subscription_included boolean not null default true,
  is_one_time_purchase_enabled boolean not null default true,
  is_premium_add_on boolean not null default false,
  category text default 'Full Set',
  city text,
  venue text,
  show_date date,
  status post_status not null default 'draft',
  scheduled_release_at timestamptz,
  view_count integer default 0,
  like_count integer default 0,
  purchase_count integer default 0,
  created_at timestamptz not null default now()
);

create table public.purchases (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  creator_id uuid not null references public.creators(id),
  stripe_payment_intent_id text unique,
  price_paid numeric(10,2) not null,
  created_at timestamptz not null default now(),
  unique(user_id, post_id)
);

create table public.subscriptions (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  creator_id uuid not null references public.creators(id) on delete cascade,
  stripe_subscription_id text unique,
  stripe_customer_id text,
  status subscription_status not null default 'incomplete',
  current_period_end timestamptz,
  canceled_at timestamptz,
  created_at timestamptz not null default now(),
  unique(user_id, creator_id)
);

create table public.bundles (
  id uuid primary key default uuid_generate_v4(),
  creator_id uuid not null references public.creators(id) on delete cascade,
  title text not null,
  description text,
  price numeric(10,2) not null,
  thumbnail_url text,
  is_active boolean default true,
  created_at timestamptz not null default now()
);

create table public.bundle_posts (
  id uuid primary key default uuid_generate_v4(),
  bundle_id uuid not null references public.bundles(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  unique(bundle_id, post_id)
);

create table public.bundle_purchases (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  bundle_id uuid not null references public.bundles(id) on delete cascade,
  creator_id uuid not null references public.creators(id),
  stripe_payment_intent_id text unique,
  price_paid numeric(10,2) not null,
  created_at timestamptz not null default now(),
  unique(user_id, bundle_id)
);

create table public.follows (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  creator_id uuid not null references public.creators(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, creator_id)
);

create table public.views (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid references public.users(id) on delete set null,
  post_id uuid not null references public.posts(id) on delete cascade,
  creator_id uuid not null references public.creators(id),
  view_type view_type not null default 'preview',
  created_at timestamptz not null default now()
);

create table public.likes (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  post_id uuid not null references public.posts(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(user_id, post_id)
);

create table public.fan_spend (
  id uuid primary key default uuid_generate_v4(),
  user_id uuid not null references public.users(id) on delete cascade,
  creator_id uuid not null references public.creators(id) on delete cascade,
  total_spent numeric(10,2) not null default 0,
  badge_level badge_level,
  updated_at timestamptz not null default now(),
  unique(user_id, creator_id)
);

create table public.messages (
  id uuid primary key default uuid_generate_v4(),
  sender_id uuid not null references public.users(id) on delete cascade,
  receiver_id uuid not null references public.users(id) on delete cascade,
  creator_id uuid not null references public.creators(id),
  body text not null,
  is_paid boolean not null default false,
  price_paid numeric(10,2) default 0,
  stripe_payment_intent_id text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.drops (
  id uuid primary key default uuid_generate_v4(),
  post_id uuid not null unique references public.posts(id) on delete cascade,
  creator_id uuid not null references public.creators(id),
  release_at timestamptz not null,
  teaser_text text,
  created_at timestamptz not null default now()
);

create index idx_posts_creator_id on public.posts(creator_id);
create index idx_posts_status on public.posts(status);
create index idx_posts_created_at on public.posts(created_at desc);
create index idx_purchases_user_id on public.purchases(user_id);
create index idx_purchases_post_id on public.purchases(post_id);
create index idx_subscriptions_user_creator on public.subscriptions(user_id, creator_id);
create index idx_follows_user_id on public.follows(user_id);
create index idx_follows_creator_id on public.follows(creator_id);
create index idx_views_post_id on public.views(post_id);
create index idx_messages_receiver on public.messages(receiver_id);
create index idx_fan_spend_user_creator on public.fan_spend(user_id, creator_id);
create index idx_bundle_posts_bundle_id on public.bundle_posts(bundle_id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.users (id, email, role)
  values (new.id, new.email, 'viewer');
  return new;
end;
$$;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

create or replace function public.update_fan_badge(p_user_id uuid, p_creator_id uuid)
returns void language plpgsql security definer as $$
declare
  v_total numeric;
  v_badge badge_level;
begin
  select coalesce(sum(price_paid), 0) into v_total
  from (
    select price_paid from public.purchases where user_id = p_user_id and creator_id = p_creator_id
    union all
    select price_paid from public.bundle_purchases where user_id = p_user_id and creator_id = p_creator_id
    union all
    select price_paid from public.messages where sender_id = p_user_id and creator_id = p_creator_id and is_paid = true
  ) all_spend;
  if v_total >= 200 then v_badge = 'day_one';
  elsif v_total >= 100 then v_badge = 'top_supporter';
  elsif v_total >= 40 then v_badge = 'real_fan';
  elsif v_total >= 10 then v_badge = 'supporter';
  else v_badge = null;
  end if;
  insert into public.fan_spend (user_id, creator_id, total_spent, badge_level, updated_at)
  values (p_user_id, p_creator_id, v_total, v_badge, now())
  on conflict (user_id, creator_id) do update
    set total_spent = v_total, badge_level = v_badge, updated_at = now();
end;
$$;

create or replace function public.increment_view_count(p_post_id uuid)
returns void language sql security definer as $$
  update public.posts set view_count = view_count + 1 where id = p_post_id;
$$;
