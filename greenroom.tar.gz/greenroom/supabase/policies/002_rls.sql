-- ============================================================
-- Row Level Security Policies
-- ============================================================

alter table public.users enable row level security;
alter table public.creators enable row level security;
alter table public.posts enable row level security;
alter table public.purchases enable row level security;
alter table public.subscriptions enable row level security;
alter table public.bundles enable row level security;
alter table public.bundle_posts enable row level security;
alter table public.bundle_purchases enable row level security;
alter table public.follows enable row level security;
alter table public.views enable row level security;
alter table public.likes enable row level security;
alter table public.fan_spend enable row level security;
alter table public.messages enable row level security;
alter table public.drops enable row level security;

-- USERS
create policy "Users can view their own profile" on public.users for select using (auth.uid() = id);
create policy "Users can update their own profile" on public.users for update using (auth.uid() = id);
create policy "Public users basic info" on public.users for select using (true);

-- CREATORS
create policy "Anyone can view creators" on public.creators for select using (true);
create policy "Creators can update own profile" on public.creators for update using (
  user_id = auth.uid()
);
create policy "Authenticated users can create creator profile" on public.creators for insert with check (
  auth.uid() = user_id
);

-- POSTS: public can see published posts metadata; full video gated by access function
create policy "Anyone can view published posts" on public.posts for select using (
  status = 'published' OR creator_id IN (
    SELECT id FROM public.creators WHERE user_id = auth.uid()
  )
);
create policy "Creators manage own posts" on public.posts for all using (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
);

-- PURCHASES
create policy "Users see own purchases" on public.purchases for select using (user_id = auth.uid());
create policy "Users create purchases" on public.purchases for insert with check (user_id = auth.uid());

-- SUBSCRIPTIONS
create policy "Users see own subscriptions" on public.subscriptions for select using (user_id = auth.uid());
create policy "Users manage own subscriptions" on public.subscriptions for insert with check (user_id = auth.uid());
create policy "Users update own subscriptions" on public.subscriptions for update using (user_id = auth.uid());

-- BUNDLES
create policy "Anyone can view active bundles" on public.bundles for select using (is_active = true);
create policy "Creators manage own bundles" on public.bundles for all using (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
);

-- BUNDLE_POSTS
create policy "Anyone can view bundle posts" on public.bundle_posts for select using (true);
create policy "Creators manage bundle posts" on public.bundle_posts for all using (
  bundle_id IN (
    SELECT b.id FROM public.bundles b
    JOIN public.creators c ON b.creator_id = c.id
    WHERE c.user_id = auth.uid()
  )
);

-- BUNDLE_PURCHASES
create policy "Users see own bundle purchases" on public.bundle_purchases for select using (user_id = auth.uid());
create policy "Users create bundle purchases" on public.bundle_purchases for insert with check (user_id = auth.uid());

-- FOLLOWS
create policy "Anyone can view follows" on public.follows for select using (true);
create policy "Users manage own follows" on public.follows for all using (user_id = auth.uid());

-- VIEWS
create policy "Insert views" on public.views for insert with check (true);
create policy "Creators see their post views" on public.views for select using (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
  OR user_id = auth.uid()
);

-- LIKES
create policy "Anyone can see likes" on public.likes for select using (true);
create policy "Users manage own likes" on public.likes for all using (user_id = auth.uid());

-- FAN_SPEND
create policy "Users see own fan spend" on public.fan_spend for select using (user_id = auth.uid());
create policy "Creators see fan spend for their content" on public.fan_spend for select using (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
);

-- MESSAGES
create policy "Users see own messages" on public.messages for select using (
  sender_id = auth.uid() OR receiver_id = auth.uid()
);
create policy "Users send messages" on public.messages for insert with check (sender_id = auth.uid());
create policy "Receivers can mark read" on public.messages for update using (receiver_id = auth.uid());

-- DROPS
create policy "Anyone can view drops" on public.drops for select using (true);
create policy "Creators manage own drops" on public.drops for all using (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
);
