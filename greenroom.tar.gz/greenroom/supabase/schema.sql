-- ============================================================
-- GREENROOM DATABASE SCHEMA
-- Run this in Supabase SQL editor
-- ============================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ============================================================
-- USERS (extends Supabase auth.users)
-- ============================================================
CREATE TABLE public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'viewer' CHECK (role IN ('viewer', 'creator', 'admin')),
  display_name TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- CREATORS
-- ============================================================
CREATE TABLE public.creators (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE REFERENCES public.users(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  bio TEXT,
  profile_image_url TEXT,
  banner_image_url TEXT,
  subscription_price NUMERIC(10,2) DEFAULT 9.99,
  stripe_account_id TEXT,
  stripe_account_status TEXT DEFAULT 'not_connected' CHECK (stripe_account_status IN ('not_connected', 'pending', 'active')),
  ticket_link TEXT,
  instagram_handle TEXT,
  twitter_handle TEXT,
  tiktok_handle TEXT,
  website_url TEXT,
  message_price NUMERIC(10,2) DEFAULT 5.00,
  total_earnings NUMERIC(12,2) DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_creators_username ON public.creators(username);
CREATE INDEX idx_creators_user_id ON public.creators(user_id);

-- ============================================================
-- POSTS
-- ============================================================
CREATE TABLE public.posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  preview_video_url TEXT,
  preview_mux_asset_id TEXT,
  preview_mux_playback_id TEXT,
  full_video_url TEXT,
  full_mux_asset_id TEXT,
  full_mux_playback_id TEXT,
  thumbnail_url TEXT,
  duration_seconds INTEGER,
  preview_duration_seconds INTEGER,
  price NUMERIC(10,2) DEFAULT 0,
  is_free BOOLEAN NOT NULL DEFAULT FALSE,
  is_subscription_included BOOLEAN NOT NULL DEFAULT TRUE,
  is_one_time_purchase_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  is_premium_add_on BOOLEAN NOT NULL DEFAULT FALSE,
  category TEXT DEFAULT 'Full Set' CHECK (category IN ('Full Set', 'Crowd Work', 'Unreleased', 'Test Material', 'Special', 'Behind the Scenes')),
  city TEXT,
  venue TEXT,
  show_date DATE,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'published', 'scheduled')),
  scheduled_release_at TIMESTAMPTZ,
  view_count INTEGER DEFAULT 0,
  purchase_count INTEGER DEFAULT 0,
  like_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_posts_creator_id ON public.posts(creator_id);
CREATE INDEX idx_posts_status ON public.posts(status);
CREATE INDEX idx_posts_created_at ON public.posts(created_at DESC);
CREATE INDEX idx_posts_category ON public.posts(category);

-- ============================================================
-- PURCHASES
-- ============================================================
CREATE TABLE public.purchases (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  stripe_payment_intent_id TEXT UNIQUE,
  stripe_session_id TEXT,
  price_paid NUMERIC(10,2) NOT NULL,
  platform_fee NUMERIC(10,2),
  creator_earnings NUMERIC(10,2),
  status TEXT NOT NULL DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'refunded', 'failed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_purchases_user_id ON public.purchases(user_id);
CREATE INDEX idx_purchases_post_id ON public.purchases(post_id);
CREATE INDEX idx_purchases_creator_id ON public.purchases(creator_id);
CREATE UNIQUE INDEX idx_purchases_user_post ON public.purchases(user_id, post_id) WHERE status = 'completed';

-- ============================================================
-- SUBSCRIPTIONS
-- ============================================================
CREATE TABLE public.subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  stripe_subscription_id TEXT UNIQUE,
  stripe_customer_id TEXT,
  status TEXT NOT NULL CHECK (status IN ('active', 'past_due', 'canceled', 'trialing', 'incomplete')),
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  cancel_at_period_end BOOLEAN DEFAULT FALSE,
  canceled_at TIMESTAMPTZ,
  price_paid NUMERIC(10,2),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_subscriptions_user_id ON public.subscriptions(user_id);
CREATE INDEX idx_subscriptions_creator_id ON public.subscriptions(creator_id);
CREATE INDEX idx_subscriptions_status ON public.subscriptions(status);
CREATE UNIQUE INDEX idx_subscriptions_user_creator ON public.subscriptions(user_id, creator_id) WHERE status = 'active';

-- ============================================================
-- BUNDLES
-- ============================================================
CREATE TABLE public.bundles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  price NUMERIC(10,2) NOT NULL,
  thumbnail_url TEXT,
  is_active BOOLEAN DEFAULT TRUE,
  total_runtime_seconds INTEGER DEFAULT 0,
  post_count INTEGER DEFAULT 0,
  purchase_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_bundles_creator_id ON public.bundles(creator_id);

-- ============================================================
-- BUNDLE POSTS (junction)
-- ============================================================
CREATE TABLE public.bundle_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  bundle_id UUID NOT NULL REFERENCES public.bundles(id) ON DELETE CASCADE,
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  position INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(bundle_id, post_id)
);

CREATE INDEX idx_bundle_posts_bundle_id ON public.bundle_posts(bundle_id);

-- ============================================================
-- BUNDLE PURCHASES
-- ============================================================
CREATE TABLE public.bundle_purchases (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  bundle_id UUID NOT NULL REFERENCES public.bundles(id) ON DELETE CASCADE,
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  stripe_payment_intent_id TEXT UNIQUE,
  stripe_session_id TEXT,
  price_paid NUMERIC(10,2) NOT NULL,
  platform_fee NUMERIC(10,2),
  creator_earnings NUMERIC(10,2),
  status TEXT NOT NULL DEFAULT 'completed' CHECK (status IN ('pending', 'completed', 'refunded', 'failed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_bundle_purchases_user_id ON public.bundle_purchases(user_id);
CREATE INDEX idx_bundle_purchases_bundle_id ON public.bundle_purchases(bundle_id);

-- ============================================================
-- FOLLOWS
-- ============================================================
CREATE TABLE public.follows (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, creator_id)
);

CREATE INDEX idx_follows_user_id ON public.follows(user_id);
CREATE INDEX idx_follows_creator_id ON public.follows(creator_id);

-- ============================================================
-- VIEWS (analytics)
-- ============================================================
CREATE TABLE public.views (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  view_type TEXT NOT NULL CHECK (view_type IN ('preview', 'full')),
  watch_duration_seconds INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_views_post_id ON public.views(post_id);
CREATE INDEX idx_views_creator_id ON public.views(creator_id);
CREATE INDEX idx_views_created_at ON public.views(created_at DESC);

-- ============================================================
-- LIKES
-- ============================================================
CREATE TABLE public.likes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  post_id UUID NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, post_id)
);

CREATE INDEX idx_likes_post_id ON public.likes(post_id);

-- ============================================================
-- FAN SPEND (badges)
-- ============================================================
CREATE TABLE public.fan_spend (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  total_spent NUMERIC(10,2) DEFAULT 0,
  badge_level TEXT DEFAULT 'none' CHECK (badge_level IN ('none', 'supporter', 'real_fan', 'top_supporter', 'day_one')),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, creator_id)
);

CREATE INDEX idx_fan_spend_creator_id ON public.fan_spend(creator_id);

-- ============================================================
-- DROPS (scheduled content releases)
-- ============================================================
CREATE TABLE public.drops (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  post_id UUID REFERENCES public.posts(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  thumbnail_url TEXT,
  drops_at TIMESTAMPTZ NOT NULL,
  is_notified BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_drops_creator_id ON public.drops(creator_id);
CREATE INDEX idx_drops_drops_at ON public.drops(drops_at);

-- ============================================================
-- MESSAGES (paid messaging)
-- ============================================================
CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sender_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  receiver_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  body TEXT NOT NULL,
  is_paid BOOLEAN DEFAULT FALSE,
  price_paid NUMERIC(10,2) DEFAULT 0,
  stripe_payment_intent_id TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  thread_id UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_messages_receiver_id ON public.messages(receiver_id);
CREATE INDEX idx_messages_sender_id ON public.messages(sender_id);
CREATE INDEX idx_messages_creator_id ON public.messages(creator_id);

-- ============================================================
-- STRIPE CUSTOMERS (mapping users to stripe customer IDs)
-- ============================================================
CREATE TABLE public.stripe_customers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL UNIQUE REFERENCES public.users(id) ON DELETE CASCADE,
  stripe_customer_id TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- MUX UPLOAD SESSIONS (track video upload state)
-- ============================================================
CREATE TABLE public.mux_uploads (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  creator_id UUID NOT NULL REFERENCES public.creators(id) ON DELETE CASCADE,
  post_id UUID REFERENCES public.posts(id) ON DELETE SET NULL,
  mux_upload_id TEXT NOT NULL,
  mux_asset_id TEXT,
  mux_playback_id TEXT,
  upload_type TEXT NOT NULL CHECK (upload_type IN ('preview', 'full')),
  status TEXT DEFAULT 'waiting' CHECK (status IN ('waiting', 'asset_created', 'ready', 'errored')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- HELPER FUNCTIONS
-- ============================================================

-- Auto-update updated_at timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_creators_updated_at BEFORE UPDATE ON public.creators FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_posts_updated_at BEFORE UPDATE ON public.posts FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_subscriptions_updated_at BEFORE UPDATE ON public.subscriptions FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_bundles_updated_at BEFORE UPDATE ON public.bundles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Update fan badge based on total spend
CREATE OR REPLACE FUNCTION update_fan_badge()
RETURNS TRIGGER AS $$
BEGIN
  NEW.badge_level := CASE
    WHEN NEW.total_spent >= 200 THEN 'day_one'
    WHEN NEW.total_spent >= 100 THEN 'top_supporter'
    WHEN NEW.total_spent >= 50 THEN 'real_fan'
    WHEN NEW.total_spent >= 10 THEN 'supporter'
    ELSE 'none'
  END;
  NEW.updated_at := NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_fan_badge_on_spend BEFORE INSERT OR UPDATE ON public.fan_spend FOR EACH ROW EXECUTE FUNCTION update_fan_badge();

-- Function to check if user can access post full content
CREATE OR REPLACE FUNCTION can_user_access_post(p_user_id UUID, p_post_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
  v_post RECORD;
  v_has_purchase BOOLEAN;
  v_has_subscription BOOLEAN;
  v_has_bundle_purchase BOOLEAN;
  v_is_creator BOOLEAN;
BEGIN
  -- Get post info
  SELECT p.*, c.user_id as creator_user_id
  INTO v_post
  FROM public.posts p
  JOIN public.creators c ON c.id = p.creator_id
  WHERE p.id = p_post_id;

  IF NOT FOUND THEN RETURN FALSE; END IF;

  -- Free post
  IF v_post.is_free THEN RETURN TRUE; END IF;

  -- Must be authenticated
  IF p_user_id IS NULL THEN RETURN FALSE; END IF;

  -- Creator owns this post
  SELECT EXISTS(
    SELECT 1 FROM public.creators
    WHERE user_id = p_user_id AND id = v_post.creator_id
  ) INTO v_is_creator;
  IF v_is_creator THEN RETURN TRUE; END IF;

  -- Direct purchase
  SELECT EXISTS(
    SELECT 1 FROM public.purchases
    WHERE user_id = p_user_id AND post_id = p_post_id AND status = 'completed'
  ) INTO v_has_purchase;
  IF v_has_purchase THEN RETURN TRUE; END IF;

  -- Active subscription (only if post is subscription-included)
  IF v_post.is_subscription_included THEN
    SELECT EXISTS(
      SELECT 1 FROM public.subscriptions
      WHERE user_id = p_user_id
        AND creator_id = v_post.creator_id
        AND status = 'active'
        AND current_period_end > NOW()
    ) INTO v_has_subscription;
    IF v_has_subscription THEN RETURN TRUE; END IF;
  END IF;

  -- Bundle purchase
  SELECT EXISTS(
    SELECT 1 FROM public.bundle_purchases bp
    JOIN public.bundle_posts bposts ON bposts.bundle_id = bp.bundle_id
    WHERE bp.user_id = p_user_id
      AND bposts.post_id = p_post_id
      AND bp.status = 'completed'
  ) INTO v_has_bundle_purchase;
  IF v_has_bundle_purchase THEN RETURN TRUE; END IF;

  RETURN FALSE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- ROW LEVEL SECURITY POLICIES
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creators ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bundles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bundle_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bundle_purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.views ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fan_spend ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.drops ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stripe_customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.mux_uploads ENABLE ROW LEVEL SECURITY;

-- USERS policies
CREATE POLICY "Users can view their own profile" ON public.users FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Users can update their own profile" ON public.users FOR UPDATE USING (auth.uid() = id);
CREATE POLICY "Users are created on signup" ON public.users FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Public profiles viewable" ON public.users FOR SELECT USING (true);

-- CREATORS policies
CREATE POLICY "Anyone can view creator profiles" ON public.creators FOR SELECT USING (true);
CREATE POLICY "Creators manage own profile" ON public.creators FOR ALL USING (
  auth.uid() = user_id
);
CREATE POLICY "Authenticated users can create creator profile" ON public.creators FOR INSERT WITH CHECK (
  auth.uid() = user_id
);

-- POSTS policies
CREATE POLICY "Anyone can view published posts" ON public.posts FOR SELECT USING (
  status = 'published' OR (
    auth.uid() IS NOT NULL AND (
      creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
    )
  )
);
CREATE POLICY "Creators manage own posts" ON public.posts FOR ALL USING (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
);

-- PURCHASES policies
CREATE POLICY "Users view own purchases" ON public.purchases FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "System inserts purchases" ON public.purchases FOR INSERT WITH CHECK (auth.uid() = user_id);

-- SUBSCRIPTIONS policies
CREATE POLICY "Users view own subscriptions" ON public.subscriptions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Creators see their subscribers" ON public.subscriptions FOR SELECT USING (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
);

-- BUNDLES policies
CREATE POLICY "Anyone can view active bundles" ON public.bundles FOR SELECT USING (is_active = true);
CREATE POLICY "Creators manage own bundles" ON public.bundles FOR ALL USING (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
);

-- BUNDLE POSTS policies
CREATE POLICY "Anyone can view bundle contents" ON public.bundle_posts FOR SELECT USING (true);
CREATE POLICY "Creators manage own bundle posts" ON public.bundle_posts FOR ALL USING (
  bundle_id IN (
    SELECT id FROM public.bundles WHERE creator_id IN (
      SELECT id FROM public.creators WHERE user_id = auth.uid()
    )
  )
);

-- BUNDLE PURCHASES policies
CREATE POLICY "Users view own bundle purchases" ON public.bundle_purchases FOR SELECT USING (auth.uid() = user_id);

-- FOLLOWS policies
CREATE POLICY "Anyone can view follows" ON public.follows FOR SELECT USING (true);
CREATE POLICY "Users manage own follows" ON public.follows FOR ALL USING (auth.uid() = user_id);

-- VIEWS policies
CREATE POLICY "Anyone can insert views" ON public.views FOR INSERT WITH CHECK (true);
CREATE POLICY "Users view own views" ON public.views FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Creators see their post views" ON public.views FOR SELECT USING (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
);

-- LIKES policies
CREATE POLICY "Anyone can view likes" ON public.likes FOR SELECT USING (true);
CREATE POLICY "Users manage own likes" ON public.likes FOR ALL USING (auth.uid() = user_id);

-- FAN SPEND policies
CREATE POLICY "Users view own fan spend" ON public.fan_spend FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Creators see fan spend for their profile" ON public.fan_spend FOR SELECT USING (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
);

-- DROPS policies
CREATE POLICY "Anyone can view upcoming drops" ON public.drops FOR SELECT USING (true);
CREATE POLICY "Creators manage own drops" ON public.drops FOR ALL USING (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
);

-- MESSAGES policies
CREATE POLICY "Users see own sent/received messages" ON public.messages FOR SELECT USING (
  auth.uid() = sender_id OR auth.uid() = receiver_id
);
CREATE POLICY "Users send messages" ON public.messages FOR INSERT WITH CHECK (auth.uid() = sender_id);

-- STRIPE CUSTOMERS policies
CREATE POLICY "Users view own stripe customer" ON public.stripe_customers FOR SELECT USING (auth.uid() = user_id);

-- MUX UPLOADS policies
CREATE POLICY "Creators manage own mux uploads" ON public.mux_uploads FOR ALL USING (
  creator_id IN (SELECT id FROM public.creators WHERE user_id = auth.uid())
);

-- ============================================================
-- STORAGE BUCKETS (run after tables)
-- ============================================================
-- Run these in Supabase Dashboard > Storage or via management API:
-- INSERT INTO storage.buckets (id, name, public) VALUES ('creator-assets', 'creator-assets', true);
-- INSERT INTO storage.buckets (id, name, public) VALUES ('thumbnails', 'thumbnails', true);

-- ============================================================
-- SUPABASE AUTH TRIGGER: Auto-create user profile on signup
-- ============================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.users (id, email, role)
  VALUES (NEW.id, NEW.email, 'viewer')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();
