import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        // GreenRoom dark palette
        gr: {
          bg: '#0a0a0a',
          surface: '#111111',
          card: '#161616',
          border: '#222222',
          muted: '#2a2a2a',
          text: '#f0ede8',
          dim: '#8a8580',
          accent: '#f5c842',       // warm spotlight gold
          'accent-dim': '#c9a234',
          red: '#e63b2e',
          green: '#22c55e',
        },
      },
      fontFamily: {
        display: ['var(--font-display)', 'serif'],
        body: ['var(--font-body)', 'sans-serif'],
        mono: ['var(--font-mono)', 'monospace'],
      },
      animation: {
        'fade-in': 'fadeIn 0.4s ease forwards',
        'slide-up': 'slideUp 0.4s ease forwards',
        'pulse-glow': 'pulseGlow 2s ease-in-out infinite',
        'spin-slow': 'spin 3s linear infinite',
      },
      keyframes: {
        fadeIn: { from: { opacity: '0' }, to: { opacity: '1' } },
        slideUp: { from: { opacity: '0', transform: 'translateY(20px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        pulseGlow: {
          '0%, 100%': { boxShadow: '0 0 8px rgba(245,200,66,0.3)' },
          '50%': { boxShadow: '0 0 24px rgba(245,200,66,0.6)' },
        },
      },
      backgroundImage: {
        'spotlight': 'radial-gradient(ellipse at top, rgba(245,200,66,0.08) 0%, transparent 60%)',
        'card-shine': 'linear-gradient(135deg, rgba(255,255,255,0.04) 0%, transparent 50%)',
      },
    },
  },
  plugins: [],
}

export default config
