'use client'

import { createContext, useContext, useEffect, useState, useCallback } from 'react'
import type { Session, User as SupabaseUser } from '@supabase/supabase-js'
import { createBrowserClient } from '@/lib/supabase'
import type { User, Creator } from '@/types'

interface AuthContextType {
  session: Session | null
  user: User | null
  creator: Creator | null
  isLoading: boolean
  isCreator: boolean
  refreshUser: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  session: null,
  user: null,
  creator: null,
  isLoading: true,
  isCreator: false,
  refreshUser: async () => {},
})

export function useAuth() {
  return useContext(AuthContext)
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [user, setUser] = useState<User | null>(null)
  const [creator, setCreator] = useState<Creator | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const supabase = createBrowserClient()

  const loadUserData = useCallback(async (supabaseUser: SupabaseUser | null) => {
    if (!supabaseUser) {
      setUser(null)
      setCreator(null)
      return
    }

    // Load user profile
    const { data: userData } = await supabase
      .from('users')
      .select('*')
      .eq('id', supabaseUser.id)
      .single()

    setUser(userData)

    // Load creator profile if applicable
    if (userData?.role === 'creator') {
      const { data: creatorData } = await supabase
        .from('creators')
        .select('*')
        .eq('user_id', supabaseUser.id)
        .single()
      setCreator(creatorData)
    } else {
      setCreator(null)
    }
  }, [supabase])

  const refreshUser = useCallback(async () => {
    const { data: { user: supabaseUser } } = await supabase.auth.getUser()
    await loadUserData(supabaseUser)
  }, [supabase, loadUserData])

  useEffect(() => {
    // Initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      loadUserData(session?.user ?? null).finally(() => setIsLoading(false))
    })

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session)
        await loadUserData(session?.user ?? null)
        setIsLoading(false)
      }
    )

    return () => subscription.unsubscribe()
  }, [supabase, loadUserData])

  return (
    <AuthContext.Provider
      value={{
        session,
        user,
        creator,
        isLoading,
        isCreator: user?.role === 'creator',
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}
