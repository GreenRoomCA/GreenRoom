'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { Home, Library, Search, User, LayoutDashboard, LogIn } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useAuth } from '@/components/shared/AuthProvider'

const navItems = [
  { href: '/feed', icon: Home, label: 'Feed' },
  { href: '/search', icon: Search, label: 'Discover' },
  { href: '/library', icon: Library, label: 'Library' },
]

export function BottomNav() {
  const pathname = usePathname()
  const { user, isCreator } = useAuth()

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 glass border-t border-white/5 pb-safe md:hidden">
      <div className="flex items-center justify-around h-16 px-2">
        {navItems.map(({ href, icon: Icon, label }) => {
          const isActive = pathname.startsWith(href)
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                'flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition-colors',
                isActive ? 'text-gold' : 'text-text-secondary hover:text-text-primary'
              )}
            >
              <Icon className="w-5 h-5" strokeWidth={isActive ? 2 : 1.5} />
              <span className="text-[10px] font-medium">{label}</span>
            </Link>
          )
        })}

        {isCreator ? (
          <Link
            href="/dashboard"
            className={cn(
              'flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition-colors',
              pathname.startsWith('/dashboard') ? 'text-gold' : 'text-text-secondary hover:text-text-primary'
            )}
          >
            <LayoutDashboard className="w-5 h-5" strokeWidth={1.5} />
            <span className="text-[10px] font-medium">Studio</span>
          </Link>
        ) : user ? (
          <Link
            href="/settings"
            className={cn(
              'flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg transition-colors',
              pathname.startsWith('/settings') ? 'text-gold' : 'text-text-secondary hover:text-text-primary'
            )}
          >
            <User className="w-5 h-5" strokeWidth={1.5} />
            <span className="text-[10px] font-medium">Profile</span>
          </Link>
        ) : (
          <Link
            href="/login"
            className="flex flex-col items-center gap-0.5 px-3 py-1 rounded-lg text-text-secondary hover:text-text-primary transition-colors"
          >
            <LogIn className="w-5 h-5" strokeWidth={1.5} />
            <span className="text-[10px] font-medium">Sign In</span>
          </Link>
        )}
      </div>
    </nav>
  )
}

export function Sidebar() {
  const pathname = usePathname()
  const { user, isCreator, creator } = useAuth()

  return (
    <aside className="hidden md:flex flex-col fixed left-0 top-0 h-screen w-60 border-r border-border bg-surface z-40">
      {/* Logo */}
      <Link href="/" className="flex items-center gap-2 px-6 py-5 border-b border-border">
        <div className="w-8 h-8 rounded-lg bg-gradient-gold flex items-center justify-center">
          <span className="text-black font-display font-bold text-sm">G</span>
        </div>
        <span className="font-display text-xl text-text-primary">GreenRoom</span>
      </Link>

      {/* Nav links */}
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map(({ href, icon: Icon, label }) => {
          const isActive = pathname.startsWith(href)
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                'flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors',
                isActive
                  ? 'bg-gold/10 text-gold'
                  : 'text-text-secondary hover:bg-surface-2 hover:text-text-primary'
              )}
            >
              <Icon className="w-4 h-4" strokeWidth={isActive ? 2 : 1.5} />
              {label}
            </Link>
          )
        })}

        {isCreator && (
          <>
            <div className="pt-4 pb-1">
              <span className="px-3 text-[10px] uppercase tracking-widest text-text-muted font-medium">Creator Studio</span>
            </div>
            {[
              { href: '/dashboard', label: 'Dashboard' },
              { href: '/dashboard/upload', label: 'Upload' },
              { href: '/dashboard/analytics', label: 'Analytics' },
              { href: '/dashboard/bundles', label: 'Bundles' },
              { href: '/dashboard/drops', label: 'Drops' },
              { href: '/dashboard/messages', label: 'Messages' },
            ].map(({ href, label }) => (
              <Link
                key={href}
                href={href}
                className={cn(
                  'flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors',
                  pathname === href
                    ? 'bg-gold/10 text-gold'
                    : 'text-text-secondary hover:bg-surface-2 hover:text-text-primary'
                )}
              >
                {label}
              </Link>
            ))}
          </>
        )}
      </nav>

      {/* User section */}
      <div className="p-4 border-t border-border">
        {user ? (
          <Link href="/settings" className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-surface-2 transition-colors">
            <div className="w-8 h-8 rounded-full bg-surface-3 flex items-center justify-center text-xs font-medium text-text-secondary">
              {user.display_name?.[0]?.toUpperCase() || user.email[0].toUpperCase()}
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-text-primary truncate">
                {user.display_name || creator?.display_name || 'Account'}
              </p>
              <p className="text-xs text-text-secondary truncate">{user.email}</p>
            </div>
          </Link>
        ) : (
          <div className="space-y-2">
            <Link
              href="/login"
              className="block text-center px-4 py-2 rounded-lg border border-border text-sm text-text-secondary hover:text-text-primary hover:border-border-hover transition-colors"
            >
              Sign In
            </Link>
            <Link
              href="/signup"
              className="block text-center px-4 py-2 rounded-lg bg-gold text-black text-sm font-medium hover:bg-gold-light transition-colors"
            >
              Join GreenRoom
            </Link>
          </div>
        )}
      </div>
    </aside>
  )
}
