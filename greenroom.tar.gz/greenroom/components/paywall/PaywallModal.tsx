'use client'

import { useState } from 'react'
import * as Dialog from '@radix-ui/react-dialog'
import { X, Lock, CheckCircle, Zap } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/components/shared/AuthProvider'
import { formatPrice, cn } from '@/lib/utils'
import type { Post } from '@/types'

interface PaywallModalProps {
  post: Post
  onClose: () => void
  defaultTab?: 'purchase' | 'subscribe'
}

export function PaywallModal({ post, onClose, defaultTab = 'purchase' }: PaywallModalProps) {
  const [tab, setTab] = useState<'purchase' | 'subscribe' | 'bundle'>(defaultTab)
  const [isLoading, setIsLoading] = useState(false)
  const { user } = useAuth()
  const router = useRouter()
  const creator = post.creator!

  async function handlePurchase(type: 'post' | 'subscription' | 'bundle', bundleId?: string) {
    if (!user) {
      router.push(`/login?redirect=/post/${post.id}`)
      onClose()
      return
    }

    setIsLoading(true)

    try {
      const endpoint = '/api/stripe/checkout'
      const body = type === 'subscription'
        ? { type: 'subscription', creator_id: creator.id, post_id: post.id }
        : type === 'bundle'
        ? { type: 'bundle', bundle_id: bundleId, post_id: post.id }
        : { type: 'post', post_id: post.id }

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })

      const data = await res.json()

      if (data.checkout_url) {
        window.location.href = data.checkout_url
      } else {
        throw new Error(data.error || 'Failed to create checkout')
      }
    } catch (err) {
      console.error(err)
      setIsLoading(false)
    }
  }

  const subscribePerks = [
    'Unlimited access to all subscription content',
    `All current & future sets by ${creator.display_name}`,
    'Cancel anytime',
  ]

  return (
    <Dialog.Root open onOpenChange={onClose}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/80 z-50 backdrop-blur-sm" />
        <Dialog.Content className="fixed inset-x-4 bottom-4 md:inset-auto md:left-1/2 md:top-1/2 md:-translate-x-1/2 md:-translate-y-1/2 md:max-w-md md:w-full z-50 bg-surface border border-border rounded-2xl shadow-2xl outline-none">
          {/* Handle (mobile) */}
          <div className="flex justify-center pt-3 pb-1 md:hidden">
            <div className="w-10 h-1 rounded-full bg-border" />
          </div>

          <div className="p-6">
            {/* Header */}
            <div className="flex items-start justify-between mb-5">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <Lock className="w-4 h-4 text-gold" />
                  <span className="text-gold text-sm font-medium">Premium Content</span>
                </div>
                <Dialog.Title className="font-display text-xl text-text-primary leading-tight">
                  {post.title}
                </Dialog.Title>
                <Dialog.Description className="text-text-secondary text-sm mt-1">
                  by {creator.display_name}
                  {post.venue && ` · ${post.venue}`}
                </Dialog.Description>
              </div>
              <Dialog.Close asChild>
                <button className="text-text-muted hover:text-text-secondary p-1 rounded-lg">
                  <X className="w-5 h-5" />
                </button>
              </Dialog.Close>
            </div>

            {/* Tabs */}
            <div className="flex gap-1 p-1 bg-surface-2 rounded-xl mb-5">
              {post.is_one_time_purchase_enabled && (
                <button
                  onClick={() => setTab('purchase')}
                  className={cn(
                    'flex-1 py-2 rounded-lg text-sm font-medium transition-colors',
                    tab === 'purchase'
                      ? 'bg-surface text-text-primary shadow'
                      : 'text-text-secondary hover:text-text-primary'
                  )}
                >
                  Buy Set
                </button>
              )}
              <button
                onClick={() => setTab('subscribe')}
                className={cn(
                  'flex-1 py-2 rounded-lg text-sm font-medium transition-colors',
                  tab === 'subscribe'
                    ? 'bg-surface text-text-primary shadow'
                    : 'text-text-secondary hover:text-text-primary'
                )}
              >
                Subscribe
              </button>
            </div>

            {/* Tab content */}
            {tab === 'purchase' && post.is_one_time_purchase_enabled && (
              <div className="space-y-4">
                <div className="bg-surface-2 rounded-xl p-4">
                  <div className="flex items-baseline justify-between mb-3">
                    <span className="text-text-secondary text-sm">One-time purchase</span>
                    <span className="font-display text-3xl text-text-primary">
                      {formatPrice(post.price)}
                    </span>
                  </div>
                  <ul className="space-y-1.5">
                    {[
                      'Permanent access to this full set',
                      'Watch anytime in your library',
                      'Supports the comedian directly',
                    ].map((perk) => (
                      <li key={perk} className="flex items-center gap-2 text-sm text-text-secondary">
                        <CheckCircle className="w-3.5 h-3.5 text-gold shrink-0" />
                        {perk}
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  onClick={() => handlePurchase('post')}
                  disabled={isLoading}
                  className="w-full py-3.5 bg-gold hover:bg-gold-light disabled:opacity-50 text-black font-semibold rounded-xl transition-colors"
                >
                  {isLoading ? 'Loading...' : `Buy for ${formatPrice(post.price)}`}
                </button>
              </div>
            )}

            {tab === 'subscribe' && (
              <div className="space-y-4">
                <div className="bg-surface-2 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Zap className="w-4 h-4 text-gold" />
                    <span className="text-xs text-gold font-medium uppercase tracking-wider">Best Value</span>
                  </div>
                  <div className="flex items-baseline gap-1 mb-3">
                    <span className="font-display text-3xl text-text-primary">
                      {formatPrice(creator.subscription_price)}
                    </span>
                    <span className="text-text-secondary text-sm">/month</span>
                  </div>
                  <ul className="space-y-1.5">
                    {subscribePerks.map((perk) => (
                      <li key={perk} className="flex items-center gap-2 text-sm text-text-secondary">
                        <CheckCircle className="w-3.5 h-3.5 text-gold shrink-0" />
                        {perk}
                      </li>
                    ))}
                  </ul>
                </div>

                <button
                  onClick={() => handlePurchase('subscription')}
                  disabled={isLoading}
                  className="w-full py-3.5 bg-gold hover:bg-gold-light disabled:opacity-50 text-black font-semibold rounded-xl transition-colors"
                >
                  {isLoading ? 'Loading...' : `Subscribe for ${formatPrice(creator.subscription_price)}/mo`}
                </button>

                <p className="text-center text-xs text-text-muted">
                  Cancel anytime. No commitment.
                </p>
              </div>
            )}

            {/* Sign in prompt */}
            {!user && (
              <p className="text-center text-xs text-text-muted mt-3">
                You&apos;ll be asked to sign in or create an account
              </p>
            )}
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}
