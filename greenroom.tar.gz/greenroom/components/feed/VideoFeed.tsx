'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { createBrowserClient } from '@/lib/supabase'
import type { Post } from '@/types'
import MuxPlayer from '@mux/mux-player-react'
import Link from 'next/link'
import { Heart, Share2, Lock, UserPlus, MapPin, Calendar } from 'lucide-react'
import { useAuth } from '@/components/shared/AuthProvider'
import { PaywallModal } from '@/components/paywall/PaywallModal'
import { formatDate, formatNumber, cn } from '@/lib/utils'
import { useToast } from '@/components/ui/Toaster'

// ============================================================
// VIDEO CARD
// ============================================================
interface VideoCardProps {
  post: Post
  isActive: boolean
}

export function VideoCard({ post, isActive }: VideoCardProps) {
  const { user } = useAuth()
  const { success, error } = useToast()
  const [isLiked, setIsLiked] = useState(post.is_liked || false)
  const [likeCount, setLikeCount] = useState(post.like_count || 0)
  const [isFollowing, setIsFollowing] = useState(false)
  const [showPaywall, setShowPaywall] = useState(false)
  const supabase = createBrowserClient()

  const creator = post.creator!

  async function handleLike() {
    if (!user) {
      error('Sign in to like posts')
      return
    }

    const wasLiked = isLiked
    setIsLiked(!wasLiked)
    setLikeCount(wasLiked ? likeCount - 1 : likeCount + 1)

    if (wasLiked) {
      await supabase.from('likes').delete().match({ user_id: user.id, post_id: post.id })
    } else {
      await supabase.from('likes').insert({ user_id: user.id, post_id: post.id })
    }
  }

  async function handleFollow() {
    if (!user) {
      error('Sign in to follow comedians')
      return
    }

    if (isFollowing) {
      await supabase.from('follows').delete().match({ user_id: user.id, creator_id: creator.id })
      setIsFollowing(false)
    } else {
      await supabase.from('follows').insert({ user_id: user.id, creator_id: creator.id })
      setIsFollowing(true)
      success(`Following ${creator.display_name}`)
    }
  }

  function handleShare() {
    const url = `${window.location.origin}/post/${post.id}`
    const text = `Missed the show? Watch "${post.title}" by ${creator.display_name} on GreenRoom.`
    if (navigator.share) {
      navigator.share({ title: post.title, text, url })
    } else {
      navigator.clipboard.writeText(url)
      success('Link copied!')
    }
  }

  // Track preview view
  useEffect(() => {
    if (isActive && post.preview_mux_playback_id) {
      supabase.from('views').insert({
        post_id: post.id,
        creator_id: post.creator_id,
        view_type: 'preview',
        user_id: user?.id || null,
      }).then()
    }
  }, [isActive, post.id, post.creator_id, post.preview_mux_playback_id, user?.id, supabase])

  return (
    <>
      <div className="relative bg-black min-h-screen md:min-h-0 md:rounded-2xl md:overflow-hidden md:mb-4 md:border md:border-border">
        {/* Video */}
        <div
          className="relative w-full bg-black"
          style={{ aspectRatio: '9/16' }}
          onContextMenu={(e) => e.preventDefault()}
        >
          {post.preview_mux_playback_id ? (
            <MuxPlayer
              playbackId={post.preview_mux_playback_id}
              autoPlay={isActive}
              muted={true}
              loop={true}
              paused={!isActive}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              className="w-full h-full"
              preload={isActive ? 'auto' : 'none'}
              thumbnailTime={5}
            />
          ) : (
            <div className="w-full h-full bg-surface-2 flex items-center justify-center">
              <span className="text-text-muted text-sm">Preview uploading...</span>
            </div>
          )}

          {/* Gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent pointer-events-none" />
          <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-transparent pointer-events-none" />

          {/* Watermark */}
          <div className="watermark">Full set on GreenRoom</div>

          {/* Category tag */}
          <div className="absolute top-4 left-4">
            <span className="px-2.5 py-1 rounded-full bg-black/50 backdrop-blur text-xs text-text-secondary border border-white/10">
              {post.category}
            </span>
          </div>

          {/* Right actions */}
          <div className="absolute right-4 bottom-32 flex flex-col gap-4 items-center">
            {/* Creator avatar */}
            <Link href={`/creator/${creator.username}`}>
              <div className="relative">
                <div className="w-12 h-12 rounded-full border-2 border-gold overflow-hidden bg-surface-2">
                  {creator.profile_image_url ? (
                    <img
                      src={creator.profile_image_url}
                      alt={creator.display_name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gold font-display text-lg">
                      {creator.display_name[0]}
                    </div>
                  )}
                </div>
                {!isFollowing && (
                  <button
                    onClick={handleFollow}
                    className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-5 h-5 bg-gold rounded-full flex items-center justify-center"
                  >
                    <span className="text-black text-xs font-bold">+</span>
                  </button>
                )}
              </div>
            </Link>

            {/* Like */}
            <button onClick={handleLike} className="flex flex-col items-center gap-1">
              <div className={cn(
                'w-11 h-11 rounded-full flex items-center justify-center transition-colors',
                isLiked ? 'bg-red-500/20' : 'bg-black/40'
              )}>
                <Heart
                  className={cn('w-5 h-5', isLiked ? 'fill-red-500 text-red-500' : 'text-white')}
                />
              </div>
              <span className="text-white text-xs">{formatNumber(likeCount)}</span>
            </button>

            {/* Share */}
            <button onClick={handleShare} className="flex flex-col items-center gap-1">
              <div className="w-11 h-11 rounded-full bg-black/40 flex items-center justify-center">
                <Share2 className="w-5 h-5 text-white" />
              </div>
              <span className="text-white text-xs">Share</span>
            </button>
          </div>

          {/* Bottom content overlay */}
          <div className="absolute bottom-0 left-0 right-14 p-4 space-y-2">
            {/* Creator name */}
            <Link
              href={`/creator/${creator.username}`}
              className="inline-flex items-center gap-2 hover:opacity-80 transition-opacity"
            >
              <span className="text-white font-semibold text-sm">@{creator.username}</span>
              {isFollowing && (
                <span className="text-xs text-gold">Following</span>
              )}
            </Link>

            {/* Title */}
            <h3 className="text-white font-display text-lg leading-tight">{post.title}</h3>

            {/* Caption */}
            {post.description && (
              <p className="text-white/70 text-sm line-clamp-2">{post.description}</p>
            )}

            {/* Show metadata */}
            {(post.city || post.venue || post.show_date) && (
              <div className="flex flex-wrap gap-3 text-xs text-white/50">
                {(post.city || post.venue) && (
                  <span className="flex items-center gap-1">
                    <MapPin className="w-3 h-3" />
                    {[post.venue, post.city].filter(Boolean).join(' · ')}
                  </span>
                )}
                {post.show_date && (
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {formatDate(post.show_date)}
                  </span>
                )}
              </div>
            )}

            {/* Action buttons */}
            <div className="flex gap-2 pt-1">
              {post.is_free ? (
                <Link
                  href={`/watch/${post.id}`}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-gold text-black text-sm font-semibold rounded-xl"
                >
                  Watch Free
                </Link>
              ) : (
                <button
                  onClick={() => setShowPaywall(true)}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-gold/90 text-black text-sm font-semibold rounded-xl"
                >
                  <Lock className="w-3.5 h-3.5" />
                  Unlock Full Set · ${post.price}
                </button>
              )}

              {creator.subscription_price > 0 && (
                <button
                  onClick={() => setShowPaywall(true)}
                  className="flex items-center gap-1.5 px-3 py-2.5 border border-white/20 bg-black/40 text-white text-xs rounded-xl backdrop-blur"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  Subscribe
                </button>
              )}
            </div>

            {/* Ticket link */}
            {creator.ticket_link && (
              <a
                href={creator.ticket_link}
                target="_blank"
                rel="noopener noreferrer"
                className="block text-center text-xs text-gold/70 hover:text-gold py-1"
              >
                🎟 See {creator.display_name} live →
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Paywall modal */}
      {showPaywall && (
        <PaywallModal
          post={post}
          onClose={() => setShowPaywall(false)}
        />
      )}
    </>
  )
}

// ============================================================
// VIDEO FEED CONTAINER
// ============================================================
interface VideoFeedProps {
  initialPosts: Post[]
  category?: string
}

export function VideoFeed({ initialPosts, category }: VideoFeedProps) {
  const [posts, setPosts] = useState<Post[]>(initialPosts)
  const [activeIndex, setActiveIndex] = useState(0)
  const [isLoadingMore, setIsLoadingMore] = useState(false)
  const [hasMore, setHasMore] = useState(initialPosts.length >= 10)
  const [page, setPage] = useState(1)
  const containerRef = useRef<HTMLDivElement>(null)
  const supabase = createBrowserClient()

  // Intersection observer for active video detection
  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const options: IntersectionObserverInit = {
      threshold: 0.5,
    }

    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const index = parseInt((entry.target as HTMLElement).dataset.index || '0')
          setActiveIndex(index)
        }
      })
    }, options)

    const items = container.querySelectorAll('[data-feed-item]')
    items.forEach((item) => observer.observe(item))

    return () => observer.disconnect()
  }, [posts.length])

  const loadMore = useCallback(async () => {
    if (isLoadingMore || !hasMore) return
    setIsLoadingMore(true)

    const nextPage = page + 1
    const limit = 10
    const offset = page * limit

    let query = supabase
      .from('posts')
      .select(`
        *,
        creator:creators(id, display_name, username, profile_image_url, subscription_price, ticket_link)
      `)
      .eq('status', 'published')
      .not('preview_mux_playback_id', 'is', null)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1)

    if (category) {
      query = query.eq('category', category)
    }

    const { data } = await query

    if (!data || data.length < limit) {
      setHasMore(false)
    }

    if (data && data.length > 0) {
      setPosts((prev) => [...prev, ...data as Post[]])
      setPage(nextPage)
    }

    setIsLoadingMore(false)
  }, [isLoadingMore, hasMore, page, category, supabase])

  useEffect(() => {
    if (activeIndex >= posts.length - 3) {
      loadMore()
    }
  }, [activeIndex, posts.length, loadMore])

  if (posts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4 py-20">
        <span className="text-4xl mb-4">🎤</span>
        <h3 className="font-display text-xl text-text-primary mb-2">No sets yet</h3>
        <p className="text-text-secondary text-sm">
          {category ? `No ${category} content yet.` : 'Check back soon!'}
        </p>
      </div>
    )
  }

  return (
    <div ref={containerRef} className="md:max-w-[480px] mx-auto">
      {posts.map((post, index) => (
        <div
          key={post.id}
          data-feed-item
          data-index={index}
        >
          <VideoCard post={post} isActive={index === activeIndex} />
        </div>
      ))}

      {isLoadingMore && (
        <div className="py-8 flex justify-center">
          <div className="w-8 h-8 rounded-full border-2 border-gold/20 border-t-gold animate-spin" />
        </div>
      )}

      {!hasMore && posts.length > 0 && (
        <div className="py-12 text-center">
          <p className="text-text-muted text-sm">You've seen everything — follow more comedians.</p>
        </div>
      )}
    </div>
  )
}
