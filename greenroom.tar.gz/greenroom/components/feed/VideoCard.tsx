'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { VideoCard } from './VideoCard'
import { createBrowserClient } from '@/lib/supabase'
import type { Post } from '@/types'

interface VideoFeedProps {
  initialPosts: Post[]
  category?: string
}

export function VideoFeed({ initialPosts, category }: VideoFeedProps) {
  const [posts, setPosts] = useState<Post[]>(initialPosts)
  const [activeIndex, setActiveIndex] = useState(0)
  const [isLoadingMore, setIsLoadingMore] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const [page, setPage] = useState(1)
  const containerRef = useRef<HTMLDivElement>(null)
  const supabase = createBrowserClient()

  // Intersection observer to detect active video
  useEffect(() => {
    const container = containerRef.current
    if (!container) return

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const index = parseInt(
              (entry.target as HTMLElement).dataset.index || '0'
            )
            setActiveIndex(index)
          }
        })
      },
      { threshold: 0.6, root: container }
    )

    const items = container.querySelectorAll('[data-index]')
    items.forEach((item) => observer.observe(item))

    return () => observer.disconnect()
  }, [posts.length])

  // Load more posts when near the end
  const loadMore = useCallback(async () => {
    if (isLoadingMore || !hasMore) return
    setIsLoadingMore(true)

    const nextPage = page + 1
    const limit = 10
    const offset = page * limit

    let query = supabase
      .from('posts')
      .select(`
        *,
        creator:creators(
          id, display_name, username, profile_image_url,
          subscription_price, ticket_link
        )
      `)
      .eq('status', 'published')
      .not('preview_mux_playback_id', 'is', null)
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1)

    if (category) {
      query = query.eq('category', category)
    }

    const { data } = await query

    if (!data || data.length === 0) {
      setHasMore(false)
    } else {
      setPosts((prev) => [...prev, ...data])
      setPage(nextPage)
    }

    setIsLoadingMore(false)
  }, [isLoadingMore, hasMore, page, category, supabase])

  // Trigger load more when approaching end
  useEffect(() => {
    if (activeIndex >= posts.length - 3) {
      loadMore()
    }
  }, [activeIndex, posts.length, loadMore])

  if (posts.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
        <div className="w-16 h-16 rounded-full bg-surface-2 flex items-center justify-center mb-4">
          <span className="text-2xl">🎤</span>
        </div>
        <h3 className="font-display text-xl text-text-primary mb-2">
          No sets here yet
        </h3>
        <p className="text-text-secondary text-sm">
          {category
            ? `No ${category} content yet. Check back soon.`
            : 'Be the first comedian to post a set!'}
        </p>
      </div>
    )
  }

  return (
    <div
      ref={containerRef}
      className="md:max-w-[480px] mx-auto"
    >
      {posts.map((post, index) => (
        <div
          key={post.id}
          data-index={index}
          className="relative"
        >
          <VideoCard
            post={post}
            isActive={index === activeIndex}
          />
        </div>
      ))}

      {isLoadingMore && (
        <div className="py-8 flex justify-center">
          <div className="w-8 h-8 rounded-full border-2 border-gold/20 border-t-gold animate-spin" />
        </div>
      )}

      {!hasMore && posts.length > 0 && (
        <div className="py-12 text-center">
          <p className="text-text-muted text-sm">You've seen it all. Follow more comedians for fresh sets.</p>
        </div>
      )}
    </div>
  )
}
