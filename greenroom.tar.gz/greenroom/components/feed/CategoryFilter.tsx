'use client'

import { useRouter, usePathname, useSearchParams } from 'next/navigation'
import { cn } from '@/lib/utils'
import type { PostCategory } from '@/types'

const categories: Array<{ value: PostCategory | 'all'; label: string }> = [
  { value: 'all', label: 'All' },
  { value: 'Full Set', label: 'Full Sets' },
  { value: 'Crowd Work', label: 'Crowd Work' },
  { value: 'Unreleased', label: 'Unreleased' },
  { value: 'Test Material', label: 'Test Material' },
  { value: 'Special', label: 'Specials' },
  { value: 'Behind the Scenes', label: 'Behind the Scenes' },
]

interface CategoryFilterProps {
  selected?: string
}

export function CategoryFilter({ selected }: CategoryFilterProps) {
  const router = useRouter()
  const pathname = usePathname()
  const searchParams = useSearchParams()

  function handleSelect(category: string) {
    const params = new URLSearchParams(searchParams.toString())
    if (category === 'all') {
      params.delete('category')
    } else {
      params.set('category', category)
    }
    params.delete('page')
    router.push(`${pathname}?${params.toString()}`)
  }

  return (
    <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none no-scrollbar">
      {categories.map(({ value, label }) => {
        const isActive = value === 'all' ? !selected : selected === value
        return (
          <button
            key={value}
            onClick={() => handleSelect(value)}
            className={cn(
              'shrink-0 px-3.5 py-1.5 rounded-full text-sm font-medium transition-all',
              isActive
                ? 'bg-gold text-black'
                : 'bg-surface-2 text-text-secondary hover:bg-surface-3 hover:text-text-primary'
            )}
          >
            {label}
          </button>
        )
      })}
    </div>
  )
}
